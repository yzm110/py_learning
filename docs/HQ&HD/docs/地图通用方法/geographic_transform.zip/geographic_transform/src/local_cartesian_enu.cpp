/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#include "geographic_transform/local_cartesian_enu.h"

namespace geographic_transform
{

LocalCartesianENU::LocalCartesianENU() :
  ecef_T_local_enu_(Eigen::Isometry3d::Identity())
{
}


LocalCartesianENU::LocalCartesianENU(const Eigen::Vector3d& local_frame_origin_ecef)
{
  setLocalFrameOrigin(local_frame_origin_ecef);
}


LocalCartesianENU::LocalCartesianENU(const GeoPoint& local_frame_origin)
{
  setLocalFrameOrigin(local_frame_origin);
}


void LocalCartesianENU::setLocalFrameOrigin(const Eigen::Vector3d& local_origin_ecef) {
  local_frame_origin_ = ECEFPoint(local_origin_ecef);
  ecef_T_local_enu_.translation() = local_origin_ecef;
  ecef_T_enu_rotation(local_frame_origin_, ecef_T_local_enu_);
}


void LocalCartesianENU::setLocalFrameOrigin(const GeoPoint& local_origin) {
  local_frame_origin_ = local_origin;
  ecef_T_local_enu_.translation() = ECEFPoint(local_origin);
  ecef_T_enu_rotation(local_frame_origin_, ecef_T_local_enu_);
}


void LocalCartesianENU::fromLatLong(const GeoPoint& geo_point, Eigen::Vector3d& local_point) const
{
  local_point = ecef_T_local_enu_.inverse() * ECEFPoint(geo_point);
}


Eigen::Vector3d LocalCartesianENU::fromLatLong(const GeoPoint& geo_point) const
{
  return ecef_T_local_enu_.inverse() * ECEFPoint(geo_point);
}


void LocalCartesianENU::fromLatLong(const GeoPose& geo_pose, Eigen::Isometry3d& local_pose) const
{
  local_pose = ecef_T_local_enu_.inverse() * geo_pose.toECEF();
}


Eigen::Isometry3d LocalCartesianENU::fromLatLong(const GeoPose& geo_pose) const
{
  return ecef_T_local_enu_.inverse() * geo_pose.toECEF();
}


void LocalCartesianENU::fromECEF(const Eigen::Vector3d& ecef_point, Eigen::Vector3d& local_point) const
{
  local_point = ecef_T_local_enu_.inverse() * ecef_point;
}


Eigen::Vector3d LocalCartesianENU::fromECEF(const Eigen::Vector3d& ecef_point) const
{
  return ecef_T_local_enu_.inverse() * ecef_point;;
}


void LocalCartesianENU::fromECEF(const Eigen::Isometry3d& ecef_pose, Eigen::Isometry3d& local_pose) const
{
  local_pose = ecef_T_local_enu_.inverse() * ecef_pose;
}


Eigen::Isometry3d LocalCartesianENU::fromECEF(const Eigen::Isometry3d& ecef_pose) const
{
  return ecef_T_local_enu_.inverse() * ecef_pose;
}


void LocalCartesianENU::toLatLong(const Eigen::Vector3d& local_point, GeoPoint& geo_point) const
{
  geo_point = GeoPoint(ecef_T_local_enu_ * local_point);
}


GeoPoint LocalCartesianENU::toLatLong(const Eigen::Vector3d& local_point) const
{
  return GeoPoint(ecef_T_local_enu_ * local_point);
}


void LocalCartesianENU::toLatLong(const Eigen::Isometry3d& local_pose, GeoPose& geo_pose) const
{
  geo_pose = ecef_T_local_enu_ * local_pose;
}


GeoPose LocalCartesianENU::toLatLong(const Eigen::Isometry3d& local_pose) const
{
  return GeoPose(ecef_T_local_enu_ * local_pose);
}


void LocalCartesianENU::toECEF(const Eigen::Vector3d& local_point, Eigen::Vector3d& ecef_point) const
{
  ecef_point = ecef_T_local_enu_ * local_point;
}


Eigen::Vector3d LocalCartesianENU::toECEF(const Eigen::Vector3d& local_point) const
{
  return ecef_T_local_enu_ * local_point;
}


void LocalCartesianENU::toECEF(const Eigen::Isometry3d& local_pose, Eigen::Isometry3d& ecef_pose) const
{
  ecef_pose = ecef_T_local_enu_ * local_pose;
}


Eigen::Isometry3d LocalCartesianENU::toECEF(const Eigen::Isometry3d& local_pose) const
{
  return ecef_T_local_enu_ * local_pose;
}

} // namespace geographic_transform
