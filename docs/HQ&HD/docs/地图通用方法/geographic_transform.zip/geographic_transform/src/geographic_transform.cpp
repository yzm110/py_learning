/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#include <exception>
#include "geographic_transform/geographic_transform.h"
#include "GeographicLib/Geocentric.hpp"
#include "GeographicLib/Geodesic.hpp"
#include "GeographicLib/TransverseMercator.hpp"

using namespace GeographicLib;

//Beijing54 Geodetic coordinate system (Krasovsky reference ellipsoid)
#define    kKRASOVSKY_A        6378245.0				    // equatorial radius [unit: meter]
#define    kKRASOVSKY_B        6356863.0187730473	        // polar radius
#define    kKRASOVSKY_ECCSQ    6.6934216229659332e-3        // first eccentricity squared
#define    kKRASOVSKY_ECC2SQ   6.7385254146834811e-3        // second eccentricity squared
#define    PI                  3.14159265358979323846       // pi

#define    kDEG2RAD            (PI / 180.0)                 // degree to radian
#define    kRAD2DEG            (180.0 / PI)                 // radian to degree

/**
 *  \brief Angle unit transform, degree to radian
 *
 *  \param [in] deg: angle in degrees
 *  \return Returns angle in radians
 *  \date 16:26:22 2021/09/02
 */
inline double Deg2Rad(const double deg) {
	return deg * kDEG2RAD;
}

/**
 *  \brief Angle unit transform, radian to degree
 *
 *  \param [in] rad: angle in radians
 *  \return Returns angle in degrees
 *  \date 16:26:22 2021/09/02
 */
inline double Rad2Deg(const double rad) {
	return rad * kRAD2DEG;
}

namespace geographic_transform
{
#ifdef _MSC_VER
#	pragma region ECEFPoint
#endif
ECEFPoint::ECEFPoint()
{

}


ECEFPoint::ECEFPoint(const Eigen::Vector3d& ecef_point) :
  Eigen::Vector3d(ecef_point)
{

}


ECEFPoint::ECEFPoint(double x, double y, double z) :
  Eigen::Vector3d(x, y, z)
{

}


ECEFPoint::ECEFPoint(const GeoPoint& geo_point)
{
  *this = geo_point;
}


ECEFPoint& ECEFPoint::operator=(const Eigen::Vector3d& ecef_point)
{
  Eigen::Vector3d::operator=(ecef_point);
  return *this;
}


// Convert from geodetic to geocentric coordinates.
ECEFPoint& ECEFPoint::operator=(const GeoPoint& geo_point)
{
  GeographicLib::Geocentric::WGS84().Forward(geo_point.latitude(), geo_point.longitude(), geo_point.elevation(), x(), y(), z());
  return *this;
}
#ifdef _MSC_VER
#	pragma endregion ECEFPoint
#endif

#ifdef _MSC_VER
#	pragma region GeoPoint
#endif
GeoPoint::GeoPoint()
{
  // set it to the middle of the earth (valid() is false after the default constructor)
  latitude_ = 0.0;
  longitude_ = 0.0;
  elevation_ = -GeographicLib::Constants::WGS84_a();
}


GeoPoint::GeoPoint(double lat, double lon, double ele)
{
  latitude_ = lat;
  longitude_ = lon;
  elevation_ = ele;
}


GeoPoint::GeoPoint(const Eigen::Vector3d& ecef_point)
{
  *this = ecef_point;
}


GeoPoint& GeoPoint::operator=(const Eigen::Vector3d& ecef_point)
{
  GeographicLib::Geocentric::WGS84().Reverse(ecef_point.x(), ecef_point.y(), ecef_point.z(), latitude_, longitude_, elevation_);
  return *this;
}

void GeoPoint::toECEF(Eigen::Vector3d& ecef_point) const
{
  GeographicLib::Geocentric::WGS84().Forward(latitude(), longitude(), elevation(), ecef_point.x(), ecef_point.y(), ecef_point.z());
}

Eigen::Vector3d GeoPoint::toECEF() const
{
  Eigen::Vector3d  ecef_point;
  toECEF(ecef_point);
  return ecef_point;
}

bool GeoPoint::valid() const
{
  return (longitude_ >= -180.0 && longitude_ <= 180.0 &&
          latitude_ >= -90.0 && latitude_ <= 90.0 &&
          elevation_ > -GeographicLib::Constants::WGS84_a()) && elevation_ < 10000.0;
}

double GeoPoint::distance(const GeoPoint& geo_point) const
{
  double dist;
  GeographicLib::Geodesic::WGS84().Inverse(latitude_, longitude_, geo_point.latitude(), geo_point.longitude(), dist);
  return dist;
}

void GeoPoint::offsetOnGeoid(const GeoPoint& other, double& dx, double& dy) const
{
  double dist, azimuth1, azimuth2;
  GeographicLib::Geodesic::WGS84().Inverse(latitude_, longitude_, other.latitude(), other.longitude(), dist, azimuth1, azimuth2);

  dx = std::sin(azimuth1 * GeographicLib::Math::pi() / 180.0) * dist;
  dy = std::cos(azimuth1 * GeographicLib::Math::pi() / 180.0) * dist;
}

GeoPoint&  GeoPoint::moveOnGeoid(double dx, double dy, double dz)
{
  double dist = std::sqrt(dx * dx + dy * dy);
  double azimuth = std::atan2(dx, dy);
  GeographicLib::Geodesic::WGS84().Direct(latitude_, longitude_, azimuth * 180.0 / GeographicLib::Math::pi(), dist, latitude_, longitude_);
  elevation_ += dz;
  return *this;
}

GeoPoint GeoPoint::moveCopyOnGeoid(double dx, double dy, double dz) const
{
  GeoPoint moved_point(*this);
  return moved_point.moveOnGeoid(dx, dy, dz);
}

/**
*  \brief Convert WGS84 Coordinate(Lat, Lon) to GCJ02 Coordinate(Lat, Lon)
*
*  \param [in] wgs84: latitude and latitude in WGS84 in degree
*  \param [out] gcj02: latitude and longitude in GCJ02 in degree
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::Wgs84LatLon_2_Gcj02LatLon(GeoPoint wgs84, GeoPoint* gcj02)
{
	//try
	{
		//get geodetic offset relative to 'center china'
		double lon0 = wgs84.longitude_ - 105.0;
		double lat0 = wgs84.latitude_ - 35.0;

		//generate an pair offset roughly in meters
		double lon1 = 300.0 + lon0 + 2.0 * lat0 + 0.1 * lon0 * lon0 + 0.1 * lon0 * lat0 + 0.1 * sqrt(fabs(lon0));
		lon1 = lon1 + (20.0 * sin(6.0 * lon0 * PI) + 20.0 * sin(2.0 * lon0 * PI)) * 2.0 / 3.0;
		lon1 = lon1 + (20.0 * sin(lon0 * PI) + 40.0 * sin(lon0 / 3.0 * PI)) * 2.0 / 3.0;
		lon1 = lon1 + (150.0 * sin(lon0 / 12.0 * PI) + 300.0 * sin(lon0 * PI / 30.0)) * 2.0 / 3.0;
		double lat1 = -100.0 + 2.0 * lon0 + 3.0 * lat0 + 0.2 * lat0 * lat0 + 0.1 * lon0 * lat0 + 0.2 * sqrt(fabs(lon0));
		lat1 = lat1 + (20.0 * sin(6.0 * lon0 * PI) + 20.0 * sin(2.0 * lon0 * PI)) * 2.0 / 3.0;
		lat1 = lat1 + (20.0 * sin(lat0 * PI) + 40.0 * sin(lat0 / 3.0 * PI)) * 2.0 / 3.0;
		lat1 = lat1 + (160.0 * sin(lat0 / 12.0 * PI) + 320.0 * sin(lat0 * PI / 30.0)) * 2.0 / 3.0;

		//latitude in radian
		double B = Deg2Rad(wgs84.latitude_);
		double sinB = sin(B), cosB = cos(B);
		double W = sqrt(1 - kKRASOVSKY_ECCSQ * sinB * sinB);
		double N = kKRASOVSKY_A / W;

		//geodetic offset used by GCJ-02
		double lat2 = Rad2Deg(lat1 * W * W / (N * (1 - kKRASOVSKY_ECCSQ)));
		double lon2 = Rad2Deg(lon1 / (N * cosB));

		gcj02->latitude_ = wgs84.latitude_ + lat2;
		gcj02->longitude_ = wgs84.longitude_ + lon2;
	}
    // catch (exception& e)
    // {
	//     throw(GeographicErr(e.what()));
	// }
}

/**
*  \brief Convert GCJ02 Coordinate(Lat, Lon) to WGS84 Coordinate(Lat, Lon)
*
*  \param [in] gcj02: latitude and latitude in GCJ02 in degree
*  \param [out] wgs84: latitude and longitude in WGS84 in degree
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::Gcj02LatLon_2_Wgs84LatLon(GeoPoint gcj02, GeoPoint *wgs84)
{
	//try
	{
		double wgs84lon = gcj02.longitude_, wgs84lat = gcj02.latitude_;
		GeoPoint tmp_wgs84_pt;

		int nIterCount = 0;
		while (++nIterCount < 1000)
		{
			//get geodetic offset relative to 'center china'
			double lon0 = wgs84lon - 105.0;
			double lat0 = wgs84lat - 35.0;

			//generate an pair offset roughly in meters
			double lon1 = 300.0 + lon0 + 2.0 * lat0 + 0.1 * lon0 * lon0 + 0.1 * lon0 * lat0 + 0.1 * sqrt(fabs(lon0));
			lon1 = lon1 + (20.0 * sin(6.0 * lon0 * PI) + 20.0 * sin(2.0 * lon0 * PI)) * 2.0 / 3.0;
			lon1 = lon1 + (20.0 * sin(lon0 * PI) + 40.0 * sin(lon0 / 3.0 * PI)) * 2.0 / 3.0;
			lon1 = lon1 + (150.0 * sin(lon0 / 12.0 * PI) + 300.0 * sin(lon0 * PI / 30.0)) * 2.0 / 3.0;
			double lat1 = -100.0 + 2.0 * lon0 + 3.0 * lat0 + 0.2 * lat0 * lat0 + 0.1 * lon0 * lat0 + 0.2 * sqrt(fabs(lon0));
			lat1 = lat1 + (20.0 * sin(6.0 * lon0 * PI) + 20.0 * sin(2.0 * lon0 * PI)) * 2.0 / 3.0;
			lat1 = lat1 + (20.0 * sin(lat0 * PI) + 40.0 * sin(lat0 / 3.0 * PI)) * 2.0 / 3.0;
			lat1 = lat1 + (160.0 * sin(lat0 / 12.0 * PI) + 320.0 * sin(lat0 * PI / 30.0)) * 2.0 / 3.0;

			double g_lon0 = 0;
			if (lon0 > 0)
				g_lon0 = 0.05 / sqrt(lon0);
			else if (lon0 < 0)
				g_lon0 = -0.05 / sqrt(-lon0);
			else
				g_lon0 = 0;

			double PIlon0 = PI * lon0, PIlat0 = PI * lat0;
			double dlon1_dlonwgs = 1 + 0.2 * lon0 + 0.1 * lat0 + g_lon0 + ((120 * PI * cos(6 * PIlon0) + 40 * PI * cos(2 * PIlon0)) + (20 * PI * cos(PIlon0) + 40 * PI / 3.0 * cos(PIlon0 / 3.0)) + (12.5 * PI * cos(PIlon0 / 12.0) + 10 * PI * cos(PIlon0 / 30.0))) * 2.0 / 3.0;
			double dlon1_dlatwgs = 2 + 0.1 * lon0;

			double dlat1_dlonwgs = 2 + 0.1 * lat0 + 2 * g_lon0 + (120 * PI * cos(6 * PIlon0) + 40 * PI * cos(2 * PIlon0)) * 2.0 / 3.0;
			double dlat1_dlatwgs = 3 + 0.4 * lat0 + 0.1 * lon0 + ((20 * PI * cos(PIlat0) + 40.0 * PI / 3.0 * cos(PIlat0 / 3.0)) + (40 * PI / 3.0 * cos(PIlat0 / 12.0) + 32.0 * PI / 3.0 * cos(PIlat0 / 30.0))) * 2.0 / 3.0;

			//latitude in radian
			double B = Deg2Rad(wgs84lat);
			double sinB = sin(B), cosB = cos(B);
			double WSQ = 1 - kKRASOVSKY_ECCSQ * sinB * sinB;
			double W = sqrt(WSQ);
			double N = kKRASOVSKY_A / W;

			double dW_dlatwgs = -PI * kKRASOVSKY_ECCSQ * sinB * cosB / (180.0 * W);
			double dN_dlatwgs = -kKRASOVSKY_A * dW_dlatwgs / WSQ;

			double PIxNxCosB = PI * N * cosB;
			double dlongcj_dlonwgs = 1.0 + 180.0 * dlon1_dlonwgs / PIxNxCosB;
			double dlongcj_dlatwgs = 180 * dlon1_dlatwgs / PIxNxCosB -
									 180 * lon1 * PI * (dN_dlatwgs * cosB - PI * N * sinB / 180.0) / (PIxNxCosB * PIxNxCosB);

			double PIxNxSubECCSQ = PI * N * (1 - kKRASOVSKY_ECCSQ);
			double dlatgcj_dlonwgs = 180 * WSQ * dlat1_dlonwgs / PIxNxSubECCSQ;
			double dlatgcj_dlatwgs = 1.0 + 180 * (N * (dlat1_dlatwgs * WSQ + 2.0 * lat1 * W * dW_dlatwgs) - lat1 * WSQ * dN_dlatwgs) /
											   (N * PIxNxSubECCSQ);

			GeoPoint wgs84_pt(wgs84lat, wgs84lon);
			Wgs84LatLon_2_Gcj02LatLon(wgs84_pt, &tmp_wgs84_pt);

			double l_lat = gcj02.latitude_ - tmp_wgs84_pt.latitude_;
			double l_lon = gcj02.longitude_ - tmp_wgs84_pt.longitude_;

			double d_latwgs = (l_lon * dlatgcj_dlonwgs - l_lat * dlongcj_dlonwgs) /
							  (dlongcj_dlatwgs * dlatgcj_dlonwgs - dlatgcj_dlatwgs * dlongcj_dlonwgs);
			double d_lonwgs = (l_lon - dlongcj_dlatwgs * d_latwgs) / dlongcj_dlonwgs;

			if (fabs(d_latwgs) < 1.0e-9 && fabs(d_lonwgs) < 1.0e-9)
				break;
			wgs84lat = wgs84lat + d_latwgs;
			wgs84lon = wgs84lon + d_lonwgs;
		}
		wgs84->latitude_ = wgs84lat;
		wgs84->longitude_ = wgs84lon;
	}
	// catch (exception& e)
	// {
	// 	throw(GeographicErr(e.what()));
	// }
}

/**
*  \brief Convert the Geodetic Coordinate(Lat, Lon) to Plane Coordinate(x, y)
*
*  \param [in] lat: latitude in degree
*  \param [in] lon: longitude in degree
*  \param [in] southHemi: flag to indicate if in south hemisphere, true: south, false: north
*  \param [out] x: plane coordinate x in meter
*  \param [out] y: plane coordinate y in meter
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::lla2utm(double lat, double lon, bool southHemi, double *x, double *y)
{
	// try
	{
		double central_meridian;
		double zone;
		double false_easting;
		double false_northing;

		zone = int(lon / 6) + 31;

		if (zone < 1 || zone > 60)
		{
			throw GeographicErr("zone not in [1,60]");
		}

		central_meridian = 6 * zone - 183;
		false_easting = 5e5;

		if (southHemi)
		{
			false_northing = 100e5;
		}
		else
		{
			false_northing = 0;
		}

		TransverseMercator tm(Constants::WGS84_a(), Constants::WGS84_f(), Constants::UTM_k0());

		tm.Forward(central_meridian, lat, lon, *x, *y);

		*x += false_easting;
		*y += false_northing;
	}
	// catch (exception& e)
	// {
	// 	throw(GeographicErr(e.what()));
	// }
}

/**
*  \brief Convert Plane Coordinate(x, y) to Geodetic Coordinate(Lat, Lon)
*
*  \param [in] zone: zone number
*  \param [in] southHemi: flag to indicate if in south hemisphere, true: south, false: north
*  \param [in] x: plane coordinate x in meter
*  \param [in] y: plane coordinate y in meter
*  \param [out] lat: latitude in degree
*  \param [out] lon: longitude in degree
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::utm2lla(int zone, bool southHemi, double x, double y, double *lat, double *lon)
{
	// try
	{
		double central_meridian;
		double false_easting;
		double false_northing;

		central_meridian = 6 * zone - 183;
		false_easting = 5e5;

		if (southHemi)
		{
			false_northing = 100e5;
		}
		else
		{
			false_northing = 0;
		}

		TransverseMercator tm(Constants::WGS84_a(), Constants::WGS84_f(), Constants::UTM_k0());

		x -= false_easting;
		y -= false_northing;
		;

		tm.Reverse(central_meridian, x, y, *lat, *lon);
	}
	// catch (exception& e)
	// {
	// 	throw(GeographicErr(e.what()));
	// }
}

/**
*  \brief Convert Plane Coordinate(x, y) to Geodetic Coordinate(Lat, Lon)
*
*  \param [in] Origin_x_utm: x coordinate of utm origin point [unit: meter] 
*  \param [in] Origin_y_utm: y coordinate of utm origin point [unit: meter] 
*  \param [in] Origin_z_utm: z coordinate of utm origin point [unit: meter] 
*  \param [in] Heading: heading angle of the car [unit: degree]
*  \param [in] x_vehicle: x coordinate in vehicle coordinate system [unit: meter] 
*  \param [in] y_vehicle: y coordinate in vehicle coordinate system [unit: meter] 
*  \param [in] z_vehicle: z coordinate in vehicle coordinate system [unit: meter] 
*  \param [out] x_utm: x coordinate in utm  [unit: meter] 
*  \param [out] y_utm: y coordinate in utm [unit: meter] 
*  \param [out] z_utm: z coordinate in utm [unit: meter] 
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::vehicle2utm(const double &Origin_x_utm, const double &Origin_y_utm, const double &Origin_z_utm,
						   const double &Heading,
						   const double &x_vehicle, const double &y_vehicle, const double &z_vehicle,
						   double &x_utm, double &y_utm, double &z_utm)
{
	z_utm = Origin_z_utm - z_vehicle;

	double Temp_angle = 360.0 - Heading + 90.0;
	double Temp_angle_rat = Deg2Rad(Temp_angle);
	x_utm = Origin_x_utm + (x_vehicle * cos(Temp_angle_rat) - y_vehicle * sin(Temp_angle_rat));
	y_utm = Origin_y_utm + (x_vehicle * sin(Temp_angle_rat) + y_vehicle * cos(Temp_angle_rat));
}

/**
*  \brief Convert Plane Coordinate(x, y) to Geodetic Coordinate(Lat, Lon)
*
*  \param [in] Origin_x_utm: x coordinate of utm origin point [unit: meter] 
*  \param [in] Origin_y_utm: y coordinate of utm origin point [unit: meter] 
*  \param [in] Origin_z_utm: z coordinate of utm origin point [unit: meter] 
*  \param [in] Heading: heading angle of the car [unit: degree]
*  \param [in] In_x_utm: x coordinate of utm origin point [unit: meter] 
*  \param [in] In_y_utm: y coordinate of utm origin point [unit: meter] 
*  \param [in] In_z_utm: z coordinate of utm origin point [unit: meter] 
*  \param [out] Out_x_vehicle: x coordinate in vehicle coordinate system [unit: meter] 
*  \param [out] Out_y_vehicle: y coordinate in vehicle coordinate system [unit: meter] 
*  \param [out] Out_Z_vehicle: z coordinate in vehicle coordinate system [unit: meter] 
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::utm2vehicle(const double &Origin_x_utm, const double &Origin_y_utm, const double &dOrigin_z_utm,
						   const double &Heading,
						   const double &In_x_utm, const double &In_y_utm, const double &In_z_utm,
						   double &Out_x_vehicle, double &Out_y_vehicle, double &Out_z_vehicle)
{
	// Use trigonometric formula to calculate, if there is library, you can replace it.
	Out_z_vehicle = In_z_utm - dOrigin_z_utm;

	// x、y
	double Temp_dx = 0.0;
	double Temp_dy = 0.0;
	Temp_dx = In_x_utm - Origin_x_utm;
	Temp_dy = In_y_utm - Origin_y_utm;
	double Temp_angle = 360.0 - Heading + 90.0;
	double Temp_angle_rat = Deg2Rad(Temp_angle);

	// Formula prototype
	Out_x_vehicle = (Temp_dx * cos(Temp_angle_rat)) + (Temp_dy * sin(Temp_angle_rat));
	Out_y_vehicle = (Temp_dy * cos(Temp_angle_rat)) - (Temp_dx * sin(Temp_angle_rat));
}

void GeoPoint::VehicleToUtm_origin(const double& x_vehicle, const double& y_vehicle, const double& z_vehicle, 
								   				 const double& Heading,
								   				 const double& In_x_utm, const double& In_y_utm, const double& In_z_utm, 
								   				 double& origin_x_utm, double& origin_y_utm, double& origin_z_utm )
{
	  // Use trigonometric formula to calculate, if there is library, you can replace it.
	origin_z_utm = In_z_utm - z_vehicle;
    
	// x y
    double Temp_angle = 360.0-Heading+90.0;
    double Temp_angle_rat = Temp_angle / 180.0 * PI;
	origin_x_utm = In_x_utm - (x_vehicle * cos(Temp_angle_rat) - y_vehicle * sin(Temp_angle_rat));
	origin_y_utm = In_y_utm - (x_vehicle * sin(Temp_angle_rat) + y_vehicle * cos(Temp_angle_rat));
}

/**
*  \brief Convert enu to Vehicle coordinate
*
*  \param [in] e: x coordinate of enu [unit: meter] 
*  \param [in] n: y coordinate of enu [unit: meter] 
*  \param [in] u: z coordinate of enu [unit: meter] 
*  \param [in] pitch: pitch angle of the car [unit: degree]
*  \param [in] roll: roll angle of the car  [unit: degree] 
*  \param [in] yaw: yaw angle of the car  [unit: degree] 
*  \param [out] x: x coordinate of vehicle [unit: meter]
*  \param [out] y: y coordinate of vehicle [unit: meter]
*  \param [out] z: z coordinate of vehicle [unit: meter]
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::enu2vehicle(double e, double n, double u, double pitch, double roll, double yaw, double *x, double *y, double *z)
{
	Eigen::Matrix3d rotation = vehicle_T_enu_rotation(pitch, roll, yaw).inverse();

	Eigen::Vector3d v(e, n, u);

	Eigen::Vector3d result = (rotation * v).transpose();

	*x = result(0);
	*y = result(1);
	*z = result(2);
}

/**
*  \brief Convert Vehicle coordinate to enu
*
*  \param [in] x: x coordinate of vehicle [unit: meter]
*  \param [in] y: y coordinate of vehicle [unit: meter]
*  \param [in] z: z coordinate of vehicle [unit: meter]
*  \param [in] pitch: pitch angle of the car [unit: degree]
*  \param [in] roll: roll angle of the car  [unit: degree] 
*  \param [in] yaw: yaw angle of the car  [unit: degree] 
*  \param [out] e: x coordinate of enu [unit: meter] 
*  \param [out] n: y coordinate of enu [unit: meter] 
*  \param [out] u: z coordinate of enu [unit: meter] 
*  \return void
*  \date 16:26:22 2021/09/02
*/
void GeoPoint::vehicle2enu(double x, double y, double z, double pitch, double roll, double yaw, double *e, double *n, double *u)
{
	Eigen::Matrix3d rotation = vehicle_T_enu_rotation(pitch, roll, yaw);

	Eigen::Vector3d v(x, y, z);

	Eigen::Vector3d result = (rotation * v).transpose();

	*e = result(0);
	*n = result(1);
	*u = result(2);
}
#ifdef _MSC_VER
#	pragma endregion GeoPoint
#endif

#ifdef _MSC_VER
#	pragma region GeoPose
#endif
GeoPose::GeoPose()
{
}

GeoPose::GeoPose(const Eigen::Affine3d& ecef_pose)
{
  *this = ecef_pose;
}

GeoPose::GeoPose(const Eigen::Isometry3d& ecef_pose) { *this = ecef_pose; }

GeoPose::GeoPose(const Eigen::Quaterniond& enu_rotation, const GeoPoint& geo_pos) :
  GeoPoint(geo_pos),
  rotation_(enu_rotation)
{
}

GeoPose& GeoPose::operator=(const Eigen::Affine3d& ecef_pose)
{
  GeoPoint::operator =(ecef_pose.translation());
  rotation_ = ecef_T_enu_rotation(*this).transpose() * ecef_pose.rotation();
  return *this;
}

GeoPose& GeoPose::operator=(const Eigen::Isometry3d& ecef_pose)
{
  GeoPoint::operator=(ecef_pose.translation());
  rotation_ = ecef_T_enu_rotation(*this).transpose() * ecef_pose.linear();
  return *this;
}

void GeoPose::toECEF(Eigen::Isometry3d& ecef_pose) const
{
  ecef_pose.linear() = ecef_T_enu_rotation(*this) * rotation_;
  ecef_pose.translation() = GeoPoint::toECEF();
}

Eigen::Isometry3d GeoPose::toECEF() const
{
  Eigen::Isometry3d ecef_pose;
  toECEF(ecef_pose);
  return ecef_pose;
}
#ifdef _MSC_VER
#	pragma endregion GeoPose
#endif

} // namespace geographic_transform
