/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#include "GeographicLib/Geohash.hpp"
#include "GeographicLib/Geodesic.hpp"
#include <limits>
#include <iostream>
#include <cmath>

#include "geographic_transform/geo_rect.h"

namespace geographic_transform
{


GeoRect::GeoRect()
{
  clear();
}


void GeoRect::clear()
{
  lower_left_.latitude() = std::numeric_limits<double>::max();
  lower_left_.longitude() = std::numeric_limits<double>::max();
  lower_left_.elevation() = 0.0;
  upper_right_.latitude() = std::numeric_limits<double>::max();
  upper_right_.longitude() = std::numeric_limits<double>::max();
  upper_right_.elevation() = 0.0;
}


bool GeoRect::setCoords(const GeoPoint& lower_left, const GeoPoint& upper_right)
{
  if(!validCoords(lower_left, upper_right))
  {
    return false;
  }

  lower_left_ = lower_left;
  upper_right_ = upper_right;

  return true;
}


bool GeoRect::setCoordsFromGeohash(const std::string& geohash)
{
  GeoPoint lower_left, upper_right;
  geohashToCoords(geohash, lower_left, upper_right);
  return setCoords(lower_left, upper_right);
}


bool GeoRect::extendCoordsToContainPoint(const GeoPoint& geo_point)
{
  if(!valid())
  {
    return setCoords(geo_point, geo_point);
  }

  if(contains(geo_point))
  {
    return true;
  }

  if(!geo_point.valid())
  {
    return false;
  }

  double lonDiff = geo_point.longitude() - longitudeCenter();
  lonDiff -= (lonDiff >  180.0) ? 360.0 : 0.0;
  lonDiff += (lonDiff < -180.0) ? 360.0 : 0.0;

  if(lonDiff < - widthDegrees() / 2.0)
  {
    lower_left_.longitude() = geo_point.longitude();
  }
  else if(lonDiff > widthDegrees() / 2.0)
  {
    upper_right_.longitude() = geo_point.longitude();
  }

  double latDiff = geo_point.latitude() - latitudeCenter();

  if(latDiff < - heightDegrees() / 2.0)
  {
    lower_left_.latitude() = geo_point.latitude();
  }
  else if(latDiff > heightDegrees() / 2.0)
  {
    upper_right_.latitude() = geo_point.latitude();
  }

  return true;
}


std::string GeoRect::geohash(size_t geohash_length) const
{
  std::string geohash;
  coordsToGeohash(lower_left_, upper_right_, geohash_length, geohash);
  return geohash;
}


double GeoRect::widthDegrees() const
{
  double diff = upper_right_.longitude() - lower_left_.longitude();
  if(diff < 0.0)
    diff += 360.0;
  return diff;
}


double GeoRect::heightDegrees() const
{
  return upper_right_.latitude() - lower_left_.latitude();
}


double GeoRect::width() const
{
  return lower_left_.distance(GeoPoint(lower_left_.latitude(), upper_right_.longitude()));
}


double GeoRect::height() const
{
  return lower_left_.distance(GeoPoint(upper_right_.latitude(), lower_left_.longitude()));
}


GeoPoint GeoRect::center() const
{
  return GeoPoint(latitudeCenter(), longitudeCenter());
}


double GeoRect::latitudeCenter() const
{
  return (lower_left_.latitude() + upper_right_.latitude()) / 2.0;
}


double GeoRect::longitudeCenter() const
{
  double long2 = upper_right_.longitude();
  if(long2 < lower_left_.longitude())
    long2 += 360.0;

  double center = (lower_left_.longitude() + long2) / 2.0;
  if(center > 180.0)
    center -= 360.0;

  return center;
}


bool GeoRect::valid() const
{
  return validCoords(lower_left_, upper_right_);
}


bool GeoRect::contains(const GeoPoint& geo_point) const
{
  double lonDiff = geo_point.longitude() - longitudeCenter();
  lonDiff -= (lonDiff >  180.0) ? 360.0 : 0.0;
  lonDiff += (lonDiff < -180.0) ? 360.0 : 0.0;

  double latDiff = geo_point.latitude() - latitudeCenter();

  return fabs(lonDiff) < (widthDegrees() / 2.0) && fabs(latDiff) < (heightDegrees() / 2.0);
}


bool GeoRect::intersects(const GeoRect& other) const
{
  double lonDiff1 = other.lowerLeft().longitude() - upperRight().longitude();
  lonDiff1 -= (lonDiff1 >  180.0) ? 360.0 : 0.0;
  lonDiff1 += (lonDiff1 < -180.0) ? 360.0 : 0.0;
  //lonDiff1 = (lonDiff1 >  180.0) ? (360.0 - lonDiff1) : lonDiff1;
  //lonDiff1 = (lonDiff1 < -180.0) ? (360.0 + lonDiff1) : lonDiff1;

  double lonDiff2 = other.upperRight().longitude() - lowerLeft().longitude();
  lonDiff2 -= (lonDiff2 >  180.0) ? 360.0 : 0.0;
  lonDiff2 += (lonDiff2 < -180.0) ? 360.0 : 0.0;
  //lonDiff2 = (lonDiff2 >  180.0) ? (360.0 - lonDiff2) : lonDiff2;
  //lonDiff2 = (lonDiff2 < -180.0) ? (360.0 + lonDiff2) : lonDiff2;


  return !(lonDiff1 > 0.0 ||
           lonDiff2 < 0.0 ||
           other.lowerLeft().latitude() > upperRight().latitude() ||
           other.upperRight().latitude() < lowerLeft().latitude());

  //return !(other.longitude1() > longitude2() ||
  //         other.longitude2() < longitude1() ||
  //         other.latitude1() > latitude2() ||
  //         other.latitude2() < latitude1());
}


/*double GeoRect::centerDistance(const GeoRect& other) const
{
  return centerDistance(other.center());
}


double GeoRect::centerDistance(const GeoPoint& geo_point) const
{
  double dist;
  GeographicLib::Geodesic::WGS84().Inverse(latitudeCenter(), longitudeCenter(), lat, lon, dist);
  return dist;
}*/


double GeoRect::boundaryDistance(const GeoPoint& geo_point) const
{
  double lonDiff = geo_point.longitude() - longitudeCenter();
  lonDiff -= (lonDiff >  180.0) ? 360.0 : 0.0;
  lonDiff += (lonDiff < -180.0) ? 360.0 : 0.0;

  //double lonDiff = fabs(lon - longitudeCenter());
  //if(lonDiff > 180.0)
  //  lonDiff = fabs(lonDiff - 360.0);
  double dx = std::max(fabs(lonDiff) - widthDegrees() / 2.0, 0.0);
  double dy = std::max(fabs(geo_point.latitude() - latitudeCenter())  - heightDegrees() / 2.0, 0.0);

  return geo_point.distance(GeoPoint(geo_point.latitude() + dy, geo_point.longitude() + dx));
}


bool GeoRect::validCoords(const GeoPoint& lower_left, const GeoPoint& upper_right)
{
  // check if we got a valid latitude (north/south +-90) longitude (east/west +-180) GeoRectangle
  return ( lower_left.valid() && upper_right.valid() && lower_left.latitude() <= upper_right.latitude());
}


bool GeoRect::coordsToGeohash(const GeoPoint& lower_left, const GeoPoint& upper_right, size_t geohash_length, std::string& geohash)
{
  if(!validCoords(lower_left, upper_right))
  {
    return false;
  }

  geohash.reserve(2 * geohash_length + 1);
  std::string geohash2;

  // add/subtract lat-long resolution to yield the bounding geohashes
  double latRes = GeographicLib::Geohash::LatitudeResolution((int)geohash_length) / 2.0;
  double longRes = GeographicLib::Geohash::LongitudeResolution((int)geohash_length) / 2.0;

  GeographicLib::Geohash::Forward(lower_left.latitude() - latRes, lower_left.longitude() - longRes, (int)geohash_length, geohash);
  GeographicLib::Geohash::Forward(upper_right.latitude() + latRes, upper_right.longitude() + longRes, (int)geohash_length, geohash2);

  if(geohash == geohash2)
  {
    //X_WARN("GeoRect::coordsToGeohash: Geohashes equal.");
  }
  geohash += "-" + geohash2;
  return true;
}


bool GeoRect::geohashToCoords(const std::string& GeoRect_geohash, GeoPoint& lower_left, GeoPoint& upper_right)
{
  size_t geohash_length = GeoRect_geohash.find_first_of('-');
  size_t total_length = GeoRect_geohash.find_last_of('-');

  // handle case when we do not have the second '-'
  if(total_length == geohash_length)
    total_length = GeoRect_geohash.length();

  // check if we have two equally long geohashes on each side of the (first) dash
  if(GeoRect_geohash.empty() || ((total_length - 1) % 2) != 0  || geohash_length != (total_length - 1) / 2)
  {
    return false;
  }

  std::string geohash1, geohash2;
  geohash1 = GeoRect_geohash.substr(0, geohash_length);
  geohash2 = GeoRect_geohash.substr(geohash_length + 1, geohash_length);

  try
  {
    int length;
    GeographicLib::Geohash::Reverse(geohash1, lower_left.latitude(), lower_left.longitude(), length);
    GeographicLib::Geohash::Reverse(geohash2, upper_right.latitude(), upper_right.longitude(), length);
  }
  catch(GeographicLib::GeographicErr& e)
  {
    return false;
  }

  lower_left.elevation() = 0.0;
  upper_right.elevation() = 0.0;

  return validCoords(lower_left, upper_right);
}


} // namespace geographic_transform
