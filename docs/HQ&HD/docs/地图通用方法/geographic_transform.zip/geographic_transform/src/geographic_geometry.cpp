#include "geographic_transform/geographic_geometry.h"
#include "geographic_transform/geographic_transform.h"

using namespace std;

namespace geographic_transform
{

CGeographicGeometry::CGeographicGeometry()
{    

}

CGeographicGeometry::~CGeographicGeometry()
{

}

// 计算新增输入点
bool CGeographicGeometry::CaclPointByVehiclePointsAndOffsets(const int32_t              *vehicle_pts_offset,
                                                      const zone::common::Point  *vehicle_pts,
                                                      uint32_t                    vehicle_pts_num,
                                                      int32_t                     point_offset,
                                                      zone::common::Point        &point,
                                                      int32_t                    &index,
                                                      bool                       &is_origin,
                                                      bool                       start_flag)
{
  is_origin = false;
  index     = -1;
  if (nullptr == vehicle_pts)
  {
      //HDM_ERROR("CGeographicGeometry::CaclPointByVehiclePointsAndOffsets", "vehicle_pts is nullptr");
      return false;
  }

  if (vehicle_pts_num <= 1) {
      //HDM_ERROR("CGeographicGeometry::CaclPointByVehiclePointsAndOffsets", "vehicle_pts_num[%d] <= 1. \n", vehicle_pts_num);
      return false;
  }

  // 不在区域内, 在第一个点的后面
  if (point_offset < vehicle_pts_offset[0]) {
    index     = 0;
    point     = vehicle_pts[0];
    is_origin = true;
    if (point_offset < vehicle_pts_offset[0]) {
      //HDM_WARNING("CGeographicGeometry::CaclPointByVehiclePointsAndOffsets", "point_offset=%d less then vehicle_pts_offset[0]=%d.\n",
      //    point_offset, vehicle_pts_offset[0]);
    }
    return true;
  }

  // 不在区域内, 在最后一个点的前方
  if (point_offset > vehicle_pts_offset[vehicle_pts_num - 1]) {
    index     = vehicle_pts_num - 1;
    point     = vehicle_pts[vehicle_pts_num - 1];
    is_origin = true;
    if (point_offset < vehicle_pts_offset[0]) {
      //HDM_WARNING("CGeographicGeometry::CaclPointByVehiclePointsAndOffsets", "point_offset=%d less then vehicle_pts_offset[-1]=%d.\n",
      //    point_offset, vehicle_pts_offset[vehicle_pts_num - 1]);
    }
    return true;
  }

  // 在区域内
  for (uint32_t i = 0; i < vehicle_pts_num; i++) {
      if (point_offset == vehicle_pts_offset[i]) {
        point     = vehicle_pts[i];
        index     = i;
        is_origin = true;
        break;
      }
      else if (point_offset < vehicle_pts_offset[i]) {
        int32_t remain_offset    = point_offset - vehicle_pts_offset[i - 1];
        int32_t two_point_offset = vehicle_pts_offset[i] - vehicle_pts_offset[i-1];
        point.x = vehicle_pts[i-1].x + (vehicle_pts[i].x - vehicle_pts[i-1].x) * remain_offset / two_point_offset;
        point.y = vehicle_pts[i-1].y + (vehicle_pts[i].y - vehicle_pts[i-1].y) * remain_offset / two_point_offset;
        index      = i - 1;
        is_origin  = false;
        break;
      }
      else {
        // 比该点大, 在该点的前方, 继续找下个点
      }
  }

  /* 修正start_offset的位置
   * offset可能存在重复: [10, 10, 20, 30, 40, 50, 50, 60, 70]
   * index对应的offset和index+1对应offset相等，index = index + 1
   */
  if (start_flag && (index >= 0)) {
    int32_t offset = vehicle_pts_offset[index];
    for (int i = index + 1; (i < static_cast<int>(vehicle_pts_num)) && (offset == vehicle_pts_offset[i]); ++i) {
      //HDM_INFO("CGeographicGeometry::CaclPointByVehiclePointsAndOffsets", "start offset[%d], start index[%d].\n", offset, index);
      index += 1;
      point = vehicle_pts[index];
    }
  }
  return (index >= 0) ? true : false;
}

/**
 * 根据start_offset和end_offset，切割它俩之间的的所有形状点，
 * 如果start_offset不在形状点列内，要把start_offset对应的点加入起点，
 * 如果end_offset不在形状点列内，要把start_offset对应的点加入终点。
 */
bool CGeographicGeometry::SplitVehiclePoints(const int32_t             *vehicle_pts_offset,  // 输入坐标点偏移
                                      const zone::common::Point *vehicle_pts,         // 输入坐标点
                                      uint32_t                   vehicle_pts_num,     // 输入坐标点数目                                    
                                      int32_t                    start_offset,        // 切割的开始offset，单位厘米，相对自车位置
                                      int32_t                    end_offset,          // 切割的终止offset，单位厘米，相对自车位置                                     
                                      std::vector<zone::common::Point> &split_vehicle_pts)
{
    std::vector<int32_t>      split_vehicle_pts_offset;
    return SplitVehiclePoints(vehicle_pts_offset,
                              vehicle_pts,
                              vehicle_pts_num,
                              start_offset, 
                              end_offset,
                              split_vehicle_pts_offset,
                              split_vehicle_pts);
}

/**
 * 根据start_offset和end_offset，切割所有之前的所有形状点，
 * 如果start_offset不在形状点列内，要把start_offset对应的点加入起点，
 * 如果end_offset不在形状点列内，要把start_offset对应的点加入终点。
 */
bool CGeographicGeometry::SplitVehiclePoints(const int32_t             *vehicle_pts_offset,
                                      const zone::common::Point *vehicle_pts,
                                      uint32_t                   vehicle_pts_num,
                                      int32_t                    start_offset, 
                                      int32_t                    end_offset,
                                      std::vector<int32_t>      &split_vehicle_pts_offset,
                                      std::vector<zone::common::Point> &split_vehicle_pts)
{
    // TODO(hcz): test log
    // HDM_WRITE("to_em_data1.txt", "CGeographicGeometry::SplitVehiclePoints, vehicle_pts_num: %d, start_offset: %d, end_offset: %d.\n",
    //           vehicle_pts_num, start_offset, end_offset);
    // HDM_WRITE("to_em_data1.txt", "CGeographicGeometry::SplitVehiclePoints, vehicle_pts_offset, ");
    // for (int i = 0; i < vehicle_pts_num; ++i) {
    //     HDM_WRITE("to_em_data1.txt", "%d : %d, ", i, vehicle_pts_offset[i]);
    // }
    // HDM_WRITE("to_em_data1.txt", "\n");

    // HDM_WRITE("to_em_data1.txt", "CGeographicGeometry::SplitVehiclePoints, vehicle_pts, ");
    // for (int i = 0; i < vehicle_pts_num;  ++i) {
    //     HDM_WRITE("to_em_data1.txt", "%d : [%lf, %lf], ", i, vehicle_pts[i].x, vehicle_pts[i].y);
    // }
    // HDM_WRITE("to_em_data1.txt", "\n");

    zone::common::Point  start_point{};
    int32_t              start_index     = -1;
    bool                 start_is_origin = false;
    if ((nullptr == vehicle_pts_offset) || (nullptr == vehicle_pts)) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_offset is nulptr, or vehicle_pts is nulptr.\n");
      return false; 
    }
    if (0 >= vehicle_pts_num) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_offset is empty. vehicle_pts_num[%d]\n", vehicle_pts_num);
      return false;
    }
    if (start_offset >= end_offset) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "param error: start_offset[%d] >= end_offset[%d]", start_offset, end_offset);
      return true;
    }
    // 整体不在范围内
    if ((start_offset > vehicle_pts_offset[vehicle_pts_num - 1]) || 
        (end_offset < vehicle_pts_offset[0])) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "Not in the range. start_offset=%d, end_offset=%d, vehicle_pts_offset[0]=%d, vehicle_pts_offset[-1]=%d\n",
      //    start_offset, end_offset, vehicle_pts_offset, vehicle_pts_offset);
      return false;
    }
    if (!CaclPointByVehiclePointsAndOffsets(vehicle_pts_offset, vehicle_pts, vehicle_pts_num, start_offset, 
                                            start_point, start_index, start_is_origin, true)) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "Cacl start_offset failed!!!");
      return false;
    }

    zone::common::Point       end_point{};
    int32_t                   end_index      = -1;
    bool                      end_is_origin  = false;
    if (!CaclPointByVehiclePointsAndOffsets(vehicle_pts_offset, vehicle_pts, vehicle_pts_num, end_offset,
                                            end_point, end_index, end_is_origin, false)) {
      //HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "Cacl end_fffset failed!!!");
      return false;
    }

    if ((start_index < 0) || (start_index >= static_cast<int>(vehicle_pts_num)) ||
        (end_index >= static_cast<int>(vehicle_pts_num)) || (end_index < 0)) {
        ///HDM_ERROR("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_num[%d] start_index[%d], end_index[%d]\n",
        //          vehicle_pts_num, start_index, end_index);
        return false;
    }

    // HDM_INFO("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_num[%d] start_index[%d], end_index[%d], start_offset[%d], end_offset[%d]\n",
    //          vehicle_pts_num, start_index, end_index, start_offset, end_offset);
    // for (size_t i = 0; i < vehicle_pts_num; ++i) {
    //   HDM_INFO("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_offset[%d] = [%d]\n", i, vehicle_pts_offset[i]);
    // }
    // if (end_index < start_index) {
    //     HDM_INFO("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_num[%d] start_index[%d], end_index[%d], start_offset[%d], end_offset[%d]\n",
    //         vehicle_pts_num, start_index, end_index, start_offset, end_offset);
    //     for (size_t i = 0; i < vehicle_pts_num; ++i) {
    //       HDM_INFO("CGeographicGeometry::SplitVehiclePoints", "vehicle_pts_offset[%d] = [%d]\n", i, vehicle_pts_offset[i]);
    //     }
    // }

    split_vehicle_pts_offset.reserve(end_index - start_index + 2);
    split_vehicle_pts.reserve(end_index - start_index + 2);

    split_vehicle_pts_offset.push_back(start_offset);
    split_vehicle_pts.push_back(start_point);
    
    int32_t end = (end_index == static_cast<int>(vehicle_pts_num)) ? end_index : end_index + 1;
    for (int32_t i = (start_index + 1); i < end; i++) {
        split_vehicle_pts_offset.push_back(vehicle_pts_offset[i]);
        split_vehicle_pts.push_back(vehicle_pts[i]);
        
    }
    if (!end_is_origin) { // end_point不和原始点重合
        split_vehicle_pts_offset.push_back(end_offset);
        split_vehicle_pts.push_back(end_point);
    }

    // TODO(hcz): test log
    // HDM_WRITE("to_em_data1.txt", "CGeographicGeometry::SplitVehiclePoints, split_vehicle_pts_offset, ");
    // for (int i = 0; i < split_vehicle_pts.size(); ++i) {
    //     HDM_WRITE("to_em_data1.txt", "%d : %d, ", i, split_vehicle_pts_offset[i]);
    // }
    // HDM_WRITE("to_em_data1.txt", "\n");

    // HDM_WRITE("to_em_data1.txt", "CGeographicGeometry::SplitVehiclePoints, split_vehicle_pts, ");
    // for (int i = 0; i < split_vehicle_pts.size(); ++i) {
    //     HDM_WRITE("to_em_data1.txt", "%d : [%lf, %lf], ", i, split_vehicle_pts[i].x, split_vehicle_pts[i].y);
    // }
    // HDM_WRITE("to_em_data1.txt", "\n");
    return true;
}

}