/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2020 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.

/    Date: 2021-8-17
/    Author: tang shaohua
/------------------------------------------------------------------------------
*******************************************************************************/

#ifndef _GEOGRAPHIC_GEOMETRY_H_
#define _GEOGRAPHIC_GEOMETRY_H_

#include <vector>
#include "common/data/zone_shared_data.h"


namespace geographic_transform
{	

class CGeographicGeometry {
public:
    CGeographicGeometry();
    ~CGeographicGeometry();

    
    static bool CaclPointByVehiclePointsAndOffsets(const int32_t  *vehicle_pts_offset,  // 输入坐标点偏移
                                        const zone::common::Point       *vehicle_pts,   // 输入坐标点
                                        uint32_t                   vehicle_pts_num,     // 输入坐标点数目
                                        int32_t                    point_offset,        // 要计算的点的距离
                                        zone::common::Point             &point,         // 要计算的点
                                        int32_t                   &index,               // 计算点的前一个原始点的索引
                                        bool                      &is_origin,           // 计算点是否就是原始点
                                        bool                      start_flag=true);     // true: start, false: end

    /**
     * @brief 根据start_offset和end_offset，切割所有之前的所有形状点，
     * 如果start_offset不在形状点列内，要把start_offset对应的点加入起点，
     * 如果end_offset不在形状点列内，要把start_offset对应的点加入终点。
     * 
     * @param vehicle_pts_offset 输入坐标点偏移
     * @param vehicle_pts 输入坐标点
     * @param vehicle_pts_num 输入坐标点数目
     * @param start_offset 切割的开始offset，单位厘米，相对自车位置
     * @param end_offset 切割的终止offset，单位厘米，相对自车位置
     * @param split_vehicle_pts 输出点列
     * @return true 
     * @return false 
     */
    static bool SplitVehiclePoints(const int32_t             *vehicle_pts_offset, // 输入坐标点偏移
                                   const zone::common::Point *vehicle_pts,        // 输入坐标点
                                   uint32_t                   vehicle_pts_num,    // 输入坐标点数目
                                   int32_t                    start_offset,       // 切割的开始offset，单位厘米，相对自车位置
                                   int32_t                    end_offset,         // 切割的终止offset，单位厘米，相对自车位置
                                   std::vector<zone::common::Point> &split_vehicle_pts); // 输出点列
 
    /**
     * @brief 根据start_offset和end_offset，切割所有之前的所有形状点，
     * 如果start_offset不在形状点列内，要把start_offset对应的点加入起点，
     * 如果end_offset不在形状点列内，要把start_offset对应的点加入终点。
     * 
     * @param vehicle_pts_offset 输入坐标点偏移
     * @param vehicle_pts 输入坐标点
     * @param vehicle_pts_num 输入坐标点数目
     * @param start_offset 切割的开始offset，单位厘米，相对自车位置
     * @param end_offset 切割的终止offset，单位厘米，相对自车位置
     * @param split_vehicle_pts_offset 输出点列对应的offset
     * @param split_vehicle_pts 输出点列
     * @return true 
     * @return false 
     */
    static bool SplitVehiclePoints(const int32_t             *vehicle_pts_offset,
                                   const zone::common::Point *vehicle_pts,
                                   uint32_t                   vehicle_pts_num,
                                   int32_t                    start_offset, 
                                   int32_t                    end_offset,
                                   std::vector<int32_t>      &split_vehicle_pts_offset,
                                   std::vector<zone::common::Point> &split_vehicle_pts);
};

}

#endif  // _CHDM_GEOMETRY_H_	
