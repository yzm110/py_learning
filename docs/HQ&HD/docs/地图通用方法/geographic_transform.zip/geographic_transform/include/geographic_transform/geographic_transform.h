/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#ifndef GEOGRAPHIC_TRANSFORM_GEOGRAPHIC_TRANSFORM_H
#define GEOGRAPHIC_TRANSFORM_GEOGRAPHIC_TRANSFORM_H

#include <Eigen/Geometry>

namespace geographic_transform
{

class GeoPoint;

class ECEFPoint : public Eigen::Vector3d
{
public:
  ECEFPoint();
  ECEFPoint(double x, double y, double z);
  ECEFPoint(const Eigen::Vector3d& ecef_point);
  ECEFPoint(const GeoPoint& geo_point);

  ECEFPoint& operator=(const Eigen::Vector3d& ecef_point);
  ECEFPoint& operator=(const GeoPoint& geo_point);
};


class GeoPoint
{
public:
  GeoPoint();
  GeoPoint(double lat, double lon, double ele = 0.0);
  GeoPoint(const Eigen::Vector3d& ecef_point);

  GeoPoint& operator=(const Eigen::Vector3d& ecef_point);

  const double& latitude() const { return latitude_; }
  double& latitude() { return latitude_; }

  const double& longitude() const { return longitude_; }
  double& longitude() { return longitude_; }

  const double& elevation() const { return elevation_; }
  double& elevation() { return elevation_; }

  void toECEF(Eigen::Vector3d& ecef_point) const;
  Eigen::Vector3d toECEF() const;

  bool valid() const;

  double distance(const GeoPoint& geo_point) const;

  // computes the offset of this point to the other point (in meters)
  // dx is the east offset and dy is the north offset
  void offsetOnGeoid(const GeoPoint& other, double& dx, double& dy) const;

  // moves this point on the geoid by the specified deltas (in meters)
  // dx moves east, dy moves north and dz moves up
  GeoPoint& moveOnGeoid(double dx, double dy, double dz = 0.0);

  // moves a copy of this point on the geoid by the specified deltas (in meters)
  // dx moves east, dy moves north and dz moves up
  GeoPoint moveCopyOnGeoid(double dx, double dy, double dz = 0.0) const;

  // convert wgs84 coordinate to gcjo2 coordinate (in degree)
  void Wgs84LatLon_2_Gcj02LatLon(GeoPoint wgs84, GeoPoint* gcj02);
  
  // convert gcj02 coordinate to wgs84 coordinate
  void Gcj02LatLon_2_Wgs84LatLon(GeoPoint gcj02, GeoPoint* wgs84); 

  // convert geodetic coordinate to plane coordinate
  void lla2utm(double lat, double lon, bool southHemi, double* x, double* y);

  // convert plane coordinate to geodetic coordinate
  void utm2lla(int zone, bool southHemi, double x, double y, double* lat, double* lon);

  // convert vehicle body coordinate to utm coordinate
  void vehicle2utm(const double& Origin_x_utm, const double& Origin_y_utm, const double& Origin_z_utm, 
								   const double& Heading,
								   const double& x_vehicle, const double& y_vehicle, const double& z_vehicle, 
								   double& x_utm, double& y_utm, double& z_utm);
  
  // convert utm coordinate to vehicle body coordinate
  void utm2vehicle(const double& Origin_x_utm, const double& Origin_y_utm, const double& Origin_z_utm, 
					         const double& Heading,
					         const double& In_x_utm, const double& In_y_utm, const double& In_z_utm, 
					         double& Out_x_vehicle, double& Out_y_vehicle, double& Out_z_vehicle);

  void VehicleToUtm_origin(const double& x_vehicle, const double& y_vehicle, const double& z_vehicle, 
								   				 const double& 	Heading,
								   				 const double&	In_x_utm, const double& In_y_utm, const double& In_z_utm, 
								   				 double& origin_x_utm, double& origin_y_utm, double& origin_z_utm );

  void enu2vehicle(double e, double n, double u, double pitch, double roll, double yaw, double* x, double*y, double*z);

  void vehicle2enu(double x, double y, double z, double pitch, double roll, double yaw, double* e, double*n, double*u);

private:
  double latitude_;
  double longitude_;
  double elevation_;
};


class GeoPose : public GeoPoint
{
public:
  GeoPose();
  GeoPose(const Eigen::Affine3d& ecef_pose);
  GeoPose(const Eigen::Isometry3d& ecef_pose);
  GeoPose(const Eigen::Quaterniond& enu_rotation, const GeoPoint& geo_pos);

  GeoPose& operator=(const Eigen::Affine3d& ecef_pose);
  GeoPose& operator=(const Eigen::Isometry3d& ecef_pose);

  const Eigen::Quaterniond& rotation() const {return rotation_; }
  Eigen::Quaterniond& rotation() {return rotation_; }

  void toECEF(Eigen::Isometry3d& ecef_pose) const;
  Eigen::Isometry3d toECEF() const;

private:
  Eigen::Quaterniond rotation_;
};


/// Writes the 3D rotation matrix from the local ENU frame at geo_pos to ECEF into ecef_T_local_enu
/// e.g.:
/// ecef_T_enu_rotation(local_enu_origin, ecef_T_local_enu)
/// rot_ecef = ecef_T_local_enu * rot_local_enu;
template <typename MatrixType>
void ecef_T_enu_rotation(const GeoPoint& geo_pos, MatrixType& ecef_T_local_enu)
{
  double
      phi = geo_pos.latitude() * 3.1415926535897932384626433832795028 / 180.0,
      sphi = std::sin(phi),
      cphi = std::cos(phi),
      lam = geo_pos.longitude() * 3.1415926535897932384626433832795028 / 180.0,
      slam = std::sin(lam),
      clam = std::cos(lam);

  // This rotation matrix is given by the following quaternion operations
  // qrot(lam, [0,0,1]) * qrot(phi, [0,-1,0]) * [1,1,1,1]/2
  // or
  // qrot(pi/2 + lam, [0,0,1]) * qrot(-pi/2 + phi , [-1,0,0])
  // where
  // qrot(t,v) = [cos(t/2), sin(t/2)*v[1], sin(t/2)*v[2], sin(t/2)*v[3]]

  // Local X axis (east) in geocentric coords
  ecef_T_local_enu(0, 0) = -slam;        ecef_T_local_enu(1, 0) =  clam;        ecef_T_local_enu(2, 0) = 0.0;
  // Local Y axis (north) in geocentric coords
  ecef_T_local_enu(0, 1) = -clam * sphi; ecef_T_local_enu(1, 1) = -slam * sphi; ecef_T_local_enu(2, 1) = cphi;
  // Local Z axis (up) in geocentric coords
  ecef_T_local_enu(0, 2) =  clam * cphi; ecef_T_local_enu(1, 2) =  slam * cphi; ecef_T_local_enu(2, 2) = sphi;
}

template <typename MatrixType>
void vehicle_T_enu_rotation(const double& pitch, const double& roll, const double& yaw, MatrixType& vehicle_T_enu)
{
    double pitch_rad=pitch * 3.1415926535897932384626433832795028 / 180.0;
    double roll_rad=roll * 3.1415926535897932384626433832795028 / 180.0;
    double yaw_rad=yaw * 3.1415926535897932384626433832795028 / 180.0;
    
    Eigen::Matrix3d matP;
    Eigen::Matrix3d matR;
    Eigen::Matrix3d matA;

    double sinP = sin(pitch_rad);
    double cosP = cos(pitch_rad);
    matP(0,0) = 1;      matP(1,0) = 0;       matP(2,0) = 0;
    matP(0,1) = 0;      matP(1,1) = cosP;    matP(2,1) = sinP;
    matP(0,2) = 0;      matP(1,2) = -sinP;   matP(2,2) = cosP;

    double sinR = sin(roll_rad);
    double cosR = cos(roll_rad);
    matR(0,0) = cosR;   matR(1,0) = 0;       matR(2,0) = -sinR;
    matR(0,1) = 0;      matR(1,1) = 1;       matR(2,1) = 0;
    matR(0,2) = sinR;   matR(1,2) = 0;       matR(2,2) = cosR;

    double sinA = sin(yaw_rad);
    double cosA = cos(yaw_rad);
    matA(0,0) = cosA;   matA(1,0) = -sinA;   matA(2,0) = 0;
    matA(0,1) = sinA;   matA(1,1) = cosA;    matA(2,1) = 0;
    matA(0,2) = 0;      matA(1,2) = 0;       matA(2,2) = 1;

    vehicle_T_enu =  matA * ( matP * matR );
}


/// Returns the 3D rotation matrix from the local ENU frame at geo_pos to ECEF
/// e.g.:
/// rot_ecef = ecef_T_enu_rotation(local_enu_origin) * rot_local_enu;
inline Eigen::Matrix3d ecef_T_enu_rotation(const GeoPoint& geo_pos)
{
  Eigen::Matrix3d ecef_T_local_enu;
  ecef_T_enu_rotation(geo_pos, ecef_T_local_enu);
  return ecef_T_local_enu;
}

/// Returns the 3D rotation matrix from the local ENU frame to vehicle body
inline Eigen::Matrix3d vehicle_T_enu_rotation(const double& pitch, const double& roll, const double& yaw)
{
  Eigen::Matrix3d vehicle_T_enu;
  vehicle_T_enu_rotation(pitch,roll, yaw, vehicle_T_enu);
  return vehicle_T_enu;
}

} //namespace geographic_transform

#endif // GEOGRAPHIC_TRANSFORM_GEOGRAPHIC_TRANSFORM_H
