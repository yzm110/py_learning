/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#ifndef GEOGRAPHIC_TRANSFORM_RECT_H
#define GEOGRAPHIC_TRANSFORM_RECT_H

#include "geographic_transform.h"
#include <string>


namespace geographic_transform
{

/// \brief A rectangle class for geographic bounding boxes in latitude-longitude degrees (elevation is ignored).
/// The upper left corner of the rect is stored in point 1, the lower right in pount 2.
/// Rects that span the poles are not allowed, leading for valid() to return false.
class GeoRect
{
public:
  /// \brief Creates a cleared rect. Before one of the setCoords variants is called, the rect is not valid.
  GeoRect();

  /// \brief Trivial virtual destructor.
  virtual ~GeoRect() {}

  /// \brief Clears the rect. After this, the rect is not valid.
  void clear();

  /// \brief Sets the rect coordinates to the given latitude longitude values (in degrees). Returns true if the rect is valid.
  bool setCoords(const GeoPoint& lower_left, const GeoPoint& upper_right);

  /// \brief Sets the rect coordinates to the latitude longitude (in degrees) corresponding to the given geohash. Returns true if the rect/geohash is valid.
  bool setCoordsFromGeohash(const std::string& geohash);

  /// \brief Extends the rect coordinates so that they contain the given point.
  bool extendCoordsToContainPoint(const GeoPoint& geo_point);

  /// \brief Retruns whether the rect is valid (and initialized) in terms of latitude longitude range
  bool valid() const;

  /// \brief Returns the geohash with the given length if the rect is valid, otherwise the empty string.
  std::string geohash(size_t geohash_length) const;

  const GeoPoint& lowerLeft() const { return lower_left_; }
  const GeoPoint& upperRight() const { return upper_right_; }
  GeoPoint center() const;
  double latitudeCenter() const;
  double longitudeCenter() const;
  double widthDegrees() const;
  double heightDegrees() const;
  double width() const;
  double height() const;


  /// \brief Indicates whether the given location is contained in the rect
  bool contains(const GeoPoint& geo_point) const;

  /// \brief Indicates whether the given rect intersects the rect
  bool intersects(const GeoRect& other) const;

  /// \brief Calculates the distance between this and the other rect. This is just the rect-center-to-rect-center distance.
  //double centerDistance(const Rect& other) const;

  /// \brief Calculates the distance between the center of this rect and the given coordinates.
  //double centerDistance(const GeoPoint& geo_point) const;

  /// \brief Calculates the distance from the boundary of this rect to a point.
  double boundaryDistance(const GeoPoint& geo_point) const;

  /// \brief Returns whether the given rect coordinates are valid in terms of latitude longitude range (expects degrees).
  /// Rects that span the poles are not allowed.
  static bool validCoords(const GeoPoint& lower_left, const GeoPoint& upper_right);

  /// \brief Returns true and the geohash with the given length if the rect coordinates are valid (expects degrees), otherwise false.
  static bool coordsToGeohash(const GeoPoint& lower_left, const GeoPoint& upper_right, size_t geohash_length, std::string& geohash);

  /// \brief Returns true and the rect coordinates (in degrees) that correspond to the given geohash if it is valid, otherwise false.
  static bool geohashToCoords(const std::string& geohash, GeoPoint& lower_left, GeoPoint& upper_right);

private:
  GeoPoint lower_left_; ///< top-left corner of the rect in longitude, latitude [degrees]
  GeoPoint upper_right_; ///< bottom-right corner of the rect in longitude, latitude [degrees]
};


} // namespace geographic_transform


#endif // GEOGRAPHIC_TRANSFORM_RECT_H
