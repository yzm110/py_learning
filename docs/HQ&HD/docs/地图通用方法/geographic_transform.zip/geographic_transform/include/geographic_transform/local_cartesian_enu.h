/******************************************************************************
/                              Copyright
/------------------------------------------------------------------------------
/    Copyright © 2021 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
/
/    This software is furnished under a license and may be used and copied
/    only in accordance with the terms of such license and with the inclusion
/    of the above copyright notice. This software or any other copies thereof
/    may not be provided or otherwise made available to any other person.
/    No title to and ownership of the software is hereby transferred.
/
/    The information in this software is subject to change without notice
/    and should not be constructed as a commitment by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
/    or reliability of its Software on equipment which is not supported by
/    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
/------------------------------------------------------------------------------
*******************************************************************************/
#ifndef GEOGRAPHIC_TRANSFORM_LOCAL_CARTESIAN_ENU_H
#define GEOGRAPHIC_TRANSFORM_LOCAL_CARTESIAN_ENU_H

#include "geographic_transform.h"

namespace geographic_transform
{

class LocalCartesianENU
{
public:
  LocalCartesianENU();
  LocalCartesianENU(const Eigen::Vector3d& local_frame_origin_ecef);
  LocalCartesianENU(const GeoPoint& local_frame_origin_);


  void setLocalFrameOrigin(const Eigen::Vector3d& local_origin_ecef);
  void setLocalFrameOrigin(const GeoPoint& local_origin);

  const Eigen::Isometry3d& ecefTransformFromLocalFrame() const { return ecef_T_local_enu_; }
  Eigen::Vector3d localFrameOriginECEF() const { return ecef_T_local_enu_.translation(); }
  const GeoPoint& localFrameOrigin() const { return local_frame_origin_; }

  void fromLatLong(const GeoPoint& geo_point, Eigen::Vector3d& local_point) const;
  Eigen::Vector3d fromLatLong(const GeoPoint& geo_point) const;  
  void fromLatLong(const GeoPose& geo_pose, Eigen::Isometry3d& local_pose) const;
  Eigen::Isometry3d fromLatLong(const GeoPose& geo_pose) const;

  void fromECEF(const Eigen::Vector3d& ecef_point, Eigen::Vector3d& local_point) const;
  Eigen::Vector3d fromECEF(const Eigen::Vector3d& ecef_point) const;
  void fromECEF(const Eigen::Isometry3d& ecef_pose, Eigen::Isometry3d& local_pose) const;
  Eigen::Isometry3d fromECEF(const Eigen::Isometry3d& ecef_pose) const;

  void toLatLong(const Eigen::Vector3d& local_point, GeoPoint& geo_point) const;
  GeoPoint toLatLong(const Eigen::Vector3d& local_point) const;
  void toLatLong(const Eigen::Isometry3d& local_pose, GeoPose& geo_pose) const;
  GeoPose toLatLong(const Eigen::Isometry3d& local_pose) const;

  void toECEF(const Eigen::Vector3d& local_point, Eigen::Vector3d& ecef_point) const;
  Eigen::Vector3d toECEF(const Eigen::Vector3d& local_point) const;
  void toECEF(const Eigen::Isometry3d& local_pose, Eigen::Isometry3d& ecef_pose) const;
  Eigen::Isometry3d toECEF(const Eigen::Isometry3d& local_pose) const;

protected:
  Eigen::Isometry3d ecef_T_local_enu_;
  GeoPoint local_frame_origin_;
};

} // namespace geographic_transform

#endif // GEOGRAPHIC_TRANSFORM_LOCAL_CARTESIAN_ENU_H
