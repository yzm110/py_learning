###############################################################################
#                              Copyright
#------------------------------------------------------------------------------
#    Copyright © 2023 SAIC MOTOR Z-ONE SOFTWARE COMPANY.  All rights reserved.
#
#    This software is furnished under a license and may be used and copied
#    only in accordance with the terms of such license and with the inclusion
#    of the above copyright notice. This software or any other copies thereof
#    may not be provided or otherwise made available to any other person.
#    No title to and ownership of the software is hereby transferred.
#
#    The information in this software is subject to change without notice
#    and should not be constructed as a commitment by
#    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
#
#    SAIC MOTOR Z-ONE SOFTWARE COMPANY assumes no responsibility for the use
#    or reliability of its Software on equipment which is not supported by
#    SAIC MOTOR Z-ONE SOFTWARE COMPANY.
#------------------------------------------------------------------------------
###############################################################################
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := libgeographic_transform
LOCAL_MODULE_CLASS := CMAKE
LOCAL_CPPFLAGS := -ffast-math -use_fast_math -pthread -fexceptions
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/include
LOCAL_SHARED_LIBRARIES := libcommon libGeographic

LOCAL_INCREMENTAL_FLAGS := true

LOCAL_CONFIG_FLAGS := -DZONE_ROS2=OFF -DBUILD_SHARED_LIBS=ON 

LOCAL_PREFIX                    := /usr/app
LOCAL_BUILT_SHARED_LIBRARIES    := libgeographic_transform.so
LOCAL_EXPORT_C_INCLUDE_DIRS     := $(LOCAL_PATH)/include
LOCAL_EXPORT_STATIC_LIBRARIES   := eigen
#LOCAL_EXPORT_CMAKE_CONFIG_DIRS := $$<PREFIX>

include $(BUILD_EXTERNAL_PROJECT)


# 
# LOCAL_PATH := $(call my-dir)
# 
# include $(CLEAR_VARS)
# 
# LOCAL_MODULE := libgeographic_transform
# 
# LOCAL_MODULE_CLASS := SHARED_LIBRARIES
# #for AngleToTorqueContorllerComponent::GetOutput NO RETURN TYPE
# LOCAL_CPPFLAGS := -ffast-math -use_fast_math -pthread -fexceptions
# 
# # For VERSION.hpp Compatible with build.py
# # 1, Complier host must install git to get the COMMIT  head 
# # 2, TIME in docker is UTC, so +8hours to get CST 
# LOCAL_VERFILE := $(LOCAL_PATH)/VERSION.hpp
# $(shell \
#   echo '#ifndef PRINT_VERSION_' >  \
#     $(LOCAL_VERFILE); \
#   echo '#define PRINT_VERSION_' >> \
#     $(LOCAL_VERFILE); \
#   echo '#include <iostream>'    >> \
#     $(LOCAL_VERFILE); \
#   echo 'inline void print_lib_version(const std::string& name){ std::cout << std::endl << name << " COMMIT:'\
#       $(shell cd $(LOCAL_PATH) && git rev-parse --short HEAD) \
#       'TIME:'\
#       $(shell date +%Y-%m-%d\ %H:%M:%S -d +8hours)\
#       '" <<std::endl;}'         >>\
#     $(LOCAL_VERFILE); \
#   echo '#endif'                 >> \
#     $(LOCAL_VERFILE); \
# )
# 
# LOCAL_SRC_FILES := \
# 	src/geographic_geometry.cpp \
# 	src/geographic_transform.cpp \
# 	src/geo_rect.cpp \
# 	src/local_cartesian_enu.cpp
# 
# LOCAL_C_INCLUDES := \
#     $(LOCAL_PATH)/include
# 
# LOCAL_SHARED_LIBRARIES := libcommon libGeographic
# 
# #Only .a file, not a submodule
# LOCAL_LDFLAGS += 
# 
# LOCAL_BUILT_SHARED_LIBRARIES := \
#     libgeographic_transform.so\
# 
# LOCAL_EXPORT_C_INCLUDE_DIRS := $(LOCAL_PATH)/include
# include $(BUILD_SHARED_LIBRARY)
