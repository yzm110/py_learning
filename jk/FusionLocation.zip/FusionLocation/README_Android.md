# 动态库编译说明（适配安卓环境的动态库）

## 下载ndk
1. https://developer.android.com/ndk/downloads?hl=zh-cn
2. 解压到本地，然后记住该文件夹地址，CMakeList.txt中会用到。(例如：/usr/local/android-ndk/android-ndk-r27c)

## 跟原来的CMakeList.txt使用基本一致
1. 将原来的CMakeLists.txt重命名或者删除
2. 将CMakeLists.txt.andriod重命名为CMakeLists.txt
3. 当前目录下新建build文件夹,并切换到build目录下 : mkdir build && cd build
4. cmake -DCMAKE_BUILD_TYPE=Debug .. (正式发版的时候cmake -DCMAKE_BUILD_TYPE=Release ..)
5. make -j8

