//
// Created by Zhiying.chen on 2022/10/10.
//

#ifndef EHR_EHPDECODER_H
#define EHR_EHPDECODER_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <unistd.h>
#include <list>
#include <ara/log/logger.h>
#include <ara/log/logging.h>

#include "HeaderDecoder.h"
#include "PosDataDecoder.h"
#include "SwitchInfoDecoder.h"
#include "RouteListDecoder.h"
#include "LaneModelDecoder.h"
#include "LaneGeomDecoder.h"
#include "PathControlDecoder.h"
#include "CurvatureDecoder.h"
#include "ProfileControlDecoder.h"
#include "GlobalDataDecoder.h"
#include "NodeDecoder.h"
#include "LaneConnectDecoder.h"
#include "LinearObjectDecoder.h"
#include "SlopeDecoder.h"
#include "SpeedLimitDecoder.h"
#include "RoadGeomDecoder.h"
#include "NumOfLaneDecoder.h"
#include "LinkIdDecoder.h"
#include "FuncClassDecoder.h"
#include "FormOfWayDecoder.h"
#include "TunnelDecoder.h"
#include "LaneWidthDecoder.h"
#include "GeoFenceDecoder.h"
#include "MergeDecoder.h"
#include "TrafficSignDecoder.h"
#include "GantryDecoder.h"
#include "PoleDecoder.h"
#include "GroundArrowDecoder.h"
#include "GroundTextDecoder.h"
#include "TollGateDecoder.h"
#include "decoder_common.h"

// EHR OUT
#include "ehrsi_out/ehrsi_out_common.h"


namespace ehp_decoder
{

class EhpProcess
{
public:
    EhpProcess(){
        init_result();
    }

    // EhpProcess() = default;

    //ehrlog
    uint32_t count_test;

    void posLog();

    void laneConnectLog();

    void mapLog();

    void mergePointLog();

    void spdLimitLog();

    void curvatureLog();

    void noaLog();

    void geoOut();

    void geoIn(LaneGeometry& laneGeo);

    void nodeLog();

    //ehp_process
    void process(std::vector<unsigned char>& unit_array);

    void ehpDecoder(std::vector<unsigned char>& bytes_array);

    void process_path();
    
    void process_profile();

    void noaUpdate();

    void init_log();

    void mapUpdate(::AllMergePoints::LinkMergePoints& link_merge_points,
                    ::FormOfWays::FormOfWays& form_of_ways,
                    ::GeoFences::GeoFences& geofences,
                    ::LaneConnectivitys::LaneConnectivitys& lane_connectivitys,
                    ::LaneSpeedLimits::LaneSpeedLimits& lane_speed_limits,
                    ::LaneWidthes::LaneWidthes& lane_widthes,
                    ::LinkCurvatures::LinkCurvatures& link_curvatures,
                    ::LinkInfos::LinkInfos& link_infos,
                    ::LinkSlopes::LinkSlopes& link_slopes,
                    ::NOAInfo::NOAInfo& noa_info,
                    ::LinearObjects::LinearObjects& linear_objects,
                    ::Nodes::Nodes& nodes,
                    ::TrafficSigns::TrafficSigns& traffic_signs);

    //ehr_out get
    ::FormOfWays::FormOfWays GetFW();
    
    ::LaneWidthes::LaneWidthes GetLaneWidth();

    ::LinearObjects::LinearObjects GetLinearObject();

    ::NOAInfo::NOAInfo GetNOAInfo();

    ::LaneConnectivitys::LaneConnectivitys GetLaneConnectivity();

    ::Nodes::Nodes GetNodes();

    ::TrafficSigns::TrafficSigns GetTrafficSign();

    ::GeoFences::GeoFences GetGeofence();

    ::LinkCurvatures::LinkCurvatures GetCurvature();

    ::LinkSlopes::LinkSlopes GetSlope();

    ::LaneSpeedLimits::LaneSpeedLimits GetSpeedLimit();

    ::LinkInfos::LinkInfos GetLink();

    ::AllMergePoints::LinkMergePoints GetMergePoint();

    std::mutex buf_mutex_;


private:
    ara::log::Logger &log_{ara::log::CreateLogger(ara::core::StringView{"EHR"},
                                                ara::core::StringView{"Decoder"})};

    void init_result();                                            

    Header header_result_;
    PositionData position_result_;
    PathControl path_control_result_;
    GlbData global_data_result_;
    ProfileControl profile_control_result_;

    //ehr pool
    std::vector<Node> node_result_;
    std::vector<LaneModel> lane_model_result_;
    std::vector<LaneConnect> lane_connect_result_;
    std::vector<LinearObject> linear_object_result_;
    std::vector<LaneGeometry> lane_geometry_result_;
    std::vector<Curvatures> curvatures_result_;
    std::vector<Slopes> slopes_result_;
    std::vector<SpdLimit> speed_limit_result_;
    std::vector<RoadGeometry> road_geometry_result_;
    std::vector<NumOfLane> num_of_lane_result_;
    std::vector<LinkId> link_id_result_;
    std::vector<FuncClass> func_class_result_;
    std::vector<FormOfWay> form_of_way_result_;
    std::vector<Tunnel> tunnel_result_;
    std::vector<LaneWidth> lane_width_result_;
    SwitchInfo switch_result_;
    RouteList route_list_result_;
    std::vector<Geofence> geofence_result_;
    std::vector<MergePoint> merge_point_result_;
    std::vector<TrafficSign> traffic_sign_result_;
    std::vector<Gantry> gantry_result_;
    std::vector<Pole> pole_result_;
    std::vector<GroundArrow> ground_arrow_result_;
    std::vector<GroundText> ground_text_result_;
    std::vector<TollGate> toll_gate_result_;
    
    // // EHR out
    ::AllMergePoints::LinkMergePoints link_merge_points_;
    ::FormOfWays::FormOfWays form_of_ways_;
    ::GeoFences::GeoFences geofences_;
    ::LaneConnectivitys::LaneConnectivitys lane_connectivitys_;
    ::LaneSpeedLimits::LaneSpeedLimits lane_speed_limits_;
    ::LaneWidthes::LaneWidthes lane_widthes_;
    ::LinkCurvatures::LinkCurvatures link_curvatures_;
    ::LinkInfos::LinkInfos link_infos_;
    ::LinkSlopes::LinkSlopes link_slopes_;
    ::NOAInfo::NOAInfo noa_info_;
    ::LinearObjects::LinearObjects linear_objects_;
    ::Nodes::Nodes nodes_;
    ::TrafficSigns::TrafficSigns traffic_signs_;

    int lane_count_;
    int route_count_ = 0;
};

} // namespace of ehp_decoder
#endif //EHR_EHPDECODER_H
