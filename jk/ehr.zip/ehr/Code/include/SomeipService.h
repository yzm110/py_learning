#ifndef PERCEP_PROVIDED_SOMEIP_H
#define PERCEP_PROVIDED_SOMEIP_H

#include <mutex>
#include "ehrsi_out/ehrsi_out_skeleton.h"

namespace map {

    class SomeipService final
            : public ehrsi_out::skeleton::EHRSI_OutSkeleton {
    public:
        SomeipService();

        ~SomeipService();

        void SendEvent(const FormOfWays::FormOfWays &data);

        void SendEvent(const LaneWidthes::LaneWidthes &data);

        void SendEvent(const LinearObjects::LinearObjects &data);

        void SendEvent(const NOAInfo::NOAInfo &data);

        void SendEvent(const LaneConnectivitys::LaneConnectivitys &data);

        void SendEvent(const ::Nodes::Nodes &data);

        void SendEvent(const ::TrafficSigns::TrafficSigns &data);

        void SendEvent(const ::GeoFences::GeoFences &data);

        void SendEvent(const ::LinkCurvatures::LinkCurvatures &data);

        void SendEvent(const ::LinkSlopes::LinkSlopes &data);

        void SendEvent(const ::LaneSpeedLimits::LaneSpeedLimits &data);

        void SendEvent(const ::LinkInfos::LinkInfos &data);

        void SendEvent(const ::AllMergePoints::LinkMergePoints &data);

    private:
        ara::log::Logger &log_;
    };
}  // namespace Perception

#endif  // PERCEP_PROVIDED_SOMEIP_H
