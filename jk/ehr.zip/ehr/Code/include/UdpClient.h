#ifndef MAPPROCESS_UDP_CLIENT_H_
#define MAPPROCESS_UDP_CLIENT_H_

#include <stdint.h>

#include <functional>
#include <string>
#include <iostream>

namespace map {
    class UdpClient final {
    public:
        UdpClient(const std::string &ip, uint16_t port);

        ~UdpClient();

        int add_udp_multi(int sockfd, const char *udp_ip, int udp_port);

        void StartRecvLoop();

        void SetCallBack(std::function<void(const uint8_t *, uint32_t)> fun);

    private:
        std::function<void(const uint8_t *, uint32_t)> callback_;

        int socket_;
        std::string ip_;
        uint16_t port_;
    };
}  // namespace map

#endif  // UDP_CLIENT_H_
