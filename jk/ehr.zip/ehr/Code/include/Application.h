
#ifndef MAPPROCESS_APPLICATION_H_
#define MAPPROCESS_APPLICATION_H_

#include <stdint.h>

#include <memory>
#include <string>
#include <thread>

#include "UdpClient.h"
#include "SomeipService.h"
#include <time.h>
#include "DecoderBase.h"
#include "ehp_decoder.h"

#include <atomic>
#include <fstream>
#include <memory>
#include <thread>
#include "ara/exec/application_client.h"
#include "ara/exec/application_state.h"
#include "ara/log/logging.h"

namespace map {
    constexpr static char *VER = "Release_A2_V001";
    constexpr static int MAIN_THREAD = 500;  // real will be 50ms
    class Application {
    public:
        Application(const std::string &ip, uint16_t port);

        ~Application();

        void WorkProc();

        void StartMainLoop();

        void OutputThread();

        void OutputWork();


        void SignalHandle();

        void ReportApplicationState(
                ara::exec::ApplicationState application_state);

    private:
        ara::log::Logger &log_{ara::log::CreateLogger(ara::core::StringView{"EHR"},
                                                      ara::core::StringView{"EHR"})};

        UdpClient udpclient_;
        ehp_decoder::EhpProcess ehpProcess;
        SomeipService service_;

        std::shared_ptr<std::thread> signal_handler_thread_;
        std::shared_ptr<std::thread> work_thread_;
        std::shared_ptr<std::thread> udp_thread_;
        std::shared_ptr<std::thread> service_thread_;

        std::atomic<bool> signal_exit_;
        std::atomic<bool> terminated_by_signal_;
        ara::exec::ApplicationClient application_client_;

        // UdpClient udpclient_;
        // std::shared_ptr<std::thread> work_thread_;
        // std::shared_ptr<std::thread> udp_thread_;
    };
}  // namespace map

#endif  // MAPPROCESS_APPLICATION_H_