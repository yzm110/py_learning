//
// Created by Zhiying.chen on 2022/10/10.
//

#include "ehp_decoder.h"

#include <algorithm>
#include <cmath>

//uint32_t count_test;
//bool start_receive = false;

//ehp_decoder::EhrLog ehrlog;

namespace ehp_decoder
{
//ehrlog
void EhpProcess::init_log()
{
    count_test = 0;

    // TODO: titles printed several times into csv

    // position
    std::ofstream out_put_pos;
    out_put_pos.open("/home/czy/jicaai/data/position.csv", std::ofstream::out | std::ofstream::app);
    out_put_pos << "count_test,lon_,lat_,heading,pathId,linkid,lanenumber,offset" << std::endl;
    out_put_pos.close();

    // noa
    std::ofstream out_put_noa;
    out_put_noa.open("/home/czy/jicaai/data/noa.csv",std::ofstream::out | std::ofstream::app);
    out_put_noa << "count_test,navi_status,match_status,remain_dis,switch_direct,switch_reson,switch_dis,switch_dis_e,pathId,linkId,laneId,offset(lineId),lon,lat" << std::endl;
//    out_put_noa << ",pathId,linkId,laneNumber,offset(linearobject)" << std::endl;
    out_put_noa.close();

    // lane connectivities
    std::ofstream out_put_laneconnect;
    out_put_laneconnect.open("/home/czy/jicaai/data/laneconnect.csv",std::ofstream::out | std::ofstream::app);
    out_put_laneconnect << "count_test,pathId,linkId,lanenumber,newPathId,newLinkID,newLaneNumber" << std::endl;
    out_put_laneconnect.close();

    //spdlimit
    std::ofstream out_put_speed_limit;
    out_put_speed_limit.open("/home/czy/jicaai/data/speed_limit.csv", std::ofstream::out | std::ofstream::app);
    out_put_speed_limit << "count_test,linkId,offset,endOffset,value_H,value_L"<<std::endl;
    out_put_speed_limit.close();

    //merge point
    std::ofstream out_put_merge_points;
    out_put_merge_points.open("/home/czy/jicaai/data/merge_points.csv", std::ofstream::out | std::ofstream::app);
    out_put_merge_points << "count_test,pathId,linkId,merge_pathId,isMaster,offset"<<std::endl;
    out_put_merge_points.close();

    //node
    std::ofstream out_put_node;
    out_put_node.open("/home/czy/jicaai/data/nodes.csv", std::ofstream::out | std::ofstream::app);
    out_put_node << "count_test,pathId,linkId,subPath,turnAngle,rightOfWay"<<std::endl;
    out_put_node.close();

    // lanegeometry
    std::ofstream out_put_geo;
    out_put_geo.open("/home/czy/jicaai/data/geo.csv",std::ofstream::out | std::ofstream::app);
    out_put_geo << "count_test:pathId:instanceId:laneNum:lineId:type(0_center 1_mark 5_vitrul):marking:offset:endoffset:line" << std::endl;
    out_put_geo.close();

    // lanegeometry input
    std::ofstream out_put_geoin;
    out_put_geoin.open("/home/czy/jicaai/data/geoin.csv",std::ofstream::out | std::ofstream::app);
    out_put_geoin << "count_test:pathId:instanceId:laneId:type(0_center 1_mark 5_vitrul):line" << std::endl;
    out_put_geoin.close();

}

void EhpProcess::posLog()
{
    std::ofstream out_put_pos;
    out_put_pos.open("/home/czy/jicaai/data/position.csv",std::ofstream::out | std::ofstream::app);
    out_put_pos << count_test << "," <<std::setprecision(10) << static_cast<double>((position_result_.lon_/pow(2,32))*360)<< "," << static_cast<double>((position_result_.lat_/pow(2,32))*360) << ","
                << position_result_.heading_ << "," << position_result_.pathid_ << "," << position_result_.roadID_ << ","
                << static_cast<unsigned int>(position_result_.currentLane_) << "," << position_result_.offset_ << std::endl;
    out_put_pos.close();
}

void EhpProcess::laneConnectLog()
{
    std::ofstream out_put_laneconnect;
    out_put_laneconnect.open("/home/czy/jicaai/data/laneconnect.csv", std::ofstream::out | std::ofstream::app);

    for(auto lane_connect : lane_connect_result_)
    {
        for(auto item : lane_connect.laneConnectItems_)
        {
            out_put_laneconnect << count_test << ","
                                << static_cast<unsigned int>(item.initPath_) << "," << static_cast<unsigned int>(lane_connect.instanceId_) << "," << static_cast<unsigned int>(item.initLaneNum_) << ","
                                << static_cast<unsigned int>(item.newPath_) << "," << static_cast<unsigned int>(item.toLinkId_) << "," << static_cast<unsigned int>(item.newLaneNum_) << std::endl;
        }
    }
    out_put_laneconnect.close();
}

void EhpProcess::mapLog()
{
    // mapUpdate
    std::ofstream mapLog;
    mapLog.open("/home/czy/jicaai/data/mapLog.csv",std::ofstream::out | std::ofstream::app);

    //pathcontrol
    if(path_control_result_.pathItems_.empty())
    {
        std::cout << "path control empty!" << std::endl;
    }
    else
    {
        mapLog << count_test << ",pathcontrol,reset=" << static_cast<unsigned int>(path_control_result_.isReset_)
                  <<" ,id="<< path_control_result_.pathItems_.begin()->id_ <<" ,offset="<< path_control_result_.pathItems_.begin()->offset_ << std::endl;
    }

    //profilecontrol
    mapLog << count_test << ",profilecontrol";
    for(auto profile_item : profile_control_result_.profileItems_)
    {
       mapLog << ",pathId="<<profile_item.pathId_ << ",offset="<<profile_item.offset_;
    }
    mapLog << std::endl;

    //position
    mapLog << count_test <<",position,pathId="<<position_result_.pathid_<<",linkid="<<position_result_.roadID_<<",offset="<<position_result_.offset_<<std::endl;

    //lanemodel
    mapLog << count_test << ",lanemodel,pathId,linkId,offset,endoffset"<<std::endl;
    for(auto laneModel_item : lane_model_result_)
    {
        mapLog <<",,"<<laneModel_item.pathId_<< "," << laneModel_item.instanceId_
              << ","<< laneModel_item.offset_ << "," << laneModel_item.endOffset_
              << std::endl;
    }
    mapLog.close();
}

void EhpProcess::mergePointLog()
{
    std::ofstream out_put_merge_points;
    out_put_merge_points.open("/home/czy/jicaai/data/merge_points.csv", std::ofstream::out | std::ofstream::app);
    for(auto merge_point : merge_point_result_)
    {
        out_put_merge_points << count_test << ","
                             << merge_point.pathId_ << "," << merge_point.instanceId_ << ","
                             << merge_point.mergePointItems_.begin()->pathId_ << ","
                             << merge_point.mergePointItems_.begin()->isMaster_ << ","
                             << merge_point.mergePointItems_.begin()->offset_ << std::endl;
    }
    out_put_merge_points.close();
}

void EhpProcess::spdLimitLog()
{
    std::ofstream out_put_speed_limit;
    out_put_speed_limit.open("/home/czy/jicaai/data/speed_limit.csv", std::ofstream::out | std::ofstream::app);
    for(auto speed_limit : speed_limit_result_)
    {
        out_put_speed_limit << count_test << "," << static_cast<unsigned int>(speed_limit.instanceId_) << ","
                    << static_cast<unsigned int>(speed_limit.offset_) << ","
                    << static_cast<unsigned int>(speed_limit.endOffset_) << ","
                    << static_cast<unsigned int>(speed_limit.value_H_) << ","
                    << static_cast<unsigned int>(speed_limit.value_L_) <<std::endl;
    }
    out_put_speed_limit.close();
}

void EhpProcess::curvatureLog()
{
    std::ofstream out_put_link_curvature;
    out_put_link_curvature.open("/home/czy/jicaai/data/link_curvatures.csv", std::ofstream::out | std::ofstream::app);
    for (auto curvatures : curvatures_result_)
    {
        out_put_link_curvature << count_test << "," << static_cast<unsigned int>(curvatures.instanceId_) << ","
                    << static_cast<unsigned int>(curvatures.offset_) << ","
                    << static_cast<unsigned int>(curvatures.endOffset_) << ","<< std::endl;
    }
    out_put_link_curvature.close();
}

void EhpProcess::noaLog()
{
    std::ofstream out_put_noa;
    out_put_noa.open("/home/czy/jicaai/data/noa.csv", std::ofstream::out | std::ofstream::app);
    out_put_noa << count_test << ","
                <<static_cast<unsigned int>(noa_info_.NavigationStatus_ref) << ","
                << static_cast<unsigned int>(noa_info_.MatchingStatus_ref) << ","
                << noa_info_.RemainDistance_ref << ","
                << static_cast<unsigned int>(noa_info_.SwitchLaneDirection_ref) << ","
                << static_cast<unsigned int>(noa_info_.SwitchLaneReason_ref) << ","
                << noa_info_.SwitchLaneDistance_ref << ","
                << noa_info_.SwitchLaneEndDistance_ref << ",";
    out_put_noa << position_result_.pathid_ << "," << position_result_.roadID_ << ","
                << static_cast<unsigned int>(position_result_.currentLane_) << "," << position_result_.offset_ << ","
                << std::endl;
    for(auto item : noa_info_.PairOfIds_ref)
    {
        out_put_noa << ",,,,,,,,"
                    << item.PathId_ref << ","
                    << item.InstanceId_ref << ","
                    << static_cast<unsigned int>(item.LaneNumber_ref) << ","
                    << item.LinearObjectId_ref << ",";

        if(linear_objects_.empty())
        {
            out_put_noa << std::endl;
            continue;
        }

        auto it_line = std::find_if(linear_objects_.begin(),linear_objects_.end(),[&](const ::LinearObject::LinearObject& linearObject){
            return item.LinearObjectId_ref == linearObject.IDLinearObject_ref;
        });
        if(it_line!=linear_objects_.end()){
            auto item = it_line->GeometryPoints_ref.begin();
            out_put_noa << std::setprecision(10) << static_cast<double>((item->Longitude_ref/pow(2,32))*360)<< "," << static_cast<double>((item->Latitude_ref/pow(2,32))*360)<<",";
        }
        out_put_noa << std::endl;
    }
    out_put_noa << std::endl;
    out_put_noa.close();
}

void EhpProcess::nodeLog()
{
    std::ofstream out_put_node;
    out_put_node.open("/home/czy/jicaai/data/nodes.csv", std::ofstream::out | std::ofstream::app);
    for(auto node : node_result_)
    {
        if(node.nodeItems_.empty())
        {
            std::cout << "node item empty!" << std::endl;
            continue;
        }
        out_put_node << count_test << "," << node.pathId_ << "," << node.instanceId_ << ","
                     << node.nodeItems_.begin()->subPath_ << ","
                     << node.nodeItems_.begin()->turnAngle_ << ","
                     << static_cast<unsigned int>(node.nodeItems_.begin()->rightOfWay_) << std::endl;
    }
    out_put_node.close();
}

void EhpProcess::geoOut()
{
    // lanegeometry
    std::ofstream out_put_geo;
    out_put_geo.open("/home/czy/jicaai/data/geo.csv",std::ofstream::out | std::ofstream::app);
    for(auto item : linear_objects_)
    {
        out_put_geo << count_test << ":" << item.PathId_ref << ":"
                    << item.InstanceId_ref << ":"
                    << static_cast<unsigned int>(item.LaneNumber_ref) << ":"
                    << item.IDLinearObject_ref << ":"
                    << static_cast<unsigned int>(item.LinearObjectType_ref) << ":"
                    << static_cast<unsigned int>(item.LinearObjectmarking_ref) <<":"
                    << item.PathOffset_ref << ":"
                    << item.EndOffset_ref << ":"
                    << "LineString(";
        for(auto point : item.GeometryPoints_ref)
        {
            out_put_geo << std::setprecision(10) << static_cast<double>((point.Longitude_ref/pow(2,32))*360)<< " " << static_cast<double>((point.Latitude_ref/pow(2,32))*360)<<",";
        }
        out_put_geo << ")" << std::endl;
    }
    out_put_geo.close();
}

void EhpProcess::geoIn(LaneGeometry& laneGeo)
{
    uint8_t line_type;

    auto it_link = std::find_if(linear_object_result_.begin(), linear_object_result_.end(), [&](const LinearObject& linearObject){
        return laneGeo.instanceId_ == linearObject.instanceId_;
    });
    if(it_link != linear_object_result_.end())
    {
        auto it_line = std::find_if(it_link->linearObject_Items_.begin(),it_link->linearObject_Items_.end(),[&](const LinearObject_Item& item){
            return laneGeo.idLine_ == item.id_;
        });
        if(it_line != it_link->linearObject_Items_.end()){
            line_type = it_line->type_;
        }
    }

    std::ofstream out_put_geoin;
    out_put_geoin.open("/home/czy/jicaai/data/geoin.csv",std::ofstream::out | std::ofstream::app);
    out_put_geoin << count_test << ":" << laneGeo.pathId_ << ":" << laneGeo.instanceId_ << ":"
                  << static_cast<unsigned int>(laneGeo.laneNumber_) << ":" << static_cast<unsigned int>(line_type) <<":LineString(";
    for(auto point : laneGeo.lanePoints_)
    {
       out_put_geoin << std::setprecision(10) << static_cast<double>((point.longitude_/pow(2,32))*360)<< " " << static_cast<double>((point.latitude_/pow(2,32))*360)<<",";
    }
    out_put_geoin<<")"<<std::endl;
    out_put_geoin.close();
}

//ehr_output_get
::FormOfWays::FormOfWays EhpProcess::GetFW(){
    // std::cout << "get fw success:";
    return form_of_ways_;
}
    
::LaneWidthes::LaneWidthes EhpProcess::GetLaneWidth(){
    // if(lane_widthes_.size()){
    //     std::cout << "get lanewidth success : "<< lane_widthes_.size();
    // }
    return lane_widthes_;
}

::LinearObjects::LinearObjects EhpProcess::GetLinearObject(){
    // if(linear_objects_.size()){
    //     std::cout << "get linear objects success : ";
    //     std::cout << linear_objects_.size() << std::endl;
    // }
    return linear_objects_;
}

::NOAInfo::NOAInfo EhpProcess::GetNOAInfo() {
    // std::cout << "get noa info success : "<< noa_info_.Count_ref << std::endl;
    return noa_info_;
}

::LaneConnectivitys::LaneConnectivitys EhpProcess::GetLaneConnectivity() {
    for (auto item : lane_connectivitys_) {
        log_.LogInfo() << "lane_connectivitys: " << "InstanceId_ref: " << item.InstanceId_ref << " ";
    }
    return lane_connectivitys_;
}

::Nodes::Nodes EhpProcess::GetNodes() {
    for (auto item : nodes_) {
        log_.LogInfo() <<"nodes: " << "InstanceId_ref: " << item.InstanceId_ref << " ";
    }
    return nodes_;
}

::TrafficSigns::TrafficSigns EhpProcess::GetTrafficSign() {
    return traffic_signs_;
}

::GeoFences::GeoFences EhpProcess::GetGeofence() {
    // std::cout << "get GF success : "<< geofences_.size();
    return geofences_;
}

::LinkInfos::LinkInfos EhpProcess::GetLink() {
    for (auto item : link_infos_) {
        log_.LogInfo() << "link_infos: " << "InstanceId_ref: " << item.InstanceId_ref << " ";
    }
    return link_infos_;
}

::LinkSlopes::LinkSlopes EhpProcess::GetSlope() {
    return link_slopes_;
}

::LaneSpeedLimits::LaneSpeedLimits EhpProcess::GetSpeedLimit() {
    return lane_speed_limits_;
}

::LinkCurvatures::LinkCurvatures EhpProcess::GetCurvature() {
    return link_curvatures_;
}

::AllMergePoints::LinkMergePoints EhpProcess::GetMergePoint() {
    return link_merge_points_;
}

//ehr_process
template <typename T>
void func_path(T &a, PathControl &path_control_result)
{
    auto iter = a.begin();
    while(iter != a.end())
    {
        auto it = std::find_if(path_control_result.pathItems_.begin(), path_control_result.pathItems_.end(), [&](const PathControlItem& item){
            return iter->pathId_ == item.id_;
        });
        if(it == path_control_result.pathItems_.end())
        {
            iter = a.erase(iter);
        }
        else
        {
            iter++;
        }
    }
}

void EhpProcess::process_path()
{
    func_path(node_result_, path_control_result_);
    func_path(lane_model_result_, path_control_result_);
    func_path(lane_connect_result_, path_control_result_);
    func_path(linear_object_result_, path_control_result_);
    func_path(lane_geometry_result_, path_control_result_);
    func_path(curvatures_result_, path_control_result_);
    func_path(slopes_result_, path_control_result_);
    func_path(speed_limit_result_, path_control_result_);
    func_path(road_geometry_result_, path_control_result_);
    func_path(num_of_lane_result_, path_control_result_);
    func_path(link_id_result_, path_control_result_);
    func_path(func_class_result_, path_control_result_);
    func_path(form_of_way_result_, path_control_result_);
    func_path(tunnel_result_, path_control_result_);
    func_path(lane_width_result_, path_control_result_);
    func_path(geofence_result_, path_control_result_);
    func_path(merge_point_result_, path_control_result_);
    func_path(traffic_sign_result_, path_control_result_);
    func_path(gantry_result_, path_control_result_);
    func_path(pole_result_, path_control_result_);
    func_path(ground_arrow_result_, path_control_result_);
    func_path(ground_text_result_, path_control_result_);
    func_path(toll_gate_result_, path_control_result_);   
}

template <typename T>
void func_profile(T &a, const ProfileControl &profile_control_result)
{
    auto iter = a.begin();
    while(iter != a.end())
    {
        auto it = std::find_if(profile_control_result.profileItems_.begin(), profile_control_result.profileItems_.end(), [&](const ProfileControlItem& item){
            return iter->pathId_ == item.pathId_;
        });
        if(it != profile_control_result.profileItems_.end() && it->offset_ >= iter->endOffset_)
        {
            iter = a.erase(iter);
        }
        else
        {
            iter++;
        }
    }
}

void EhpProcess::process_profile()
{
    func_profile(node_result_, profile_control_result_);
    func_profile(lane_model_result_, profile_control_result_);
    func_profile(lane_connect_result_, profile_control_result_);
    func_profile(linear_object_result_, profile_control_result_);
    func_profile(lane_geometry_result_, profile_control_result_);
    func_profile(curvatures_result_, profile_control_result_);
    func_profile(slopes_result_, profile_control_result_);
    func_profile(speed_limit_result_, profile_control_result_);
    func_profile(road_geometry_result_, profile_control_result_);
    func_profile(num_of_lane_result_, profile_control_result_);
    func_profile(link_id_result_, profile_control_result_);
    func_profile(func_class_result_, profile_control_result_);
    func_profile(form_of_way_result_, profile_control_result_);
    func_profile(tunnel_result_, profile_control_result_);
    func_profile(lane_width_result_, profile_control_result_);
    func_profile(geofence_result_, profile_control_result_);
    func_profile(merge_point_result_, profile_control_result_);
    func_profile(traffic_sign_result_, profile_control_result_);
    func_profile(gantry_result_, profile_control_result_);
    func_profile(pole_result_, profile_control_result_);
    func_profile(ground_arrow_result_, profile_control_result_);
    func_profile(ground_text_result_, profile_control_result_);
    func_profile(toll_gate_result_, profile_control_result_);    
}

void EhpProcess::init_result(){
    memset(&link_merge_points_  ,0, sizeof(link_merge_points_));
    memset(&form_of_ways_  ,0, sizeof(form_of_ways_));
    memset(&geofences_         ,0, sizeof(geofences_));
    memset(&lane_connectivitys_,0, sizeof(lane_connectivitys_));
    memset(&lane_speed_limits_ ,0, sizeof(lane_speed_limits_));
    memset(&lane_widthes_ ,0, sizeof(lane_widthes_));
    memset(&link_curvatures_   ,0, sizeof(link_curvatures_));
    memset(&link_infos_        ,0, sizeof(link_infos_));
    memset(&link_slopes_       ,0, sizeof(link_slopes_));
    memset(&noa_info_          ,0, sizeof(noa_info_));
    memset(&linear_objects_          ,0, sizeof(linear_objects_));
    memset(&nodes_             ,0, sizeof(nodes_));
    memset(&traffic_signs_    ,0, sizeof(traffic_signs_));
}

void EhpProcess::mapUpdate(::AllMergePoints::LinkMergePoints& link_merge_points,
    ::FormOfWays::FormOfWays& form_of_ways,
    ::GeoFences::GeoFences& geofences,
    ::LaneConnectivitys::LaneConnectivitys& lane_connectivitys,
    ::LaneSpeedLimits::LaneSpeedLimits& lane_speed_limits,
    ::LaneWidthes::LaneWidthes& lane_widthes,
    ::LinkCurvatures::LinkCurvatures& link_curvatures,
    ::LinkInfos::LinkInfos& link_infos,
    ::LinkSlopes::LinkSlopes& link_slopes,
    ::NOAInfo::NOAInfo& noa_info,
    ::LinearObjects::LinearObjects& linear_objects,
    ::Nodes::Nodes& nodes,
    ::TrafficSigns::TrafficSigns& traffic_signs
)
{
    count_test++;

    // EHROUT: all merge points
    link_merge_points.clear();
    for (auto merge_point : merge_point_result_)
    {
        ::AllMergePoint::LinkMergePoint link_merge_point;
        link_merge_point.InstanceId_ref = merge_point.instanceId_;
        link_merge_point.PathId_ref = merge_point.pathId_;
        link_merge_point.LaneNum_ref = merge_point.laneNumber_;
        link_merge_point.PathOffset_ref = merge_point.offset_;
        link_merge_point.EndOffset_ref = merge_point.endOffset_;
        link_merge_point.MergePointCount_ref = merge_point.mergePointCount_;
        link_merge_point.MergePoints_ref.resize( link_merge_point.MergePointCount_ref);
        for (int i = 0; i < merge_point.mergePointItems_.size(); i++)
        {
            link_merge_point.MergePoints_ref.at(i).IsMaster_ref = merge_point.mergePointItems_.at(i).isMaster_;
            link_merge_point.MergePoints_ref.at(i).PathId_ref = merge_point.mergePointItems_.at(i).pathId_;
            link_merge_point.MergePoints_ref.at(i).PathOffset_ref = merge_point.mergePointItems_.at(i).offset_;
        }
        link_merge_points.push_back(link_merge_point);
    }
    
    // EHROUT : Form Of Way
    form_of_ways.clear();
    for (auto form_of_way_in : form_of_way_result_)
    {
        ::FormOfWay::FormOfWay form_of_way;
        form_of_way.InstanceId_ref = form_of_way_in.instanceId_;
        form_of_way.PathId_ref = form_of_way_in.pathId_;
        form_of_way.LaneNumber_ref = form_of_way_in.laneNumber_;
        form_of_way.PathOffset_ref = form_of_way_in.offset_;
        form_of_way.EndOffset_ref = form_of_way_in.endOffset_;
        form_of_way.FromOfWayConfidence_ref = form_of_way_in.confidence_;
        form_of_way.Available_ref = (::Available::Available)form_of_way_in.available_;
        form_of_way.FormOfWay1_ref = (::FormOfWay1::FormOfWay1)form_of_way_in.formOfWay_;
        form_of_ways.push_back(form_of_way);
    }

    // EHROUT: geofences
    geofences.clear();
    for (auto geofence : geofence_result_)
    {
        ::GeoFence::GeoFence geo_fence;
        geo_fence.InstanceId_ref = geofence.instanceId_;
        geo_fence.PathId_ref = geofence.pathId_;
        geo_fence.LaneNumber_ref = geofence.laneNumber_;
        geo_fence.PathOffset_ref = geofence.offset_;
        geo_fence.EndOffset_ref = geofence.endOffset_;
        geo_fence.GeoFenceCount_ref = geofence.geoFenceCount_;
        geo_fence.GeofenceType_ref = (::GeofenceType::GeofenceType)geofence.geoFenceItems_.begin()->geoFenceType_;
        geo_fence.Lanesequence_ref = geofence.geoFenceItems_.begin()->laneSequence_;
        geo_fence.S_Offset_ref = geofence.geoFenceItems_.begin()->s_offset_;
        geo_fence.EndOffset_ref = geofence.geoFenceItems_.begin()->e_offset_;

        // geo_fence.GeoFenceType_ref = geofence.type_;
//        for(auto geofence_item : geofence.geoFenceItems_)
//        {
//            geo_fence.GeofenceType_ref = (::GeofenceType::GeofenceType)geofence_item.geoFenceType_;
//            geo_fence.Lanesequence_ref = geofence_item.laneSequence_;
//            geo_fence.S_Offset_ref = geofence_item.s_offset_;
//            geo_fence.E_Offset_ref = geofence_item.e_offset_;
//        }

        geofences.push_back(geo_fence);
    }

    // EHROUT: lane connectivities
    lane_connectivitys.clear();
    for(auto lane_connect:lane_connect_result_)
    {
        for(auto lane_connect_item : lane_connect.laneConnectItems_)
        {
            ::PairConnectivity::PairConnectivity pair_connectivity;
            pair_connectivity.PathId_ref = lane_connect.pathId_;
            pair_connectivity.InstanceId_ref = lane_connect.instanceId_;
            pair_connectivity.LaneNumber_ref = lane_connect.laneNumber_;
            pair_connectivity.PathOffset_ref = lane_connect.offset_;
            pair_connectivity.FromLinkId_ref = lane_connect.instanceId_;
            pair_connectivity.InitPath_ref = lane_connect_item.initPath_;
            pair_connectivity.InitLaneNum_ref = lane_connect_item.initLaneNum_;
            pair_connectivity.ToLinkId_ref = lane_connect_item.toLinkId_;
            pair_connectivity.NewPath_ref = lane_connect_item.newPath_;
            pair_connectivity.NewLaneNum_ref = lane_connect_item.newLaneNum_;
            lane_connectivitys.push_back(pair_connectivity);
        }
    }

    // EHROUT: lane speed limits
    lane_speed_limits.clear();
    for(auto speed_limit : speed_limit_result_)
    {
        ::LaneSpeedLimit::LaneSpeedLimit lane_speed_limit;
        lane_speed_limit.InstanceId_ref = speed_limit.instanceId_;
        lane_speed_limit.PathId_ref = speed_limit.pathId_;
        lane_speed_limit.LaneNumber_ref = speed_limit.laneNumber_;
        lane_speed_limit.PathOffset_ref = speed_limit.offset_;
        lane_speed_limit.EndOffset_ref = speed_limit.endOffset_;
        lane_speed_limit.Value_H_ref = speed_limit.value_H_;
        lane_speed_limit.Value_L_ref = speed_limit.value_L_;
        lane_speed_limit.SpeedLimitUnit_ref = (::SpeedLimitUnit::SpeedLimitUnit)speed_limit.uint_;
        lane_speed_limits.push_back(lane_speed_limit); 
    }

    // EHROUT: link curvatures
    link_curvatures.clear();
    for(auto lane_model : lane_model_result_)
    {
        ::LinkCurvature::LinkCurvature link_curvature;
        link_curvature.InstanceId_ref = lane_model.instanceId_;
        link_curvature.PathId_ref = lane_model.pathId_;
        link_curvature.LaneNumber_ref = lane_model.laneNumber_;
        link_curvature.PathOffset_ref = lane_model.offset_;
        link_curvature.EndOffset_ref = lane_model.endOffset_;

        for (auto curvatures : curvatures_result_)
        {
            if (curvatures.instanceId_ == link_curvature.InstanceId_ref)
            {
                link_curvature.CurvCount_ref ++;
                for (auto curvature : curvatures.curvatures_)
                {
                    ::CurvPoint::CurvPoint curve_point;
                    curve_point.PathOffset_ref = curvature.offset_;
                    curve_point.CurvPointValue_ref = curvature.curvature_;
                    link_curvature.CurvPoints_ref.push_back(curve_point);
                }
            }
        }
        link_curvatures.push_back(link_curvature);
    }

    // EHROUT: link slopes
    link_slopes.clear();
    for (auto lane_model : lane_model_result_)
    {
        ::LinkSlope::LinkSlope link_slope;
        link_slope.InstanceId_ref = lane_model.instanceId_;
        link_slope.NumOfLane_ref = lane_model.totalNumLane_;
        link_slope.PathId_ref = lane_model.pathId_;
        link_slope.PathOffset_ref = lane_model.offset_;
        link_slope.EndOffset_ref = lane_model.endOffset_;
        for(auto slopes : slopes_result_)
        {
            if(slopes.instanceId_ == link_slope.InstanceId_ref)
            {
                link_slope.SlopeCount_ref = slopes.slopeCount_;
                for (auto slope : slopes.slopes_)
                {
                    ::SlopePoint::SlopePoint slope_point;
                    slope_point.Crossvalue_ref = slope.crossSlope_;
                    slope_point.Slopevalue_ref = slope.slope_;
                    slope_point.PathOffset_ref = slope.offset_;
                    link_slope.SlopePoints_ref.push_back(slope_point);
                }
            }
        }
        link_slopes.push_back(link_slope);
    }

    // EHROUT: Lane Width
    lane_widthes.clear();
    for (auto lane_width_in : lane_width_result_)
    {
        ::LaneWidth::LaneWidth lane_width;
        lane_width.InstanceId_ref = lane_width_in.instanceId_;
        lane_width.PathId_ref = lane_width_in.pathId_;
        lane_width.LaneNumber_ref = lane_width_in.laneNumber_;
        lane_width.PathOffset_ref = lane_width_in.offset_;
        lane_width.EndOffset_ref = lane_width_in.endOffset_;
        lane_width.Available_ref = (::Available::Available)lane_width_in.available_;
        lane_width.Minwidth_ref = lane_width_in.minWidth_;
        lane_width.Maxwidth_ref = lane_width_in.maxWidth_;
        lane_widthes.push_back(lane_width);    
    }

    // EHROUT: nodes
    nodes.clear();
    for(auto node : node_result_)
    {
        ::PathNode::PathNode path_node;
        path_node.InstanceId_ref = node.instanceId_;
        path_node.PathId_ref = node.pathId_;
        path_node.LaneNumber_ref = node.laneNumber_;
        path_node.PathOffset_ref = node.offset_;
        path_node.EndOffset_ref = node.endOffset_;
        path_node.SubPath_ref = node.nodeItems_.begin()->subPath_;
        path_node.Probability_ref = node.nodeItems_.begin()->probability_;
        path_node.TurnAngle_ref = node.nodeItems_.begin()->turnAngle_;
        path_node.CompIntSec_ref = node.nodeItems_.begin()->compIntSec_;
        path_node.RightOfWay_ref= (::RightOfWay::RightOfWay)node.nodeItems_.begin()->rightOfWay_;
        nodes.push_back(path_node);
        // std::cout << "test2!!!!!!!!!!!1" << static_cast<unsigned int>(node.instanceId_) << std::endl;
    }

    // EHROUR: traffic signs
    traffic_signs.clear();
    for(auto traffic_sign : traffic_sign_result_)
    {
        ::PathTrafficSigns::PathTrafficSigns path_traffic_signs;
        path_traffic_signs.InstanceId_ref = traffic_sign.instanceId_;
        path_traffic_signs.PathId_ref = traffic_sign.pathId_;
        path_traffic_signs.LaneNumber_ref = traffic_sign.laneNumber_;
        path_traffic_signs.PathOffset_ref = traffic_sign.offset_;
        path_traffic_signs.EndOffset_ref = traffic_sign.endOffset_;
        path_traffic_signs.TrafficSignType_ref = (TrafficSignType::TrafficSignType)traffic_sign.trafficSignType_;
        path_traffic_signs.TrafficSignShape_ref = (TrafficSignShape::TrafficSignShape)traffic_sign.trafficSignShape_;
        // ::Latitude::Latitude latitude_sum;
        // ::Longitude::Longitude longitude_sum;
        // ::Altitude::Altitude altitude_sum;
        // for (auto traffic_sign_point : traffic_sign.trafficSignPoints_)
        // {
        //     latitude_sum += traffic_sign_point.latitude_;
        //     longitude_sum += traffic_sign_point.longitude_;
        //     altitude_sum += traffic_sign_point.altitude_;
        // }
        // path_traffic_signs.Latitude_ref = latitude_sum / traffic_sign.trafficSignPoints_.size();
        // path_traffic_signs.Longitude_ref = longitude_sum / traffic_sign.trafficSignPoints_.size();
        // path_traffic_signs.Altitude_ref = altitude_sum / traffic_sign.trafficSignPoints_.size();
        path_traffic_signs.Latitude_ref = traffic_sign.trafficSignPoints_.begin()->latitude_;
        path_traffic_signs.Longitude_ref = traffic_sign.trafficSignPoints_.begin()->longitude_;
        path_traffic_signs.Altitude_ref = traffic_sign.trafficSignPoints_.begin()->altitude_;
        traffic_signs.push_back(path_traffic_signs);
    }

    // EHROUT: link infos
    link_infos.clear();
    for (auto lane_model : lane_model_result_)
    {
        ::LinkInfo::LinkInfo link_info;
        link_info.InstanceId_ref = lane_model.instanceId_;
        link_info.PathId_ref = lane_model.pathId_;
        link_info.PathOffset_ref = lane_model.offset_;
        link_info.EndOffset_ref = lane_model.endOffset_;
        link_info.TotalNumLane_ref = lane_model.totalNumLane_;
        // LinkInfo.LaneInfos
        for(auto item : lane_model.laneInfos_)
        {
            ::LaneInfo::LaneInfo lane_info;
            lane_info.LaneNum_ref = item.laneNum_;
            lane_info.Direction_ref = (Direction::Direction)item.direction_;
            lane_info.Transit_ref = (Transit::Transit)item.transit_;
            lane_info.LaneType_ref = (LaneType::LaneType)item.laneType_;
            lane_info.LaneAppType_ref = (LaneAppType::LaneAppType)item.laneAppType_;
            lane_info.Centeline_ref = (Centeline::Centeline)item.centerLine_;
            lane_info.L_Bound_ref = (L_Bound::L_Bound)item.l_bound_;
            lane_info.R_Bound_ref = (R_Bound::R_Bound)item.r_bound_;
            link_info.LaneInfos_ref.push_back(lane_info);
        }
        link_infos.push_back(link_info);
    }

    // EHROUT: linear objects???
    linear_objects.clear();
    for (auto linear_object_in : linear_object_result_)
    {
        ::LinearObject::LinearObject linear_object;
        linear_object.InstanceId_ref = linear_object_in.instanceId_;
        linear_object.PathId_ref = linear_object_in.pathId_;
//        linear_object.LaneNumber_ref = linear_object_in.laneNumber_;
//        linear_object.PathOffset_ref = linear_object_in.offset_;
//        linear_object.EndOffset_ref = linear_object_in.endOffset_;
        for(auto linear_item : linear_object_in.linearObject_Items_)
        {
            linear_object. IDLinearObject_ref = linear_item.id_;
            linear_object. LinearObjectType_ref = (::LinearObjectType::LinearObjectType)linear_item.type_;
            linear_object. LinearObjectColour_ref = (::LinearObjectColour::LinearObjectColour)linear_item.colour_;
            linear_object. LinearObjectmarking_ref = (::LinearObjectmarking::LinearObjectmarking)linear_item.marking_;
            linear_object. LinearObjectIsBold_ref = (::LinearObjectIsBold::LinearObjectIsBold)linear_item.isBold_;
            auto it_lane_geometry = std::find_if(lane_geometry_result_.begin(), lane_geometry_result_.end(), [&](const LaneGeometry& lane_geometry){
                return lane_geometry.idLine_ == linear_object.IDLinearObject_ref;
            });
            if (it_lane_geometry != lane_geometry_result_.end())
            {
                linear_object.LinearObjectCurveType_ref = (::LinearObjectCurveType::LinearObjectCurveType)it_lane_geometry->curveType_;
                linear_object.PointCount_ref = it_lane_geometry->pointCount_;

                linear_object.LaneNumber_ref = it_lane_geometry->laneNumber_;
                linear_object.PathOffset_ref = it_lane_geometry->offset_;
                linear_object.EndOffset_ref = it_lane_geometry->endOffset_;

                linear_object.GeometryPoints_ref.clear();
                for(auto point : it_lane_geometry->lanePoints_)
                {
                    ::GeometryPoint::GeometryPoint  geometry_point;
                    geometry_point.Latitude_ref = point.latitude_;
                    geometry_point.Longitude_ref = point.longitude_;
                    geometry_point.Altitude_ref = point.altitude_;
                    linear_object.GeometryPoints_ref.push_back(geometry_point);
                }
            }
            else
            {
                continue;
            }
            linear_objects.push_back(linear_object);
        }
    }

}

void EhpProcess::noaUpdate()
{
    // EHROUT: noa_info
    memset(&noa_info_, 0, sizeof(noa_info_));

    //maybe the position not in the first route link
    if(!route_list_result_.linkId_.empty()){
        noa_info_.NavigationStatus_ref = (::NavigationStatus::NavigationStatus)switch_result_.navigationStatus_;
        noa_info_.MatchingStatus_ref = (::MatchingStatus::MatchingStatus)switch_result_.matchingStatus_;
        noa_info_.RemainDistance_ref = (::RemainDistance::RemainDistance)switch_result_.remainDistance_;
        noa_info_.SwitchLaneDirection_ref = (::SwitchLaneDirection::SwitchLaneDirection)switch_result_.switchLaneDirection_;
        noa_info_.SwitchLaneReason_ref = (::SwitchLaneReason::SwitchLaneReason)switch_result_.switchLaneReason_;
        noa_info_.SwitchLaneDistance_ref = switch_result_.switchLaneDistance_;
        noa_info_.SwitchLaneEndDistance_ref = switch_result_.switchLaneEndDistance_;
        noa_info_.Count_ref = switch_result_.lineCount_;

        auto iter = route_list_result_.linkId_.begin();
        //find the first link
        while(*iter != position_result_.roadID_){
            iter++;
        }

        for (int i = 0; i < noa_info_.Count_ref; i++)
        {
            ::PairOfId::PairOfId pair_of_id;

            pair_of_id.InstanceId_ref = *iter++;

            pair_of_id.LinearObjectId_ref = switch_result_.linearObjectIds_.at(i);
            auto it_lane_model = std::find_if(lane_model_result_.begin(), lane_model_result_.end(), [&](const LaneModel& lane_model){
                return lane_model.instanceId_ == pair_of_id.InstanceId_ref;
            });
            if (it_lane_model != lane_model_result_.end())
            {
                pair_of_id.PathId_ref = it_lane_model->pathId_;
                // std::cout << it_lane_model->pathId_<< std::endl;

                auto it_lane_info = std::find_if(it_lane_model->laneInfos_.begin(), it_lane_model->laneInfos_.end(), [&](const LaneInfo& lane_info){
                    return lane_info.centerLine_ == pair_of_id.LinearObjectId_ref;
                });
                if (it_lane_info != it_lane_model->laneInfos_.end())
                {
                    pair_of_id.LaneNumber_ref = it_lane_info->laneNum_;
                    noa_info_.PairOfIds_ref.push_back(pair_of_id);
                }
                else
                {
                    std::cout << "noa:\t" << "No certain lane info found!" << std::endl;
                }
            }
            else
            {
                std::cout << "noa:\t" << "No certain lane model found!" <<  std::endl;

            }
        }
    }
}

void EhpProcess::ehpDecoder(std::vector<unsigned char>& unit_array)
{
    // Delate unuseful data
    // unit_array.erase(unit_array.begin(), unit_array.begin()+42);

    //common header decoder
    HeaderDecoder header_decoder;
    if(!header_decoder.dataCheckValid(unit_array)){
        std::cout << "Date check failed!";
        return;
    }
    header_decoder.decode(unit_array);
    header_result_ = header_decoder.getResult();
    unit_array.erase(unit_array.begin(), unit_array.begin()+44);

    //    std::cout << "counter:" << header_result_.e2eCounter_ << ",partCount:" << header_result_.plhPartCount_
    //              << ",partIndex:" << header_result_.plhPartIndex_ << ",bundleId:" << header_result_.plhBundleId_
    //              << ",reserved:" << int(header_result_.aishReserved_) << ",cycCounter:" << int(header_result_.aishCycCounter_)
    //              << ",MsgType:" << int(header_result_.aishMsgType_) << ",MsgCount:" << int(header_result_.aishMsgCount_) << "," <<std::endl;

    switch(header_result_.e2eDataId_)
    {
        case 0x03000001:
        {
            PosDataDecoder position_decoder;
            position_decoder.decode(unit_array);
            auto res = position_decoder.getResult();
            position_result_ = res;
            posLog();
            break;
        }

        case 0x03000002:
        {
            PathControlDecoder path_control_decoder;
            path_control_decoder.decode(unit_array);
            auto res = path_control_decoder.getResult();
            path_control_result_ = res;
            process_path();
            break;  
        }

        case 0x03000003:
        {
            GlbDataDecoder global_data_decoder;
            global_data_decoder.decode(unit_array);
            global_data_result_ = global_data_decoder.getResult();
            break;
        }
        
        case 0x03000004:
        {
            ProfileControlDecoder profile_control_decoder;
            profile_control_decoder.decode(unit_array);
            profile_control_result_ = profile_control_decoder.getResult();
            process_profile();
            break;
        }

        case 0x03000005:
        {
            NodeDecoder node_decoder;
            node_decoder.decode(unit_array);
            auto res = node_decoder.getResult();
            node_result_.push_back(res);
            break;
        }

        case 0x03000006:
        {
            LaneModelDecoder lane_model_decoder;
            lane_model_decoder.decode(unit_array);
            auto res = lane_model_decoder.getResult();
            lane_model_result_.push_back(res);
            break;
        }

        case 0x03000007:
        {
            LaneConnectDecoder lane_connect_decoder;
            lane_connect_decoder.decode(unit_array);
            lane_connect_result_.push_back(lane_connect_decoder.getResult());
            break;
        }

        case 0x03000008:
        {
            LinearObjectDecoder linear_object_decoder;
            linear_object_decoder.decode(unit_array);
            auto res = linear_object_decoder.getResult();
            linear_object_result_.push_back(res);
            break;
        }

        case 0x03000009:
        {
            LaneGeomDecoder lane_geometry_decoder;
            lane_geometry_decoder.decode(unit_array);
            LaneGeometry res = lane_geometry_decoder.getResult();

            //lane geo input log
            geoIn(res);

            auto iter = std::find_if(lane_geometry_result_.begin(),lane_geometry_result_.end(), [res](const LaneGeometry& iter){
                return iter.pathId_ == res.pathId_ && iter.instanceId_ == res.instanceId_ && iter.idLine_ == res.idLine_ && iter.offset_ != res.offset_;
            });
            if(iter == lane_geometry_result_.end())
            {
                lane_geometry_result_.push_back(res);
            }
            else
            {
                iter->lanePoints_.insert(iter->lanePoints_.end(), res.lanePoints_.begin(), res.lanePoints_.end());
                iter->endOffset_ = res.endOffset_;
                iter->pointCount_ = iter->lanePoints_.size();
            }
            break;
        }

        case 0x0300000a:
        {
            CurvatesDecoder curvatures_decoder;
            curvatures_decoder.decode(unit_array);
            auto res = curvatures_decoder.getResult();

            auto iter = std::find_if(curvatures_result_.begin(),curvatures_result_.end(),[res](const Curvatures& iter){
                return iter.pathId_ == res.pathId_ && iter.instanceId_ == res.instanceId_ && iter.laneNumber_ == res.laneNumber_ && iter.offset_ != res.offset_;
            });
            if(iter == curvatures_result_.end())
            {
                curvatures_result_.push_back(res);
            }
            else
            {
                iter->curvatures_.insert(iter->curvatures_.end(), res.curvatures_.begin(), res.curvatures_.end());
                iter->endOffset_ = res.endOffset_;
                iter->curCount_ = iter->curvatures_.size();
            }
            break;
        }

        case 0x0300000b:
        {
            SlopesDecoder slopes_decoder;
            slopes_decoder.decode(unit_array);
            auto res = slopes_decoder.getResult();
            auto iter = std::find_if(slopes_result_.begin(),slopes_result_.end(),[res](const Slopes& iter){
                return iter.pathId_ == res.pathId_ && iter.instanceId_ == res.instanceId_ && iter.laneNumber_ == res.laneNumber_ && iter.offset_ != res.offset_;
            });
            if(iter == slopes_result_.end())
            {
                slopes_result_.push_back(res);
            }
            else
            {
                iter->slopes_.insert(iter->slopes_.end(),res.slopes_.begin(),res.slopes_.end());
                iter->endOffset_ = res.endOffset_;
                iter->slopeCount_ = iter->slopes_.size();
            }
            break;
        }

        case 0x0300000c:
        {
            SpdLimitDecoder speed_limit_decoder;
            speed_limit_decoder.decode(unit_array);
            auto res = speed_limit_decoder.getResult();
            speed_limit_result_.push_back(res);
            break;
        }

        case 0x0300000d:
        {
            RoadGeomDecoder road_geometry_decoder;
            road_geometry_decoder.decode(unit_array);
            auto res = road_geometry_decoder.getResult();

            auto iter = std::find_if(road_geometry_result_.begin(),road_geometry_result_.end(), [res](const RoadGeometry& iter){
                return iter.pathId_ == res.pathId_ && iter.instanceId_ == res.instanceId_ && iter.offset_ != res.offset_;
            });
            if(iter == road_geometry_result_.end())
            {
                road_geometry_result_.push_back(res);
            }
            else
            {
                iter->roadPoints_.insert(iter->roadPoints_.end(), res.roadPoints_.begin(), res.roadPoints_.end());
                iter->endOffset_ = res.endOffset_;
                iter->geoCount_ = iter->roadPoints_.size();
            }
            break;
        }

        case 0x0300000e:
        {
            NumOfLaneDecoder num_of_lane_decoder;
            num_of_lane_decoder.decode(unit_array);
            auto res = num_of_lane_decoder.getResult();
            num_of_lane_result_.push_back(res);
            break;
        }

        case 0x0300000f:
        {
            LinkIdDecoder link_id_decoder;
            link_id_decoder.decode(unit_array);
            auto res = link_id_decoder.getResult();
            link_id_result_.push_back(res);
            break;
        }

        case 0x03000010:
        {
            FuncClassDecoder func_class_decoder;
            func_class_decoder.decode(unit_array);
            auto res = func_class_decoder.getResult();
            func_class_result_.push_back(res);
            break;
        }

        case 0x03000011:
        {
            FormOfWayDecoder form_of_way_decoder;
            form_of_way_decoder.decode(unit_array);
            auto res = form_of_way_decoder.getResult();
            form_of_way_result_.push_back(res);
            break;
        }

        case 0x03000012:
        {
            TunnelDecoder tunnel_decoder;
            tunnel_decoder.decode(unit_array);
            auto res = tunnel_decoder.getResult();
            tunnel_result_.push_back(res);
            break;
        }

        case 0x03000013:
        {
            LaneWidthDecoder lane_width_decoder;
            lane_width_decoder.decode(unit_array);
            auto res = lane_width_decoder.getResult();
            lane_width_result_.push_back(res);
            break;
        }

        case 0x03000014:
        {
            SwitchInfoDecoder switch_decoder;
            switch_decoder.decode(unit_array);
            switch_result_ = switch_decoder.getResult();
            break;
        }

        case 0x03000017:
        {
            RouteListDecoder route_list_decoder;
            route_list_decoder.decode(unit_array);
            route_list_result_ = route_list_decoder.getResult();
            break;
        }

        case 0x0300001a:
        {
            GeofenceDecoder geofence_decoder;
            geofence_decoder.decode(unit_array);
            geofence_result_.push_back(geofence_decoder.getResult());
            break;
        }

        case 0x0300001b:
        {
            MergePointDecoder merge_point_decoder;
            merge_point_decoder.decode(unit_array);
            merge_point_result_.push_back(merge_point_decoder.getResult());
            break;
        }

        case 0x0300001d:
        {
            TrafficSignDecoder traffic_sign_decoder;
            traffic_sign_decoder.decode(unit_array);
            traffic_sign_result_.push_back(traffic_sign_decoder.getResult());
            break;
        }

        case 0x0300001e:
        {
            GantryDecoder gantry_decoder;
            gantry_decoder.decode(unit_array);
            gantry_result_.push_back(gantry_decoder.getResult());
            break;
        }

        case 0x0300001f:
        {
            PoleDecoder pole_decoder;
            pole_decoder.decode(unit_array);
            pole_result_.push_back(pole_decoder.getResult());
            break;
        }

        case 0x03000020:
        {
            GroundArrowDecoder ground_arrow_decoder;
            ground_arrow_decoder.decode(unit_array);
            ground_arrow_result_.push_back(ground_arrow_decoder.getResult());
            break;
        }

        case 0x03000021:
        {
            GroundTextDecoder ground_text_decoder;
            ground_text_decoder.decode(unit_array);
            ground_text_result_.push_back(ground_text_decoder.getResult());
            break;
        }

        case 0x03000022:
        {
            TollGateDecoder toll_gate_decoder;
            toll_gate_decoder.decode(unit_array);
            toll_gate_result_.push_back(toll_gate_decoder.getResult());
            break;
        }

        default:
            break;
    }
}

void EhpProcess::process(std::vector<unsigned char>& unit_array)
{
    ehpDecoder(unit_array);

    //cycle message noa
    if(header_result_.plhPartCount_ == 1)
    {
        if(header_result_.e2eDataId_ == 0x03000017)
        {
            //update noa
            noaUpdate();

            // noa log
            // noaLog();
        }
    }
    //eventrigger
    else{
        // rebuild horizon after recieve whole bundle
        if(header_result_.plhPartCount_ == header_result_.plhPartIndex_+1)
        {
            //ehr pool log
            // mapLog();
            // laneConnectLog();
            // spdLimitLog();
            // mergePointLog();
            // nodeLog();
            
            std::cout << "*****************ehr out start*****************"<<std::endl;
            buf_mutex_.lock();
            mapUpdate(link_merge_points_, form_of_ways_, geofences_, lane_connectivitys_, lane_speed_limits_, lane_widthes_, 
            link_curvatures_, link_infos_, link_slopes_, noa_info_, linear_objects_, nodes_, traffic_signs_);
            buf_mutex_.unlock();
            std::cout << "*****************ehr out end*****************"<<std::endl;

            //ehr output log
            // geoOut();
        }
    }
}

}// end of namespace


