// Created by Qi.Zhang on 2023/03/08

#include "decoder_common.h"


namespace ehp_decoder
{
bool DecoderCommon::dataCheckValid(std::vector<unsigned char>& input)
{ 
    if(input.empty())
        return false;
    //delete unuseful data, including version, environment...
    input.erase(input.begin(),input.begin()+42);
    //get origin checksum
    Uint32Decoder check_sum_decoder;
    memset(check_sum_decoder.data_,0,sizeof(check_sum_decoder.data_));
    std::copy(input.begin()+8,input.begin()+12,check_sum_decoder.data_);
    uint32_t origin_checksum=check_sum_decoder.result_;
    //erase checksum and compute locally
    input.erase(input.begin()+8,input.begin()+12);
    uint32_t sum_16_bits=0;
    std::size_t reached_index=0;
    for(;reached_index<input.size()-1;reached_index+=2){
        memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
        std::copy(input.begin()+reached_index,input.begin()+reached_index+2,uint16Decoder_.data_);
        sum_16_bits+=uint16Decoder_.result_;
    }
    if(reached_index < input.size()){
        //there is a single byte
        memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
        uint16Decoder_.data_[0]=input.at(reached_index);
        sum_16_bits+=uint16Decoder_.result_;
    }
    while(sum_16_bits > 0xFFFF){
        //add high 16 bits and low 16 bits
        uint32_t low_16_bits= sum_16_bits & 0x0000FFFF;
        uint32_t high_16_bits=(sum_16_bits & 0xFFFF0000) >> 16;
        sum_16_bits=low_16_bits + high_16_bits;
    }
    uint16_t raw_checksum=static_cast<uint16_t>(sum_16_bits);
    //invert all bits
    uint16_t checksum=~raw_checksum;
    uint32_t checksum_32bits=static_cast<uint32_t>(checksum);
    return origin_checksum==checksum_32bits;
}
} // end of namespace 
