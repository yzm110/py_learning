// Created by Zhiying.Chen on 2023/03/13

#include "HeaderDecoder.h"

namespace ehp_decoder
{
void HeaderDecoder::decode(const std::vector<unsigned char> &input){
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;
    
    result_.e2eLength_ = decodeUint16(input,start_index);
    result_.e2eCounter_ = decodeUint16(input,start_index);
    result_.e2eDataId_ = decodeUint32(input,start_index);
    result_.e2eChecksum_ = decodeUint32(input,start_index);

    result_.tsReserved_ = decodeUint8(input,start_index);
    result_.tsValid_ = decodeBoolean(input,start_index);
    result_.tsWeek_ = decodeUint16(input,start_index);
    result_.tsMs_ = decodeUint64(input,start_index);
    result_.tsSysTime_ = decodeUint64(input,start_index);

    result_.plhPartCount_ = decodeUint16(input,start_index);
    result_.plhPartIndex_ = decodeUint16(input,start_index);
    result_.plhBundleId_ = decodeUint32(input,start_index);

    result_.aishReserved_ = decodeUint8(input,start_index);
    result_.aishCycCounter_ = decodeUint8(input,start_index);
    result_.aishMsgType_ = decodeUint8(input,start_index);
    result_.aishMsgCount_ = decodeUint8(input,start_index);

    return;
}
} // namespace of ehp_decoder
