//
// Created by jian.jiang on 2022/9/30.
//

#include "GlobalDataDecoder.h"
namespace ehp_decoder
{
void GlbDataDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.proT_0_= decodeUint8(input,start_index);
    result_.proA_0_= decodeBoolean(input,start_index);
    result_.drivSide= decodeUint8(input,start_index);

    result_.proT_1_= decodeUint8(input,start_index);
    result_.proA_1_= decodeBoolean(input,start_index);
    result_.countryCode = decodeUint32(input,start_index);

    result_.proT_2_= decodeUint8(input,start_index);
    result_.proA_2_= decodeBoolean(input,start_index);
    result_.unitSystem = decodeUint8(input,start_index);

    result_.proT_3_= decodeUint8(input,start_index);
    result_.proA_3_= decodeBoolean(input,start_index);
    result_.verProtocol = decodeUint32(input,start_index);

    result_.proT_4_= decodeUint8(input,start_index);
    result_.proA_4_= decodeBoolean(input,start_index);
    result_.versionHW = decodeUint32(input,start_index);

    result_.proT_5_= decodeUint8(input,start_index);
    result_.proA_5_= decodeBoolean(input,start_index);
    result_.versionMap = decodeUint32(input,start_index);

    result_.proT_6_= decodeUint8(input,start_index);
    result_.proA_6_= decodeBoolean(input,start_index);
    result_.mapAge = decodeUint32(input,start_index);

    result_.proT_7_= decodeUint8(input,start_index);
    result_.proA_7_= decodeBoolean(input,start_index);
    result_.mapProvider = decodeUint32(input,start_index);

    result_.proT_8_= decodeUint8(input,start_index);
    result_.proA_8_= decodeBoolean(input,start_index);
    result_.guidance = decodeUint32(input,start_index);

    result_.proT_9_= decodeUint8(input,start_index);
    result_.proA_9_= decodeBoolean(input,start_index);
    result_.regionCode= decodeUint32(input,start_index);
    result_.simulation= decodeUint8(input,start_index);

    return ;
}
} // namespace of ehp_decoder