//
// Created by jian.jiang on 2022/9/28.
//

#include "RouteListDecoder.h"
namespace ehp_decoder
{
void RouteListDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));

    std::size_t start_index=0;
    result_.hdmapVersion_= decodeUint32(input,start_index);
    result_.linkCount_= decodeUint16(input,start_index);

    while(start_index + 4 <= input.size()){
        result_.linkId_.push_back(decodeUint32(input,start_index));
    }
}
} // namespace of ehp_decoder