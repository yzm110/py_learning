//
// Created by jian.jiang on 2022/9/29.
//

#include "NodeDecoder.h"
namespace ehp_decoder
{
void NodeDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_=decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.count_= decodeUint8(input,start_index);
    while(start_index + 14 <= input.size()){
        NodeItem node_item;
        memset(&node_item,0,sizeof(node_item));
        node_item.subPath_= decodeUint32(input,start_index);
        node_item.probability_= decodeFloat(input,start_index);
        node_item.turnAngle_= decodeFloat(input,start_index);
        node_item.compIntSec_= decodeBoolean(input,start_index);
        node_item.rightOfWay_= decodeUint8(input,start_index);
        result_.nodeItems_.emplace_back(std::move((node_item)));
    }
}
} // namespace of ehp_decoder
