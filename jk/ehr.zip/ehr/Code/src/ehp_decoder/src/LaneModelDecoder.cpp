//
// Created by jian.jiang on 2022/9/29.
//

#include "LaneModelDecoder.h"
namespace ehp_decoder
{
void LaneModelDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_=decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.totalNumLane_= decodeUint8(input,start_index);
    while(start_index + 23 <= input.size()){
        LaneInfo lane_info;
        memset(&lane_info,0,sizeof(lane_info));
        lane_info.laneNum_= decodeUint8(input,start_index);
        lane_info.direction_= decodeUint8(input,start_index);
        lane_info.transit_= decodeUint8(input,start_index);
        lane_info.laneType_= decodeUint32(input,start_index);
        lane_info.laneAppType_= decodeUint32(input,start_index);
        lane_info.centerLine_= decodeUint32(input,start_index);
        lane_info.l_bound_= decodeUint32(input,start_index);
        lane_info.r_bound_= decodeUint32(input,start_index);
        result_.laneInfos_.emplace_back(std::move((lane_info)));
    }
}
} // namespace of ehp_decoder