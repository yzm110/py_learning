//
// Created by jian.jiang on 2022/9/28.
//

#include "SwitchInfoDecoder.h"
namespace ehp_decoder
{
void SwitchInfoDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));

    std::size_t start_index=0;
    result_.navigationStatus_= decodeUint8(input,start_index);
    result_.matchingStatus_= decodeUint8(input,start_index);
    result_.remainDistance_= decodeUint32(input,start_index);
    result_.switchLaneDirection_= decodeUint8(input,start_index);
    result_.switchLaneReason_= decodeUint8(input,start_index);
    result_.switchLaneDistance_= decodeUint16(input,start_index);
    result_.switchLaneEndDistance_= decodeUint16(input,start_index);
    result_.lineCount_= decodeUint16(input,start_index);

    while(start_index+4 <= input.size()){
       result_.linearObjectIds_.push_back(decodeUint32(input,start_index));
    }

}
} // namespace of ehp_decoder
