//
// Created by jian.jiang on 2022/9/27.
//

#include "PosDataDecoder.h"

#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
namespace ehp_decoder
{
void PosDataDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));

    std::size_t start_index=0;
    result_.roadID_= decodeUint64(input,start_index);
    result_.laneID_= decodeUint64(input,start_index);
    result_.laneSeq_= decodeUint8(input,start_index);
    result_.disLeft_= decodeUint32(input,start_index);
    result_.disRight_=decodeUint32(input,start_index);
    result_.headLeft_= decodeFloat(input,start_index);
    result_.headRight_= decodeFloat(input,start_index);
    result_.lon_= decodeInt32(input,start_index);
    result_.lat_=decodeInt32(input,start_index);
    result_.heading_= decodeFloat(input,start_index);
    result_.lon_std_= decodeFloat(input,start_index);
    result_.lat_std_=decodeFloat(input,start_index);
    result_.confidence_= decodeUint8(input,start_index);
    result_.xAcc_= decodeFloat(input,start_index);
    result_.yAcc_=decodeFloat(input,start_index);
    result_.zAcc_=decodeFloat(input,start_index);
    result_.angular_velocity_x_=decodeFloat(input,start_index);
    result_.angular_velocity_y_=decodeFloat(input,start_index);
    result_.angular_velocity_z_=decodeFloat(input,start_index);
    result_.geofence_judge_status_= decodeUint8(input,start_index);
    result_.geofence_judge_type_=decodeUint8(input,start_index);
    result_.timestamp_= decodeUint64(input,start_index);
    result_.positionage_=decodeUint64(input,start_index);
    result_.pathid_= decodeUint32(input,start_index);
    result_.offset_=decodeUint32(input,start_index);
    result_.accuracy_= decodeUint32(input,start_index);
    result_.deviation_= decodeInt32(input,start_index);
    result_.speed_= decodeFloat(input,start_index);
    result_.relative_H_= decodeFloat(input,start_index);
    result_.probability_= decodeFloat(input,start_index);
    result_.currentLane_= decodeUint8(input,start_index);
    result_.preferPath_= decodeUint32(input,start_index);
    result_.failsafe_loc_status_= decodeUint8(input,start_index);
    result_.failsafe_gnss_status_= decodeUint8(input,start_index);
    result_.failsafe_camera_status_= decodeUint8(input,start_index);
    result_.failsafe_hdmap_status_= decodeUint8(input,start_index);
    result_.failsafe_vehicle_status_= decodeUint8(input,start_index);
    result_.failsafe_imu_status_= decodeUint8(input,start_index);
    result_.failsafe_other_status_= decodeUint8(input,start_index);

}
} // namespace of ehp_decoder
