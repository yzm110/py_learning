//
// Created by jian.jiang on 2022/9/29.
//

#include "LinearObjectDecoder.h"
namespace ehp_decoder
{
void LinearObjectDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_=decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.totalNumObj_= decodeUint8(input,start_index);
    while(start_index + 8 <= input.size()){
        LinearObject_Item linearObject_Item;
        memset(&linearObject_Item,0,sizeof(linearObject_Item));
        linearObject_Item.id_ = decodeUint32(input,start_index);
        linearObject_Item.type_ = decodeUint8(input,start_index);
        linearObject_Item.marking_ = decodeUint8(input,start_index);
        linearObject_Item.colour_ = decodeUint8(input,start_index);
        linearObject_Item.isBold_ = decodeUint8(input,start_index);
        result_.linearObject_Items_.emplace_back(std::move((linearObject_Item)));
    }
}
} // namespace of ehp_decoder
