//
// Created by jian.jiang on 2022/9/29.
//

#include "LaneConnectDecoder.h"
namespace ehp_decoder
{
void LaneConnectDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_=decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.count_= decodeUint8(input,start_index);
    while(start_index + 14<= input.size()){
        LaneConnectItem laneConnect_item;
        memset(&laneConnect_item,0,sizeof(laneConnect_item));
        laneConnect_item.initLaneNum_ = decodeUint8(input,start_index);
        laneConnect_item.initPath_ = decodeUint32(input,start_index);
        laneConnect_item.newLaneNum_ = decodeUint8(input,start_index);
        laneConnect_item.newPath_ = decodeUint32(input,start_index);
        laneConnect_item.toLinkId_ = decodeUint32(input,start_index);
        result_.laneConnectItems_.emplace_back(std::move((laneConnect_item)));
    }
}
} // namespace of ehp_decoder
