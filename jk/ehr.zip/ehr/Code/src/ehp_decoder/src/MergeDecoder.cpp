//
// Created by jian.jiang on 2022/9/29.
//

#include "MergeDecoder.h"
namespace ehp_decoder
{
void MergePointDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_=decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.mergePointCount_= decodeUint8(input,start_index);
    while(start_index + 9 <= input.size()){
        MergePointItem mergePoint_item;
        memset(&mergePoint_item,0,sizeof(mergePoint_item));
        mergePoint_item.pathId_= decodeUint32(input,start_index);
        mergePoint_item.offset_= decodeUint32(input,start_index);
        mergePoint_item.isMaster_= decodeBoolean(input,start_index);
        result_.mergePointItems_.emplace_back(std::move((mergePoint_item)));
    }
}
}
