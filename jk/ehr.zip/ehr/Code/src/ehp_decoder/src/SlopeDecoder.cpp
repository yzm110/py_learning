//
// Created by jian.jiang on 2022/9/30.
//

#include "SlopeDecoder.h"

namespace ehp_decoder
{
 void SlopesDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_= decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.slopeCount_= decodeUint8(input,start_index);
    while(start_index + 12 <= input.size()){
        Slope slope;
        memset(&slope,0,sizeof(slope));
        slope.offset_= decodeUint32(input,start_index);
        slope.slope_= decodeFloat(input,start_index);
        slope.crossSlope_= decodeFloat(input,start_index);
        result_.slopes_.emplace_back(std::move(slope));
    }

    return;
}
} // namespace of ehp_decoder