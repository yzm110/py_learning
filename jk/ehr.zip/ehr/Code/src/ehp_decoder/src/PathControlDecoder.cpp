//
// Created by jian.jiang on 2022/9/30.
//

#include "PathControlDecoder.h"
namespace ehp_decoder
{
void PathControlDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.idFirst_= decodeUint32(input,start_index);
    result_.idLast_= decodeUint32(input,start_index);
    result_.pathCount_= decodeUint8(input,start_index);
    result_.isReset_= decodeUint8(input,start_index);
    while(start_index + 12 <= input.size()){
        PathControlItem path_item;
        memset(&path_item,0,sizeof(path_item));
        path_item.id_= decodeUint32(input,start_index);
        path_item.parentId_= decodeUint32(input,start_index);
        path_item.offset_= decodeUint32(input,start_index);
        result_.pathItems_.emplace_back(std::move((path_item)));
    }

    return ;
}
} // namespace of ehp_decoder
