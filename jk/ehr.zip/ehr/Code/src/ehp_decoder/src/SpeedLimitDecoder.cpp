//
// Created by jian.jiang on 2022/9/30.
//

#include "SpeedLimitDecoder.h"

namespace ehp_decoder
{
 void SpdLimitDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;

    result_.instanceId_= decodeUint32(input,start_index);
    result_.retransmis_= decodeBoolean(input,start_index);
    result_.change_= decodeUint8(input,start_index);
    result_.confidence_= decodeFloat(input,start_index);
    result_.pathId_= decodeUint32(input,start_index);
    result_.laneNumber_= decodeUint8(input,start_index);
    result_.offset_= decodeUint32(input,start_index);
    result_.endOffset_= decodeUint32(input,start_index);
    result_.endOffsetF_= decodeBoolean(input,start_index);
    result_.interpolat_= decodeUint8(input,start_index);
    result_.type_= decodeUint8(input,start_index);
    result_.available_= decodeBoolean(input,start_index);
    result_.value_H_= decodeUint8(input,start_index);
    result_.value_L_= decodeUint8(input,start_index);
    result_.uint_= decodeUint8(input,start_index);
    
    return;
}
} // namespace of ehp_decoder