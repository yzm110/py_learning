  //
// Created by jian.jiang on 2022/9/30.
//

#include "ProfileControlDecoder.h"
#include <iostream>
namespace ehp_decoder
{
void ProfileControlDecoder::decode(const std::vector<unsigned char> &input) {
    memset(&result_,0,sizeof(result_));
    std::size_t start_index=0;
    while(start_index + 8 <= input.size()){
        ProfileControlItem profile_item;
        memset(&profile_item,0,sizeof(profile_item));
        profile_item.pathId_= decodeUint32(input,start_index);
        profile_item.offset_= decodeUint32(input,start_index);
        result_.profileItems_.emplace_back(std::move((profile_item)));
        // std::cout<<"debug"<<std::endl;
    }
    return ;
}
} // namespace of ehp_decoder
