//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_LINEAROBJECTDECODER_H
#define EHR_LINEAROBJECTDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct LinearObject_Item{
    uint32_t id_;
    uint8_t type_;
    uint8_t marking_;
    uint8_t colour_;
    uint8_t isBold_;
};

struct LinearObject{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t totalNumObj_;
    std::vector<LinearObject_Item> linearObject_Items_;
};


class LinearObjectDecoder:public DecoderBase<struct LinearObject>{
public:
    LinearObjectDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};


#endif //EHR_LINEAROBJECTDECODER_H
} // namespace of ehp_decoder 
