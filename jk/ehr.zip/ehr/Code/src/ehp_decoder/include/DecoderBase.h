//
// Created by jian.jiang on 2022/9/28.
//

#ifndef EHR_DECODERBASE_H
#define EHR_DECODERBASE_H

#include <vector>
#include <cstring>
#include <cstdint>
#include <algorithm>

namespace ehp_decoder
{
union Uint64Decoder{
    unsigned char data_[8];
    uint64_t result_;
};
union Uint32Decoder{
    unsigned char data_[4];
    uint32_t result_;
};
union Uint16Decoder{
    unsigned char data_[2];
    uint16_t result_;
};
union Uint8Decoder{
    unsigned char data_;
    uint8_t result_;
};
union Int32Decoder{
    unsigned char data_[4];
    int32_t result_;
};
union FloatDecoder{
    unsigned char data_[4];
    float result_;
};

union BooleanDecoder{
    unsigned char data_;
    bool result_;
};

template <typename T>
class DecoderBase{
public:
    virtual void decode(const std::vector<unsigned char>& input)=0;
    T getResult(){
        return result_;
    }

    bool dataCheckValid(std::vector<unsigned char> input){
        if(input.empty())
            return false;
        //delete unuseful data
        // XXX: why 42
//        input.erase(input.begin(),input.begin()+42);
        // XXX: what is checksum
        //get origin checksum
        Uint32Decoder check_sum_decoder;
        memset(check_sum_decoder.data_,0,sizeof(check_sum_decoder.data_));
        // XXX: what is represented in 8 ~ 12 
        std::copy(input.begin()+8,input.begin()+12,check_sum_decoder.data_);

        // XXX: 
        uint32_t origin_checksum=check_sum_decoder.result_;
        //erase checksum and compute locally
        input.erase(input.begin()+8,input.begin()+12);
        uint32_t sum_16_bits=0;
        std::size_t reached_index=0;
        for(;reached_index<input.size()-1;reached_index+=2){
            memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
            std::copy(input.begin()+reached_index,input.begin()+reached_index+2,uint16Decoder_.data_);
            sum_16_bits+=uint16Decoder_.result_;
        }
        if(reached_index < input.size()){
            //there is a single byte
            memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
            uint16Decoder_.data_[0]=input.at(reached_index);
            sum_16_bits+=uint16Decoder_.result_;
        }
        while(sum_16_bits > 0xFFFF){
            //add high 16 bits and low 16 bits
            uint32_t low_16_bits= sum_16_bits & 0x0000FFFF;
            uint32_t high_16_bits=(sum_16_bits & 0xFFFF0000) >> 16;
            sum_16_bits=low_16_bits + high_16_bits;
        }
        uint16_t raw_checksum=static_cast<uint16_t>(sum_16_bits);
        //invert all bits
        uint16_t checksum=~raw_checksum;
        uint32_t checksum_32bits=static_cast<uint32_t>(checksum);
        return origin_checksum==checksum_32bits;
    }

protected:
    uint64_t decodeUint64(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 8 > input.size())
            return 0;
        memset(uint64Decoder_.data_,0,sizeof(uint64Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+8,uint64Decoder_.data_);
        start_index+=8;
        return uint64Decoder_.result_;
    }
    uint32_t decodeUint32(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(uint32Decoder_.data_,0,sizeof(uint32Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,uint32Decoder_.data_);
        start_index+=4;
        return uint32Decoder_.result_;
    }
    uint16_t decodeUint16(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 2 > input.size())
            return 0;
        memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+2,uint16Decoder_.data_);
        start_index+=2;
        return uint16Decoder_.result_;
    }
    uint8_t decodeUint8(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 1 > input.size())
            return 0;
        memset(&uint8Decoder_.data_,0,sizeof(uint8Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+1,&uint8Decoder_.data_);
        start_index+=1;
        return uint8Decoder_.result_;
    }
    int32_t decodeInt32(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(&int32Decoder_.data_,0,sizeof(int32Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,int32Decoder_.data_);
        start_index+=4;
        return int32Decoder_.result_;
    }
    float decodeFloat(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(&floatDecoder_.data_,0,sizeof(floatDecoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,floatDecoder_.data_);
        start_index+=4;
        return floatDecoder_.result_;
    }
    bool decodeBoolean(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 1 > input.size())
            return 0;
        memset(&booleanDecoder_.data_,0,sizeof(booleanDecoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+1,&booleanDecoder_.data_);
        start_index+=1;
        return booleanDecoder_.result_;
    }
    // std:: cout << "aaaaaaaaaaa" << std::endl;
protected:
    T result_;
    Uint64Decoder uint64Decoder_;
    Uint32Decoder uint32Decoder_;
    Uint16Decoder uint16Decoder_;
    Uint8Decoder uint8Decoder_;
    Int32Decoder int32Decoder_;
    FloatDecoder floatDecoder_;
    BooleanDecoder booleanDecoder_;
};

} // namespace of ehp_decoder
#endif //EHR_DECODERBASE_H
