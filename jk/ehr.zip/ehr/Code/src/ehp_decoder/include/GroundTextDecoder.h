//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_GROUNDTEXTDECODER_H
#define EHR_GROUNDTEXTDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct GroundTextPoint{
    int32_t latitude_;
    int32_t longitud_;
    int32_t altitude_;
};

struct GroundText{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    std::vector<GroundTextPoint> groundTextPoints_;
};


class GroundTextDecoder:public DecoderBase<struct GroundText>{
public:
    GroundTextDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_GROUNDTEXTDECODER_H

} // namespace of ehp_decoder
