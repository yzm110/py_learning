//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_GLBDATADECODER_H
#define EHR_GLBDATADECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct GlbData{
    uint8_t proT_0_;
    bool proA_0_;
    uint8_t drivSide;

    uint8_t proT_1_;
    bool proA_1_;
    uint32_t countryCode;

    uint8_t proT_2_;
    bool proA_2_;
    uint8_t unitSystem;

    uint8_t proT_3_;
    bool proA_3_;
    uint32_t verProtocol;

    uint8_t proT_4_;
    bool proA_4_;
    uint32_t versionHW;

    uint8_t proT_5_;
    bool proA_5_;
    uint32_t versionMap;

    uint8_t proT_6_;
    bool proA_6_;
    uint32_t mapAge;

    uint8_t proT_7_;
    bool proA_7_;
    uint32_t mapProvider;

    uint8_t proT_8_;
    bool proA_8_;
    uint32_t guidance;
    
    uint8_t proT_9_;
    bool proA_9_;
    uint32_t regionCode;
    uint8_t simulation;
};

class GlbDataDecoder:public DecoderBase<GlbData>{
public:
    GlbDataDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_PATHCONTROLDECODER_H

} // namespace of ehp_decoder
