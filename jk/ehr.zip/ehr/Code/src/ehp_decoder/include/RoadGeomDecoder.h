//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_ROADGEOMDECODER_H
#define EHR_ROADGEOMDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{

struct RoadGeomPoint{
    int32_t latitude_;
    int32_t longitud_;
    int32_t altitude_;
};

struct RoadGeometry{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t geoCount_;
    std::vector<RoadGeomPoint> roadPoints_;
};


class RoadGeomDecoder:public DecoderBase<struct RoadGeometry>{
public:
    RoadGeomDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_ROADGEOMDECODER_H
} // namespace of ehp_decoder
