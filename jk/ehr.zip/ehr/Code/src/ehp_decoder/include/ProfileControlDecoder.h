//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_PROFILECONTROLDECODER_H
#define EHR_PROFILECONTROLDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct ProfileControlItem{
    uint32_t pathId_;
    uint32_t offset_;
};

struct ProfileControl{
    std::vector<ProfileControlItem> profileItems_;
};

class ProfileControlDecoder:public DecoderBase<ProfileControl>{
public:
    ProfileControlDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_PROFILECONTROLDECODER_H
} // namespace of ehp_decoder
