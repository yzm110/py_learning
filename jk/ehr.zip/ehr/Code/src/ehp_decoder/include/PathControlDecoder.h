//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_PATHCONTROLDECODER_H
#define EHR_PATHCONTROLDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct PathControlItem{
    uint32_t id_;
    uint32_t parentId_;
    uint32_t offset_;
};

struct PathControl{
    uint32_t idFirst_;
    uint32_t idLast_;
    uint8_t pathCount_;
    uint8_t isReset_;
    std::vector<PathControlItem> pathItems_;
};

class PathControlDecoder:public DecoderBase<PathControl>{
public:
    PathControlDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_PATHCONTROLDECODER_H
} // namespace of ehp_decoder
