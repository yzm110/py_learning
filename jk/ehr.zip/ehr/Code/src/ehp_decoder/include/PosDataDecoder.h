//
// Created by jian.jiang on 2022/9/27.
//

#ifndef EHR_POSDATADECODER_H
#define EHR_POSDATADECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct PositionData{
    uint64_t roadID_;
    uint64_t laneID_;
    uint8_t laneSeq_;
    uint32_t disLeft_;
    uint32_t disRight_;
    float headLeft_;
    float headRight_;
    int32_t  lon_;
    int32_t  lat_;
    float heading_;
    float lon_std_;
    float lat_std_;
    uint8_t confidence_;
    float xAcc_;
    float yAcc_;
    float zAcc_;
    float angular_velocity_x_;
    float angular_velocity_y_;
    float angular_velocity_z_;
    uint8_t geofence_judge_status_;
    uint8_t geofence_judge_type_;
    uint64_t timestamp_;
    uint64_t positionage_;
    uint32_t pathid_;
    uint32_t offset_;
    uint32_t accuracy_;
    int32_t  deviation_;
    float speed_;
    float relative_H_;
    float probability_;
    uint8_t currentLane_;
    uint32_t preferPath_;
    uint8_t failsafe_loc_status_;
    uint8_t failsafe_gnss_status_;
    uint8_t failsafe_camera_status_;
    uint8_t failsafe_hdmap_status_;
    uint8_t failsafe_vehicle_status_;
    uint8_t failsafe_imu_status_;
    uint16_t failsafe_other_status_;
};

class PosDataDecoder:public DecoderBase<struct PositionData>{
public:
    PosDataDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};

} // namespace of ehp_decoder
#endif //EHR_POSDATADECODER_H
