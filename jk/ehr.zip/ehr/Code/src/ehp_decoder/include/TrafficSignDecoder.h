//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_TRAFFICSIGNDECODER_H
#define EHR_TRAFFICSIGNDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct TrafficSignPoint{
    int32_t latitude_;
    int32_t longitude_;
    int32_t altitude_;
};

struct TrafficSign{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t trafficSignType_;
    uint8_t trafficSignShape_;
    std::vector<TrafficSignPoint> trafficSignPoints_;
};


class TrafficSignDecoder:public DecoderBase<struct TrafficSign>{
public:
    TrafficSignDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_TRAFFICSIGNDECODER_H
} // namespace of ehp_decoder
