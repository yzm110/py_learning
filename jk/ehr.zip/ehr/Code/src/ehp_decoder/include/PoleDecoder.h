//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_POLEDECODER_H
#define EHR_POLEDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct PolePoint{
    int32_t latitude_;
    int32_t longitud_;
    int32_t altitude_;
};

struct Pole{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t poleType_;
    std::vector<PolePoint> polePoints_;
};


class PoleDecoder:public DecoderBase<struct Pole>{
public:
    PoleDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_POLEDECODER_H
} // namespace of ehp_decoder
