//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_NUMOFLANEDECODER_H
#define EHR_NUMOFLANEDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct NumOfLane{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t numOfLane_;
};


class NumOfLaneDecoder:public DecoderBase<NumOfLane>{
public:
    NumOfLaneDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};

} //namespace of ehp_decoder
#endif //EHR_NUMOFLANEDECODER_H
