//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_GANTRYDECODER_H
#define EHR_GANTRYDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct GantryPoint{
    int32_t latitude_;
    int32_t longitud_;
    int32_t altitude_;
};

struct Gantry{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    std::vector<GantryPoint> gantryPoints_;
};


class GantryDecoder:public DecoderBase<struct Gantry>{
public:
    GantryDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_GANTRYDECODER_H

} // namespace of decoder
