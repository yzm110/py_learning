//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_LANECONNECTDECODER_H
#define EHR_LANECONNECTDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct LaneConnectItem{
    uint8_t initLaneNum_;
    uint32_t initPath_;
    uint8_t newLaneNum_;
    uint32_t newPath_;
    uint32_t toLinkId_;
};

struct LaneConnect{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t count_;
    std::vector<LaneConnectItem> laneConnectItems_;
};


class LaneConnectDecoder:public DecoderBase<struct LaneConnect>{
public:
    LaneConnectDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};


#endif //EHR_LANECONNECTDECODER_H

} // namespace of ehp_decoder
