// Created by Zhiying.Chen on 2023/03/13

#ifndef EHR_HEADERDECODER_H
#define EHR_HEADERDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct Header{
    uint16_t e2eLength_;
    uint16_t e2eCounter_;
    uint32_t e2eDataId_;
    uint32_t e2eChecksum_;

    uint8_t  tsReserved_;
    bool     tsValid_;
    uint16_t tsWeek_;
    uint64_t tsMs_;
    uint64_t tsSysTime_;

    uint16_t plhPartCount_;
    uint16_t plhPartIndex_;
    uint32_t plhBundleId_;

    uint8_t  aishReserved_;
    uint8_t  aishCycCounter_;
    uint8_t  aishMsgType_;
    uint8_t  aishMsgCount_;
};

class HeaderDecoder:public DecoderBase<struct Header>{
public:
    HeaderDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};

#endif //EHR_HEADERDECODER_H

} // namespace of decoder
