//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_LANEGEOMDECODER_H
#define EHR_LANEGEOMDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct LaneGeomPoint{
    int32_t latitude_;
    int32_t longitude_;
    int32_t altitude_;
};

struct LaneGeometry{
    uint32_t instanceId_;
  	bool  retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t geometryCount_;
    uint32_t idLine_;
    uint8_t curveType_;
    uint8_t pointCount_;
    std::vector<LaneGeomPoint> lanePoints_;
};


class LaneGeomDecoder:public DecoderBase<struct LaneGeometry>{
public:
    LaneGeomDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};


#endif //EHR_LANEGEOMDECODER_H
} // namepspace of ehp_decoder
