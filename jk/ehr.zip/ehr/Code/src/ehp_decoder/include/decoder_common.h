// Created by Qi.Zhang on 2023/03/08


#include <vector>
#include <iomanip>
#include "DecoderBase.h"
namespace ehp_decoder
{
class DecoderCommon
{
    public:
    bool dataCheckValid(std::vector<unsigned char>& input);

    private:
    Uint64Decoder uint64Decoder_;
    Uint32Decoder uint32Decoder_;
    Uint16Decoder uint16Decoder_;
    Uint8Decoder uint8Decoder_;
    Int32Decoder int32Decoder_;
    FloatDecoder floatDecoder_;
    BooleanDecoder booleanDecoder_;

    uint64_t decodeUint64(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 8 > input.size())
            return 0;
        memset(uint64Decoder_.data_,0,sizeof(uint64Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+8,uint64Decoder_.data_);
        start_index+=8;
        return uint64Decoder_.result_;
    }
    uint32_t decodeUint32(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(uint32Decoder_.data_,0,sizeof(uint32Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,uint32Decoder_.data_);
        start_index+=4;
        return uint32Decoder_.result_;
    }
    uint16_t decodeUint16(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 2 > input.size())
            return 0;
        memset(uint16Decoder_.data_,0,sizeof(uint16Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+2,uint16Decoder_.data_);
        start_index+=2;
        return uint16Decoder_.result_;
    }
    uint8_t decodeUint8(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 1 > input.size())
            return 0;
        memset(&uint8Decoder_.data_,0,sizeof(uint8Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+1,&uint8Decoder_.data_);
        start_index+=1;
        return uint8Decoder_.result_;
    }
    int32_t decodeInt32(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(&int32Decoder_.data_,0,sizeof(int32Decoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,int32Decoder_.data_);
        start_index+=4;
        return int32Decoder_.result_;
    }
    float decodeFloat(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 4 > input.size())
            return 0;
        memset(&floatDecoder_.data_,0,sizeof(floatDecoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+4,floatDecoder_.data_);
        start_index+=4;
        return floatDecoder_.result_;
    }
    bool decodeBoolean(const std::vector<unsigned char>& input,std::size_t& start_index){
        if(start_index + 1 > input.size())
            return 0;
        memset(&booleanDecoder_.data_,0,sizeof(booleanDecoder_.data_));
        std::copy(input.begin()+start_index,input.begin()+start_index+1,&booleanDecoder_.data_);
        start_index+=1;
        return booleanDecoder_.result_;
    }
};
} // end of namespace 