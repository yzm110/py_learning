//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_SLOPEDECODER_H
#define EHR_SLOPEDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct Slope{
    uint32_t offset_;
    float slope_;
    float crossSlope_;
};

struct Slopes{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t slopeCount_;
    std::vector<Slope> slopes_;
};


class SlopesDecoder:public DecoderBase<Slopes>{
public:
    SlopesDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};





#endif //EHR_SLOPEDECODER_H
} // namespace of ehp_decoder
