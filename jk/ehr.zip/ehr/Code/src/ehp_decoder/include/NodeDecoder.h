//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_NODEDECODER_H
#define EHR_NODEDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct NodeItem{
    uint32_t subPath_;
    float probability_;
    float turnAngle_;
    bool compIntSec_;
    uint8_t rightOfWay_;
};

struct Node{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t count_;
    std::vector<NodeItem> nodeItems_;
};


class NodeDecoder:public DecoderBase<struct Node>{
public:
    NodeDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};


#endif //EHR_NODEDECODER_H
} // namespace of ehp_decoder
