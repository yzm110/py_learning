//
// Created by jian.jiang on 2022/9/28.
//

#ifndef EHR_ROUTELISTDECODER_H
#define EHR_ROUTELISTDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct RouteList{
    uint32_t hdmapVersion_;
    uint16_t  linkCount_;
    std::vector<uint32_t> linkId_;
};

class RouteListDecoder :public DecoderBase<struct RouteList>{
public:
    RouteListDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};

#endif //EHR_ROUTELISTDECODER_H
} // namespace of ehp_decoder
