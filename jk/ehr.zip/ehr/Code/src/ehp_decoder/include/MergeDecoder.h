//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_MERGEPOINTDECODER_H
#define EHR_MERGEPOINTDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct MergePointItem{
    uint32_t pathId_;
    uint32_t offset_;
    bool isMaster_;
};

struct MergePoint{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t mergePointCount_;
    std::vector<MergePointItem> mergePointItems_;
};


class MergePointDecoder:public DecoderBase<struct MergePoint>{
public:
    MergePointDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};

#endif //EHR_MERGEPOINTDECODER_H
} // namespace of ehp_decoder
