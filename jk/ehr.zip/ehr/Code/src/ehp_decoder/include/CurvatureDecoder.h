//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_CURVATUREDECODER_H
#define EHR_CURVATUREDECODER_H

#include "DecoderBase.h"


namespace ehp_decoder
{
struct Curvature{
    uint32_t offset_;
    float curvature_;
};

struct Curvatures{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t curCount_;
    std::vector<Curvature> curvatures_;
};


class CurvatesDecoder:public DecoderBase<Curvatures>{
public:
    CurvatesDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};

#endif //EHR_CURVATUREDECODER_H

} //namespace of ehp_decoder
