//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_TOLLGATEDECODER_H
#define EHR_TOLLGATEDECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct TollGate{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    bool isTollGate_;
};


class TollGateDecoder:public DecoderBase<TollGate>{
public:
    TollGateDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};

#endif //EHR_TOLLGATEDECODER_H
} // namespace of ehp_decoder
