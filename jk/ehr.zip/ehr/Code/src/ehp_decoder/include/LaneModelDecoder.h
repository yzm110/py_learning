//
// Created by jian.jiang on 2022/9/29.
//

#ifndef EHR_LANEMODELDECODER_H
#define EHR_LANEMODELDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct LaneInfo{
    uint8_t laneNum_;
    uint8_t direction_;
    uint8_t transit_;
    uint32_t laneType_;
    uint32_t laneAppType_;
    uint32_t centerLine_;
    uint32_t l_bound_;
    uint32_t r_bound_;
};

struct LaneModel{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t totalNumLane_;
    std::vector<LaneInfo> laneInfos_;
};


class LaneModelDecoder:public DecoderBase<struct LaneModel>{
public:
    LaneModelDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};


#endif //EHR_LANEMODELDECODER_H

} // namespace of ehp_decoder
