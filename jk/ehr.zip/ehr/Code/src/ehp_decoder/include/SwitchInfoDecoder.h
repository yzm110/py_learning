//
// Created by jian.jiang on 2022/9/28.
//

#ifndef EHR_SWITCHINFODECODER_H
#define EHR_SWITCHINFODECODER_H

#include "DecoderBase.h"
namespace ehp_decoder
{
struct SwitchInfo{
    uint8_t navigationStatus_;
    uint8_t matchingStatus_;
    uint32_t remainDistance_;
    uint8_t switchLaneDirection_;
    uint8_t switchLaneReason_;
    uint16_t switchLaneDistance_;
    uint16_t switchLaneEndDistance_;
    uint16_t lineCount_;
    std::vector<uint32_t> linearObjectIds_;
};

class SwitchInfoDecoder:public DecoderBase<struct SwitchInfo>{
public:
    SwitchInfoDecoder()=default;
    void decode(const std::vector<unsigned char>& input) override;
};

#endif //EHR_SWITCHINFODECODER_H
} // namespace of ehp_decoder
