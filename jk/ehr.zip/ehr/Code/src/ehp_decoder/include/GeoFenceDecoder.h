//
// Created by jian.jiang on 2022/9/30.
//

#ifndef EHR_GEOFENCEDECODER_H
#define EHR_GEOFENCEDECODER_H

#include "DecoderBase.h"

namespace ehp_decoder
{
struct GeoFenceItem
{
    uint8_t geoFenceType_;
    uint8_t laneSequence_;
    uint32_t s_offset_;
    uint32_t e_offset_;
};


struct Geofence{
    uint32_t instanceId_;
    bool retransmis_;
    uint8_t change_;
    float confidence_;
    uint32_t pathId_;
    uint8_t laneNumber_;
    uint32_t offset_;
    uint32_t endOffset_;
    bool endOffsetF_;
    uint8_t interpolat_;
    uint8_t type_;
    bool available_;
    uint8_t geoFenceCount_;
    std::vector<GeoFenceItem> geoFenceItems_;
};


class GeofenceDecoder:public DecoderBase<Geofence>{
public:
    GeofenceDecoder()=default;
    void decode(const std::vector<unsigned char>& input);
};

#endif //EHR_GEOFENCEDECODER_H

} // namespace of ehp_decoder
