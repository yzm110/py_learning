#include "SomeipService.h"

namespace map {

    ara::core::StringView const kInstanceSpecifierService{
            "EHRExe/EHR/EHRSIP"};

    SomeipService::SomeipService()
            : log_(ara::log::CreateLogger(ara::core::StringView{"EHR"},
                                          ara::core::StringView{"EHR"})),
              ehrsi_out::skeleton::EHRSI_OutSkeleton(
                      ehrsi_out::skeleton::EHRSI_OutSkeleton::Preconstruct(
                              ara::core::InstanceSpecifier{kInstanceSpecifierService})
                              .InspectError([](ara::core::ErrorCode const &error_code) {
                                  ara::core::String error_msg{
                                          "Failed to create "
                                          "EHRSI_OutSkeleton::ConstructionToken with "
                                          "error: "};
                                  error_msg.append(error_code.UserMessage());
                                  ara::core::Abort(error_msg.c_str());
                              })
                              .Value()) {
        ehrsi_out::skeleton::EHRSI_OutSkeleton::OfferService();
        log_.LogInfo() << "[EHR]  OfferService  succeed ! [EHR] "
                          "is running...";
    }

    SomeipService::~SomeipService() {
        ehrsi_out::skeleton::EHRSI_OutSkeleton::StopOfferService();
    }

    void SomeipService::SendEvent(const FormOfWays::FormOfWays &data) {
        EHR_Bus_FormOfWays.Send(data);
        //log_.LogInfo() << "[EHR] send [FormOfWays] succeed!";
    }
    
    void SomeipService::SendEvent(const LaneWidthes::LaneWidthes &data) {
        EHR_Bus_LaneWidthes.Send(data);
        //log_.LogInfo() << "[EHR] send [LaneWidthes] succeed!";
    }

    void SomeipService::SendEvent(const LinearObjects::LinearObjects &data) {
        EHR_Bus_LinearObjects.Send(data);
        //log_.LogInfo() << "[EHR] send [LinearObjects] succeed!";
    }

    void SomeipService::SendEvent(const NOAInfo::NOAInfo &data) {
        EHR_Bus_NOAInfo.Send(data);
        //log_.LogInfo() << "[EHR] send [NOAInfo] succeed!";
    }

    void SomeipService::SendEvent(const LaneConnectivitys::LaneConnectivitys &data) {
        EHR_Bus_LaneConnectivitys.Send(data);
        //log_.LogInfo() << "[EHR] send [LaneConnectivitys] succeed!";
    }

    void SomeipService::SendEvent(const ::Nodes::Nodes &data) {
        EHR_Bus_Nodes.Send(data);
        //log_.LogInfo() << "[EHR] send [Nodes] succeed!";
    }

    void SomeipService::SendEvent(const ::TrafficSigns::TrafficSigns &data) {
        EHR_Bus_TrafficSigns.Send(data);
        //log_.LogInfo() << "[EHR] send [TrafficSigns] succeed!";
    }

    void SomeipService::SendEvent(const ::GeoFences::GeoFences &data) {
        EHR_Bus_GeoFences.Send(data);
        //log_.LogInfo() << "[EHR] send [GeoFences] succeed!";
    }

    void SomeipService::SendEvent(const ::LinkCurvatures::LinkCurvatures &data) {
        EHR_Bus_LinkCurvatures.Send(data);
        //log_.LogInfo() << "[EHR] send [Curvatures] succeed!";
    }

    void SomeipService::SendEvent(const ::LinkSlopes::LinkSlopes &data) {
        EHR_Bus_LinkSlopes.Send(data);
        //log_.LogInfo() << "[EHR] send [Slopes] succeed!";
    }

    void SomeipService::SendEvent(const ::LaneSpeedLimits::LaneSpeedLimits &data) {
        EHR_Bus_LaneSpeedLimits.Send(data);
//        log_.LogInfo() << "[EHR] send [speedlimit] succeed!";
    }

    void SomeipService::SendEvent(const ::LinkInfos::LinkInfos &data) {
        EHR_Bus_LinkInfos.Send(data);
//        log_.LogInfo() << "[EHR] send [Links] succeed!";
    }

    void SomeipService::SendEvent(const ::AllMergePoints::LinkMergePoints &data) {
        EHR_Bus_AllMergePoints.Send(data);
//        log_.LogInfo() << "[EHR] send [MergePoints] succeed!";
    }
}  // namespace Perception