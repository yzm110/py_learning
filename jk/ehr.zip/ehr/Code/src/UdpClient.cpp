#include "UdpClient.h"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <iostream>
#include <vector>

namespace map {
    UdpClient::UdpClient(const std::string &ip, uint16_t port)
            : ip_(ip), port_(port) {}

    int UdpClient::add_udp_multi(int sockfd, const char *udp_ip, int udp_port) {
        struct sockaddr_in localSock;
        struct ip_mreq group;

        int reuse = 1;
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *) &reuse, sizeof(reuse)) < 0) {
            perror("Setting SO_REUSEADDR error");
            close(sockfd);
        } else
            printf("Setting SO_REUSEADDR...OK.\n");

        group.imr_multiaddr.s_addr = inet_addr(udp_ip);
        group.imr_interface.s_addr = INADDR_ANY;
        if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *) &group, sizeof(group)) < 0) {
            perror("Adding multicast group error");
            close(sockfd);
        } else
            printf("Adding multicast group...OK.\n");


        memset((char *) &localSock, 0, sizeof(localSock));
        localSock.sin_family = AF_INET;
        localSock.sin_port = htons(udp_port);
        localSock.sin_addr.s_addr = inet_addr(udp_ip);//htonl(INADDR_ANY);
        if (bind(sockfd, (struct sockaddr *) &localSock, sizeof(localSock))) {
            perror("Binding datagram socket error");
            close(sockfd);
        } else
            printf("Binding datagram socket...OK.\n");

        return 1;
    }

    void UdpClient::StartRecvLoop() {
        printf("\r\n[%s::%s().Line%d]: Test UDP MultiCast Receive Message!\r\n", __FILE__,
               __FUNCTION__, __LINE__);

        int32_t dwSocketFd = -1;
        if ((dwSocketFd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
            perror("Create Socket: ");
            return;
        }

        if (add_udp_multi(dwSocketFd, ip_.c_str(), port_) < 0) {
            perror("add_udp_multi 225.0.0.10:12306 error");
            return;
        }

        uint32_t dwOpenLoop = 1;
        if (setsockopt(dwSocketFd, IPPROTO_IP, IP_MULTICAST_LOOP, &dwOpenLoop, sizeof(dwOpenLoop)) < 0) {
            perror("setsockopt():IP_MULTICAST_LOOP\n");
            return;
        } else
            printf("IP_MULTICAST_LOOP...OK.\n");

        uint8_t szRecvBuffer[2048] = {0};
        uint32_t dwReadLen = 0;

        sockaddr_in hostAddr;
        socklen_t hostAddrSize = sizeof(hostAddr);

        while (1) {
            bzero(szRecvBuffer, sizeof(szRecvBuffer));
            dwReadLen = recvfrom(dwSocketFd, szRecvBuffer, sizeof(szRecvBuffer),
                                 0, (sockaddr *) &hostAddr,&hostAddrSize);
            if(dwReadLen > 0 && callback_){
                callback_(szRecvBuffer, dwReadLen);
            }
        }
        std::cout << "Exit Main() Now !\r\n";

    }

    UdpClient::~UdpClient() {}

    void UdpClient::SetCallBack(std::function<void(const uint8_t *, uint32_t)> fun) {
        callback_ = fun;
    }
}  // namespace map
