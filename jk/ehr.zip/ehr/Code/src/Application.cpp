
#include "Application.h"

#include <iostream>
#include <csignal>

namespace map {
    Application::Application(const std::string &ip, uint16_t port)
            : udpclient_(ip, port) {

    }

// Application::Application(const std::string& ip, uint16_t port)
//     : udpclient_(ip, port) {}
    Application::~Application() {}

    void Application::StartMainLoop() {
        ReportApplicationState(ara::exec::ApplicationState::kRunning);
//        ehpProcess.init_log();

        // main loop ,check exit
        signal_handler_thread_.reset(new std::thread{&Application::SignalHandle, this});
        work_thread_.reset(new std::thread(&Application::WorkProc, this));

        std::chrono::steady_clock::time_point next_run{
                std::chrono::steady_clock::now()};
        std::chrono::steady_clock::duration duration{
                std::chrono::milliseconds{MAIN_THREAD}};
        while (!terminated_by_signal_) {
            //log_.LogInfo() << "main loop------------>";
            next_run += duration;
            std::this_thread::sleep_until(next_run);
        }
        if(signal_handler_thread_->joinable()){
            signal_handler_thread_->join();
        }
        if(work_thread_->joinable()){
            work_thread_->join();
        }

        ReportApplicationState(ara::exec::ApplicationState::kTerminating);
    }

    void Application::WorkProc() {
        log_.LogInfo() << "Application::WorkProc()   start";
        //init udp thread
        udpclient_.SetCallBack([this](const uint8_t *data, uint32_t len) {
            // log_.LogInfo() << "call back data len:" << len;
            // log_.LogInfo() << "data: " << data;
            std::vector<unsigned char> unit_array(data, data + len);
            ehpProcess.process(unit_array);
        });
        udp_thread_.reset(new std::thread(&UdpClient::StartRecvLoop, udpclient_));
        service_thread_.reset(new std::thread(&Application::OutputThread, this));

        log_.LogInfo() << "Application::WorkProc() end.";
    }

    void Application::OutputThread() {
        std::chrono::steady_clock::time_point next_run{std::chrono::steady_clock::now()};
        std::chrono::steady_clock::duration duration{std::chrono::milliseconds{100}};

        log_.LogInfo() << "Application::OutputThread()   start";
        while (true) {
            OutputWork();

            next_run += duration;
            std::this_thread::sleep_until(next_run);
        }
        log_.LogInfo() << "OutputThread work finished.";
    }

    void Application::OutputWork() {
        log_.LogInfo() << "Application::OutputWork()   start";
        ehpProcess.buf_mutex_.lock();
        log_.LogInfo() << "ehpProcess get mutex, send data!";

        service_.SendEvent(ehpProcess.GetNOAInfo());

        // send LaneConnectivitys
        service_.SendEvent(ehpProcess.GetLaneConnectivity());

        //send FW
        service_.SendEvent(ehpProcess.GetFW());

        //send lane width
        service_.SendEvent(ehpProcess.GetLaneWidth());

        //send linear object
        service_.SendEvent(ehpProcess.GetLinearObject());

        // send Nodes
        service_.SendEvent(ehpProcess.GetNodes());

        // EHR_Bus_TrafficSigns
        service_.SendEvent(ehpProcess.GetTrafficSign());

        // EHR_Bus_GeoFences
        service_.SendEvent(ehpProcess.GetGeofence());

        // EHR_Bus_LinkCurvatures
        service_.SendEvent(ehpProcess.GetCurvature());

        // EHR_Bus_LinkSlopes
        service_.SendEvent(ehpProcess.GetSlope());

        // EHR_Bus_LaneSpeedLimits
        service_.SendEvent(ehpProcess.GetSpeedLimit());

        // EHR_Bus_LinkInfos
        service_.SendEvent(ehpProcess.GetLink());

        // EHR_Bus_MergePoints
        service_.SendEvent(ehpProcess.GetMergePoint());

        // EHR_Bus_GeofennceJudge
        ehpProcess.buf_mutex_.unlock();

    }

    void Application::SignalHandle() {
        sigset_t signal_set;
        if (0 != sigemptyset(&signal_set)) {
            log_.LogFatal() << "CAM could not empty signal set.";
            ara::core::Abort("Empty signal set failed.");
        }
        if (0 != sigaddset(&signal_set, SIGTERM)) {
            log_.LogFatal() << "CAM cannot add signal to signalset: SIGTERM";
            ara::core::Abort("Adding SIGTERM failed.");
        }
        if (0 != sigaddset(&signal_set, SIGINT)) {
            log_.LogFatal() << "CAM cannot add signal to signalset: SIGINT";
            ara::core::Abort("Adding SIGINT failed.");
        }

        // Loop until SIGTERM or SIGINT signal received
        int sig{-1};  // VECTOR SL AutosarC++17_10-A3.9.1: MD_tmp_A3.9.1_sigwait

        do {
            // TODO  if  blocked by sigwait ,how to finish this thread
            if (0 != sigwait(&signal_set, &sig)) {
                log_.LogFatal() << "CAM called sigwait() with invalid signalset.";
                ara::core::Abort("Waiting for SIGTERM or SIGINT failed.");
            }
            log_.LogInfo() << "CAM received signal: " << sig << ".";

            // VECTOR NL AutosarC++17_10-M18.7.1: MD_tmp_M18.7.1_signalhandling
            if ((sig == SIGTERM) || (sig == SIGINT)) {
                log_.LogInfo()
                        << "CAM received SIGTERM or SIGINT, requesting application shutdown.";
                if (!signal_exit_) {
                    // Request application exit. (SignalHandler initiate the shutdown!)
                    signal_exit_ = true;
                }
                terminated_by_signal_ = true;
            }
        } while (!signal_exit_);
    }

    void Application::ReportApplicationState(
            ara::exec::ApplicationState application_state) {
        std::string application_state_string;
        bool error_occurred = false;

        // Verify which state should be reported.
        if (application_state == ara::exec::ApplicationState::kRunning) {
            application_state_string = "kRunning";
        } else if (application_state == ara::exec::ApplicationState::kTerminating) {
            application_state_string = "kTerminating";
        } else {
            // Invalid application state detected.
            error_occurred = true;
            log_.LogError()
                    << "ReportApplicationState called with an invalid application state "
                    << application_state_string << ".";
        }

        // Check if invalid application state was detected.
        if (!error_occurred) {
            log_.LogDebug()
                    << "StartApplicationCmClient1 is reporting Application state "
                    << application_state_string << ".";

            // Send application state.
            if (application_client_.ReportApplicationState(application_state) ==
                ara::exec::ApplicationReturnType::kSuccess) {
                log_.LogDebug() << "StartApplicationCmClient1 reported Application state "
                                << application_state_string << " successfully.";
            } else {
                // Application state could not be set.
                log_.LogError()
                        << "StartApplicationCmClient1 could not report the Application state "
                        << application_state_string << ".";
            }
        }
    }

}  // namespace map
