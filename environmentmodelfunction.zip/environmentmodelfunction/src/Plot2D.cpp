#include "Plot2D.h"

namespace earth {
namespace shell {
namespace framework {
using namespace mantle;
std::shared_ptr<Plot2D> Plot2D::getuniqueptr() {
    if (!plot2d) {
        std::unique_lock<std::mutex> lock(plot2dmutex);
        if (!plot2d) {
            plot2d = std::shared_ptr<Plot2D>(new Plot2D());
        }
    }
    return plot2d;
}

void Plot2D::plot(const message::map_position::s_Position_t& map_position_,
                  const TopicTrait::MapMapMsg& map_static_info_, const TopicTrait::MapSwitchInfoMsg& switch_info_msg_) {
    double lon_ego = static_cast<double>(map_position_.Lon.Lon) * 360.0 / (pow(2, 32));
    double lat_ego = static_cast<double>(map_position_.Lat.Lat) * 360.0 / (pow(2, 32));
    double utm_x_ego;
    double utm_y_ego;
    double ego_z;
#ifdef USE_PROJ4
    CommonTool::CoordinateConvertTool::GetInstance()->WGS84ToUTM(lon_ego, lat_ego, 0, &utm_x_ego, &utm_y_ego, &ego_z);
#else
    CommonTool::CoordinateTool::GetInstance()->wgs84toUTM2(lat_ego, lon_ego, utm_x_ego, utm_y_ego, lat_ego, lon_ego);
    // LonLat2UTM(lon_ego, lat_ego, utm_x_ego, utm_y_ego);
#endif
    double heading = static_cast<double>(map_position_.Heading.Heading);

    if (!routing_id.empty()) {
        routing_id.clear();
    }
    if (switch_info_msg_.NOAInfo.PairOfIds.PairOfIds.size() > 0) {
        for (int i = 0; i < switch_info_msg_.NOAInfo.PairOfIds.PairOfIds.size(); i++) {
            routing_id.push_back(switch_info_msg_.NOAInfo.PairOfIds.PairOfIds[i].LinearObjectId);
        }
    }

    for (auto link_index = map_static_info_.LinearObjects.LinearObjects.begin();
         link_index < map_static_info_.LinearObjects.LinearObjects.end(); link_index++) {
        if (link_startposninfo.find(link_index->InstanceId.InstanceId) == link_startposninfo.end()) {
            std::vector<double> ab;
            double lon =
                double(link_index->GeometryPoints.GeometryPoints[0].Longitude.Longitude) * 360.0 / (pow(2, 32));
            double lat = double(link_index->GeometryPoints.GeometryPoints[0].Latitude.Latitude) * 360.0 / pow(2, 32);
            double utm_x;
            double utm_y;
            double utm_z;
#ifdef USE_PROJ4

            CommonTool::CoordinateConvertTool::GetInstance()->WGS84ToUTM(lon, lat, 0, &utm_x, &utm_y, &utm_z);
#else
            CommonTool::CoordinateTool::GetInstance()->wgs84toUTM2(lat, lon, utm_x, utm_y, lat_ego, lon_ego);
            // LonLat2UTM(lon, lat, utm_x, utm_y);
#endif
            ab.push_back(utm_x);
            ab.push_back(utm_y);
            link_startposninfo.insert({link_index->InstanceId.InstanceId, ab});
        }
    }
    for (auto link_id = link_startposninfo.begin(); link_id != link_startposninfo.end();) {
        if (sqrt(pow(link_id->second[0] - utm_x_ego, 2) + pow(link_id->second[1] - utm_y_ego, 2)) > 300) {
            link_id = link_startposninfo.erase(link_id);
        } else {
            link_id++;
        }
    }
#ifdef BUILD_WITH_ZPLOT
    ZPLOT_APPEND_XY_BEGIN("EFM_INFO", "point_x", "point_y");
    auto rect = rotatedRect(0, 0, 2, 1, 0);
    auto& self_car = rect.first;
    auto& self_car_y = rect.second;
    ZPLOTXYF("EFM_INFO", "-black2", self_car, self_car_y);
    // ZPLOT_BOX("EFM_INFO", 0, 0, 1, 2.5, 0);
    //  for(auto plot_link = map_static_info_.LinearObjects.LinearObjects.begin();plot_link <
    //  map_static_info_.LinearObjects.LinearObjects.end();plot_link++){
    //      if(link_startposninfo.find(plot_link->InstanceId.InstanceId) != link_startposninfo.end() &&
    //          static_cast<int>(plot_link->LinearObjectType.data) == 0 ){//&&
    //          // find(routing_id.begin(),routing_id.end(),plot_link->IDLinearObject.IDLinearObject) !=
    //          routing_id.end()) {    //serch for link ID chich have chosed into select vector std::vector<double>
    //          point_x; std::vector<double> point_y; for(int i = 0;i<
    //          plot_link->GeometryPoints.GeometryPoints.size();i++){
    //              double lon_ =
    //              double(plot_link->GeometryPoints.GeometryPoints[i].Longitude.Longitude)*360.0/(pow(2,32)); double
    //              lat_ = double(plot_link->GeometryPoints.GeometryPoints[i].Latitude.Latitude)*360.0/(pow(2,32));
    //              double utm_x_;
    //              double utm_y_;
    //              LonLat2UTM(lon_,lat_,utm_x_,utm_y_);
    //              double UTME_pre = utm_x_ - utm_x_ego;
    //              double UTMN_pre = utm_y_ - utm_y_ego;

    //             double trans_heading = heading + M_PI;
    //             double UTME = UTME_pre * std::cos(trans_heading) - UTMN_pre * std::sin(trans_heading);
    //             double UTMN = UTMN_pre * std::cos(trans_heading) - UTME_pre * std::sin(trans_heading);

    //             point_x.push_back((UTME));
    //             point_y.push_back((UTMN));
    //         }
    //         if(point_x.size() > 0 && point_y.size() > 0){
    //                 ZPLOTXYF("EFM_INFO","+green14",point_x,point_y);
    //         }
    //     }
    // }

    ZPLOT_APPEND_XY_END("EFM_INFO", "point_x", "point_y");
#endif
#ifdef BUILD_WITH_ZPLOT
    ZPLOT_APPEND_XY_BEGIN("EFM_INFO", "point_x1", "point_y1");
    {
        std::vector<double> point_x1{}, point_y1{};
        ZPLOTXYF("EFM_INFO", "--red1", point_x1, point_y1);
    }
    for (auto plot_link = map_static_info_.LinearObjects.LinearObjects.begin();
         plot_link < map_static_info_.LinearObjects.LinearObjects.end(); plot_link++) {
        if (link_startposninfo.find(plot_link->InstanceId.InstanceId) != link_startposninfo.end() &&
            static_cast<int>(plot_link->LinearObjectType.data) != 0 &&
            static_cast<int>(plot_link->LinearObjectMarking.data ==
                             3)) {  // serch for link ID chich have chosed into select vector
            std::vector<double> point_x1;
            std::vector<double> point_y1;
            for (int i = 0; i < plot_link->GeometryPoints.GeometryPoints.size(); i++) {
                double lon_ =
                    double(plot_link->GeometryPoints.GeometryPoints[i].Longitude.Longitude) * 360.0 / (pow(2, 32));
                double lat_ =
                    double(plot_link->GeometryPoints.GeometryPoints[i].Latitude.Latitude) * 360.0 / (pow(2, 32));
                double utm_x_;
                double utm_y_;
                double utm_z_;
#ifdef USE_PROJ4

                CommonTool::CoordinateConvertTool::GetInstance()->WGS84ToUTM(lon_, lat_, 0, &utm_x_, &utm_y_, &utm_z_);
#else
                CommonTool::CoordinateTool::GetInstance()->wgs84toUTM2(lat_, lon_, utm_x_, utm_y_, lat_ego, lon_ego);
                // LonLat2UTM(lon_, lat_, utm_x_, utm_y_);
#endif
                double UTME_pre = utm_x_ - utm_x_ego;
                double UTMN_pre = utm_y_ - utm_y_ego;

                double trans_heading = heading + M_PI;
                double UTME = -UTME_pre * std::sin(trans_heading) - UTMN_pre * std::cos(trans_heading);
                double UTMN = -UTMN_pre * std::sin(trans_heading) + UTME_pre * std::cos(trans_heading);

                point_x1.push_back(UTME);
                point_y1.push_back(UTMN);
            }
            if (point_x1.size() > 0 && point_y1.size() > 0) {
                ZPLOTXYF("EFM_INFO", "--red1", point_x1, point_y1);
            }
        }
    }
    ZPLOT_APPEND_XY_END("EFM_INFO", "point_x1", "point_y1");
#endif
#ifdef BUILD_WITH_ZPLOT
    ZPLOT_APPEND_XY_BEGIN("EFM_INFO", "point_x2", "point_y2");
    {
        std::vector<double> point_x2{}, point_y2{};
        ZPLOTXYF("EFM_INFO", "-blue2", point_x2, point_y2);
    }
    for (auto plot_link = map_static_info_.LinearObjects.LinearObjects.begin();
         plot_link < map_static_info_.LinearObjects.LinearObjects.end(); plot_link++) {
        if (link_startposninfo.find(plot_link->InstanceId.InstanceId) != link_startposninfo.end() &&
            static_cast<int>(plot_link->LinearObjectType.data) != 0 &&
            static_cast<int>(plot_link->LinearObjectMarking.data !=
                             3)) {  // serch for link ID chich have chosed into select vector
            std::vector<double> point_x2;
            std::vector<double> point_y2;
            for (int i = 0; i < plot_link->GeometryPoints.GeometryPoints.size(); i++) {
                double lon_ =
                    double(plot_link->GeometryPoints.GeometryPoints[i].Longitude.Longitude) * 360.0 / (pow(2, 32));
                double lat_ =
                    double(plot_link->GeometryPoints.GeometryPoints[i].Latitude.Latitude) * 360.0 / (pow(2, 32));
                double utm_x_;
                double utm_y_;
                double utm_z_;
#ifdef USE_PROJ4

                CommonTool::CoordinateConvertTool::GetInstance()->WGS84ToUTM(lon_, lat_, 0, &utm_x_, &utm_y_, &utm_z_);
#else
                CommonTool::CoordinateTool::GetInstance()->wgs84toUTM2(lat_, lon_, utm_x_, utm_y_, lat_ego, lon_ego);
                // LonLat2UTM(lon_, lat_, utm_x_, utm_y_);
#endif
                double UTME_pre = utm_x_ - utm_x_ego;
                double UTMN_pre = utm_y_ - utm_y_ego;

                double trans_heading = heading + M_PI;
                double UTME = -UTME_pre * std::sin(trans_heading) - UTMN_pre * std::cos(trans_heading);
                double UTMN = -UTMN_pre * std::sin(trans_heading) + UTME_pre * std::cos(trans_heading);
                point_x2.push_back(UTME);
                point_y2.push_back(UTMN);
            }
            if (point_x2.size() > 0 && point_y2.size() > 0) {
                ZPLOTXYF("EFM_INFO", "-blue2", point_x2, point_y2);
            }
        }
    }
    ZPLOT_APPEND_XY_END("EFM_INFO", "point_x2", "point_y2");
#endif
    // std::cout << "link_startposninfo :" << link_startposninfo.size() <<  std::endl;
}

void Plot2D::LonLat2UTM(double longitude, double latitude, double& UTME, double& UTMN) {
    double lon = longitude;
    double lat = latitude;
    // unit: km
    // variable
    double a = 6378.137;  // 赤道半径
    double e = 0.0818192;
    double k0 = 0.9996;
    double E0 = 500;
    double N0 = 0;
    // calc zoneNumber
    double zoneNumber = floor(lon / 6) + 31;
    // calc lambda0
    double lambda0 = (zoneNumber - 1) * 6 - 180 + 3;  // deg
    lambda0 = lambda0 * DEG_TO_RAD_LOCAL;             // radian
    // calc phi and lambda (lat and lon)
    double phi = lat * DEG_TO_RAD_LOCAL;
    double lambda = lon * DEG_TO_RAD_LOCAL;

    // Formula START
    double v = 1 / sqrt(1 - pow(e * sin(phi), 2));
    double A = (lambda - lambda0) * cos(phi);
    double T = pow(tan(phi), 2);
    double C = pow(e, 2) / (1 - pow(e, 2)) * pow(cos(phi), 2);
    double s = (1 - pow(e, 2) / 4 - 3 * pow(e, 4) / 64 - 5 * pow(e, 6) / 256) * phi -
               (3 * pow(e, 2) / 8 + 3 * pow(e, 4) / 32 + 45 * pow(e, 6) / 1024) * sin(2 * phi) +
               (15 * pow(e, 4) / 256 + 45 * pow(e, 6) / 1024) * sin(4 * phi) - 35 * pow(e, 6) / 3072 * sin(6 * phi);

    UTME = E0 + k0 * a * v * (A + (1 - T + C) * pow(A, 3) / 6 + (5 - 18 * T + T * T) * pow(A, 5) / 120);
    UTMN = N0 + k0 * a *
                    (s + v * tan(phi) *
                             (pow(A, 2) / 2 + (5 - T + 9 * C + 4 * C * C) * pow(A, 4) / 24 +
                              (61 - 58 * T + T * T) * pow(A, 6) / 720));

    UTME *= 1000;
    UTMN *= 1000;
}

std::pair<std::array<double, 5>, std::array<double, 5>> Plot2D::rotatedRect(double x, double y, double half_width,
                                                                            double half_height, double angle) {
    double c = cos(angle);
    double s = sin(angle);
    double r1x = -half_width * c - half_height * s;
    double r1y = -half_width * s + half_height * c;
    double r2x = half_width * c - half_height * s;
    double r2y = half_width * s + half_height * c;
    return {{x + r1x, x + r2x, x - r1x, x - r2x, x + r1x}, {y + r1y, y + r2y, y - r1y, y - r2y, y + r1y}};
}

Plot2D::Plot2D(/* args */) {}

Plot2D::~Plot2D() {}

}  // namespace framework
}  // namespace shell
}  // namespace earth
