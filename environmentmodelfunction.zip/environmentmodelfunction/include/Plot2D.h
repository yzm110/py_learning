#include <chrono>
#include <cmath>
#include <iostream>
#include <map>
#include <memory>
#include <thread>
#include <utility>
#include <vector>

#include "CandidateLanesModel.h"
#include "CompileConfig.h"
#include "ScenarioJudgeModel.h"
#ifdef USE_PROJ4
#include "coordinate_convert_tool.h"
#endif
#include "CoordinateTool.h"
#include "math.h"
// #include "topic/topic_trait.h"
#include "common/framework.h"
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace earth {
namespace shell {
namespace framework {
using namespace mantle;

class Plot2D {
   private:
    std::vector<uint32_t> routing_id;
    std::string csv_name;
    std::unordered_map<unsigned int, std::vector<double>> link_startposninfo;

   public:
    constexpr static double DEG_TO_RAD_LOCAL = 3.1415926535897932 / 180.0;

    static std::shared_ptr<Plot2D> getuniqueptr();
    void LonLat2UTM(double longitude, double latitude, double& UTME, double& UTMN);
    void plot(const message::map_position::s_Position_t& map_position, const TopicTrait::MapMapMsg& map_static_info,
              const TopicTrait::MapSwitchInfoMsg& switch_info_msg);
    std::pair<std::array<double, 5>, std::array<double, 5>> rotatedRect(double x, double y, double half_width,
                                                                        double half_height, double angle);

    Plot2D(/* args */);
    ~Plot2D();
};

static std::shared_ptr<Plot2D> plot2d = nullptr;
static std::mutex plot2dmutex;

}  // namespace framework
}  // namespace shell
}  // namespace earth