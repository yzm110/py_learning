#pragma once
// //DISABLE_GCC_WARNINGS
//  DISABLE_WARNING(sign-conversion, )
//  DISABLE_WARNING(old-style-cast, )
//  DISABLE_WARNING(float-conversion, )
//  DISABLE_WARNING(double-promotion, )
//DISABLE_WARNING(unused-parameter, )
//DISABLE_WARNING(unused-variable, )
//DISABLE_WARNING(unused-but-set-variable, )
//  #if __linux
//  DISABLE_WARNING(deprecated-copy, )
//  #endif
//  DISABLE_WARNING(useless-cast, )
//  DISABLE_WARNING(old-style-cast, )
//  DISABLE_WARNING(maybe-uninitialized, )
//DISABLE_WARNING(sign-compare, )
// DISABLE_WARNING(uninitialized, )
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wsign-compare"
#pragma GCC diagnostic ignored "-Wold-style-cast"
#pragma GCC diagnostic ignored "-Wsign-conversion"
#pragma GCC diagnostic ignored "-Wtype-limits"
