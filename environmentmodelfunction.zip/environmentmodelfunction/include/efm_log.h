#pragma once
#include <vector>
#include "calibration.h"

//打点信息
extern std::vector<uint32_t> merge_attrbute_link_log;

