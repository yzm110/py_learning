/*
 * @Author: xiaofeng.liu xiaofeng.liu@jicaai.com
 * @Date: 2023-12-26 20:24:56
 * @LastEditors: xiaofeng.liu xiaofeng.liu@jicaai.com
 * @LastEditTime: 2023-12-26 21:03:14
 * @FilePath: /repo82/code/dx11_noa/application/environmentmodelfunction/include/efm_config.h
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#pragma once
#include "store/yaml.h"
#include "calibration.h"
#include <vector>

void EfmConfig(const std::string file_name);


